import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';

const columns = [
  { id: 'no', label: '번호', minWidth: 150 },
  { id: 'name', label: '이름', minWidth: 100 },
  {
    id: 'id',
    label: '아이디',
    minWidth: 170,
    align: 'right',
  },
  {
    id: 'job',
    label: '구분',
    minWidth: 170,
    align: 'right',
  },
  {
    id: 'work',
    label: '재직여부',
    minWidth: 150,
    align: 'right',
  },
];

function createData(no, name, id, job, work) {
  return { no, name, id, job, work };
}

const rows = [
  createData(1, '라이언', '2021073001', '의사', 'Y'),
  createData(2, '어피치', '2021073002', '간호사', 'Y'),
  createData(3, '춘식이', '2021073003', '간호사', 'N'),
  createData(4, '프로도', '2021073004', '간호사', 'Y'),
  createData(5, '제이지', '2021073005', '간호사', 'Y'),
  createData(1, '라이언', '2021073001', '의사', 'Y'),
  createData(2, '어피치', '2021073002', '간호사', 'Y'),
  createData(3, '춘식이', '2021073003', '간호사', 'N'),
  createData(4, '프로도', '2021073004', '간호사', 'Y'),
  createData(5, '제이지', '2021073005', '간호사', 'Y'),
  createData(1, '라이언', '2021073001', '의사', 'Y'),
  createData(2, '어피치', '2021073002', '간호사', 'Y'),
  createData(3, '춘식이', '2021073003', '간호사', 'N'),
  createData(4, '프로도', '2021073004', '간호사', 'Y'),
  createData(5, '제이지', '2021073005', '간호사', 'Y'),
  createData(1, '라이언', '2021073001', '의사', 'Y'),
  createData(7, '어피치', '2021073002', '간호사', 'Y'),
  createData(8, '춘식이', '2021073003', '간호사', 'N'),
  createData(9, '프로도', '2021073004', '간호사', 'Y'),
  createData(10, '제이지', '2021073005', '간호사', 'Y'),
];

const useStyles = makeStyles({
  root: {
    width: '100%',
  },
  container: {
    maxHeight: 600,
  },
});

export default function StickyHeadTable() {
  const classes = useStyles();
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <Paper className={classes.root}>
      <TableContainer className={classes.container}>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                  align={column.align}
                  style={{ minWidth: column.minWidth }}
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
              return (
                <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                  {columns.map((column) => {
                    const value = row[column.id];
                    return (
                      <TableCell key={column.id} align={column.align}>
                        {column.format && typeof value === 'number' ? column.format(value) : value}
                      </TableCell>
                    );
                  })}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination

        component="div"
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Paper>
  );
}
