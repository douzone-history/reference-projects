import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';

const currencies = [
  {
    value: 'All',
    label: '전체',
  },
  {
    value: 'Name',
    label: '이름',
  },
  {
    value: 'ID',
    label: '아이디',
  },
  {
    value: 'Job',
    label: '구분',
  },
];

const useStyles = makeStyles((theme) => ({
  root: {
    '& .MuiTextField-root': {
      width: '20ch',
    },
  },
}));

export default function MultilineTextFields() {
  const classes = useStyles();
  const [currency, setCurrency] = React.useState('All');

  const handleChange = (e) => {
    setCurrency(e.target.value);
  };

  return (
    <form className={classes.root} noValidate autoComplete="off">
        
        <TextField
          id="outlined-select-currency"
          select
          value={currency}
          onChange={handleChange}
          variant="outlined"
        >
          {currencies.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
       
    </form>
  );
}
