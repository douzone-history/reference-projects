import React, { Fragment } from 'react';
import DashBoard from './DashBoard';

export default function App() {
    return (
       <Fragment>
           <DashBoard />
        </Fragment>
    );
}