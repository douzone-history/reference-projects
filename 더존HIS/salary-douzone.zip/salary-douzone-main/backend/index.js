(function () {
    const express = require('express');
    const session = require('express-session');
    const multer = require('multer');
    const http = require('http');
    const path = require('path');
    const dotenv = require('dotenv');
    const { swaggerUi, specs } = require('./routes/swagger/swagger');

    // 1. Startup Arguments
    const argv = require('minimist')(process.argv.slice(2));

    // 2. Environment Variables
    dotenv.config({ path: path.join(__dirname, 'app.config.env') })

    // 3. Process Title(name)
    process.title = argv.name;

    // 4. Application Routers
    const { applicationRouter } = require('./routes');

    // 5. Logger
    const logger = require('./logging');

    // 6. Application Setup
    const application = express()
        // 6-1. Session Environment
        .use(session({
            secret: process.env.SESSION_SECRET,
            resave: false,
            saveUninitialized: false
        }))
        // 6-2. Body Parsers
        .use(express.json())
        .use(express.urlencoded({extended: true}))
         // 6-3. Multer
        .use(multer({dest: path.join(__dirname, process.env.MULTER_TEMPORARY_STORE)}).single('url'))
        // 6-4. Static
        .use(express.static(path.join(__dirname, process.env.STATIC_RESOURCES_DIRECTORY)))
        .use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs))
        // 6-5. View Engine Setup
        .set('views', path.join(__dirname, 'views'))
        .set('view engine', 'ejs');

    // 7. Application Router Setup
    applicationRouter.setup(application);

    // 8. Server Startup
    const server = http.createServer(application)
        .on('listening', function () {
            logger.info('Listening on port ' + process.env.PORT);
        })
        .on('error', function (error) {
            if (error.syscall !== 'listen') {
                throw error;
            }
            switch (error.code) {
                case 'EACCES':
                    logger.error('Port ' + process.env.PORT + ' requires elevated privileges');
                    process.exit(1);
                    break;
                case 'EADDRINUSE':
                    logger.error('Port ' + process.env.PORT + ' is already in use');
                    process.exit(1);
                    break;
                default:
                    throw error;
            }
        });

    const io = require("socket.io")(server, {
        cors: {
            origin: "http://localhost:8888",
            methods: ["GET", "POST"],
        },
    });//cors 오류로 인한 설정

    io.on("connection", (socket) => {
      
        socket.on("send", (item) => {
            io.emit("receive", { 
                no: item.no,
                id: item.id, 
                role: item.role, 
                message: item.message });
        });
        socket.on("sendpatientlist", (item) => {
            io.emit("receivepatientlist", item);
        });
        socket.on("sendcuringpatient", (item) => {
            io.emit("receivecuringpatient", item);
        });
        socket.on("sendpaywaiting", (item) => {
            io.emit("receivepaywaiting", item);
        })
        socket.on("sendCancelOrder", item => {
            io.emit("receiveCancelOrder", item);
        })
        socket.on("sendfinishpatient", (item) => {
            io.emit("receivefinishpatient", item);
        })
        socket.on("sendpatientupdate", (item) => {
            io.emit("receivepatientupdate", item);
        })
        socket.on("sendAddPatient", (item) => {
            io.emit("receiveAddPatient", item);
        })
        socket.on("sendUpdatePatient", (item) => {
            io.emit("receiveUpdatePatient", item);
        })
        socket.on("sendUpdatePatientOfOrderList", (item) => {
            io.emit("receiveUpdatePatientOfOrderList", item);
        })
    });

    server.listen(process.env.PORT);
})();