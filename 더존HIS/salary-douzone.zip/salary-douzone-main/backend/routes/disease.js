const express = require('express');
const controller = require('../controllers/disease');
const router = express.Router();

router.route('').get(controller.readAll);
router.route('/:diseaseNo').get(controller.read);

module.exports = router;