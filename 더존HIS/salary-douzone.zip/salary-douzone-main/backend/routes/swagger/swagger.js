const swaggerUi = require('swagger-ui-express');
const swaggereJsdoc = require('swagger-jsdoc');

const options = {
    swaggerDefinition: {
        info: {
            title: 'DOUZONE HIS APIs',
            version: '1.0.0',
            description: 'Douzone HIS with Express.'
        },
        host: "localhost:9999",
        basePath: "/",
        tags: [
            {
                name: "Member",
                description: 'Member management'
            },
            {
                name: 'Patient',
                description: 'Patient management'
            },
            {
                name: 'Orders',
                description: 'Orders management'
            },
            {
                name: 'Clinic',
                description: 'Clinic management'
            },
            {
                name: 'History',
                description: 'History management'
            },
            {
                name: 'Prescription',
                description: 'Prescription management'
            },
            {
                name: 'Clinic_cure',
                description: 'Clinic_cure management'
            }
        ],
        schemes: ["http", "https"],
        paths: {
            '/api/member': {
                'get': {
                    'tags': ['Member'],
                    'summary': 'Select User Member Read All',
                    'description': '',
                    'produces': ['application/json'],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                },
                'post': {
                    'tags': ['Member'],
                    'summary': 'Add User Member',
                    'description': '',
                    'consumes': ['application/json'],
                    'produces': ['application/json'],
                    'parameters': [
                        {
                            'in': 'body',
                            'name': 'body',
                            'required': true,
                            'schema': {
                                '$ref': '#/definitions/Member'
                            }
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/member/{division}': {
                'get': {
                    'tags': ['Member'],
                    'summary': 'Find Member by Division',
                    'produces': ['apllication/json'],
                    'parameters': [
                        {
                            'name': 'division',
                            'in': 'path',
                            'description': 'Filter List of Membmer to return',
                            'type': 'string'
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/member/{division}/{keyword}': {
                'get': {
                    'tags': ['Member'],
                    'summary': 'Find Member by Division and Keyword',
                    'produces': ['apllication/json'],
                    'parameters': [
                        {
                            'name': 'division',
                            'in': 'path',
                            'description': 'Filter List of Membmer to return',
                            'type': 'string'
                        },
                        {
                            'name': 'keyword',
                            'in': 'path',
                            'description': 'Filter List of Membmer to return',
                            'type': 'string'
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/member/login': {
                'post': {
                    'tags': ['Member'],
                    'summary': 'Login',
                    'description': '',
                    'consumes': ['application/json'],
                    'parameters': [
                        {
                            'in': 'body',
                            'name': 'body',
                            'required': true,
                            'schema': {
                                'type': 'object',
                                'properties': {
                                    'id': {
                                        'tpye': 'string'
                                    },
                                    'password': {
                                        'type': 'string'
                                    }
                                }
                            }
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/member/{memberNo}': {
                'post': {
                    'tags': ['Member'],
                    'summary': 'Update Member Info',
                    'consumes': ['application/json'],
                    'parameters':[
                        {
                            'in': 'path',
                            'name': 'memberNo',
                            'required': true,
                            'type': 'integer',
                            'format': 'int64'
                        },
                        {
                            'in': 'body',
                            'name': 'body',
                            'required': true,
                            'schema': {
                                '$ref': '#/definitions/Member'
                            }
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/member/{no}': {
                'put': {
                    'tags': ['Member'],
                    'summary': 'Select Member find by no',
                    'consumes': ['application/json'],
                    'parameters': [
                        {
                            'in': 'path',
                            'name': 'no',
                            'required': true,
                            'description': 'find needs member no',
                            'type': 'integer'
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },


            '/api/patient': {
                'get': {
                    'tags': ['Patient'],
                    'summary': 'Select Patient Read All',
                    'consumes': ['application/json'],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    } 
                },
                'post': {
                    'tags': ['Patient'],
                    'summary': 'Add Patient',
                    'consumes': ['application/json'],
                    'parameters': [
                        {
                            'in': 'body',
                            'name': 'body',
                            'required': true,
                            'schema': {
                                '$ref': '#/definitions/Patient'
                            }
                        }
    
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    } 
                }
            },
            '/api/patient/info/{patientNo}': {
                'get': {
                    'tags': ['Patient'],
                    'summary': 'A Patient Read Info',
                    'produces': ['application/json'],
                    'parameters': [
                        {
                            'in': 'path',
                            'name': 'patientNo',
                            'required': true,
                            'description': 'find needs patient number',
                            'type': 'integer'
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/patient/{division}': {
                'get': {
                    'tags': ['Patient'],
                    'summary': 'Find Patient by Division',
                    'produces': ['apllication/json'],
                    'parameters': [
                        {
                            'name': 'division',
                            'in': 'path',
                            'description': 'Filter List of Patient to return',
                            'type': 'string'
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/patient/{division}/{keyword}': {
                'get': {
                    'tags': ['Patient'],
                    'summary': 'Find Patient by Division and Keyword',
                    'produces': ['apllication/json'],
                    'parameters': [
                        {
                            'name': 'division',
                            'in': 'path',
                            'description': 'Filter List of Patient to return',
                            'type': 'string'
                        },
                        {
                            'name': 'keyword',
                            'in': 'path',
                            'description': 'Filter List of Patient to return',
                            'type': 'string'
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/patient/{patientNo}': {
                'post': {
                    'tags': ['Patient'],
                    'summary': 'Update Patient Info',
                    'consumes': ['application/json'],
                    'parameters': [
                        {
                            'in': 'path',
                            'name': 'patientNo',
                            'required': true,
                            'description': 'find needs patient number',
                            'type': 'integer'
                        },
                        {
                            'in': 'body',
                            'name': 'body',
                            'schema': {
                                '$ref': '#/definitions/Patient'
                            }
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/patient/{no}': {
                'put': {
                    'tags': ['Patient'],
                    'summary': 'Select Member find by no',
                    'produces': ['application/json'],
                    'parameters': [
                        {
                            'in': 'path',
                            'name': 'no',
                            'required': true,
                            'description': 'Find needs patient number',
                            'type': 'integer'
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/orders': {
                'get': {
                    'tags': ['Orders'],
                    'summary': 'Select Orders Read All',
                    'produces': ['application/json'],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                },
                'post': {
                    'tags': ['Orders'],
                    'summary': 'Add Orders',
                    'consumes': ['application/json'],
                    'parameters': [
                        {
                            'in': 'body',
                            'name': 'body',
                            'required': true,
                            'description': 'pateint order record needs to no',
                            'type': 'string'
                        }
                    ]
                }
            },
            '/api/orders/record/{patientNo}': {
                'get': {
                    'tags': ['Orders'],
                    'summary': 'Select Patient Record Info',
                    'produces': ['application/json'],
                    'parameters': [
                        {
                            'in': 'path',
                            'name': 'patientNo',
                            'required': true,
                            'description': 'patient record needs to no',
                            'type': 'integer'
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/orders/update': {
                'post': {
                    'tags': ['Orders'],
                    'summary': 'Patient Update Cure Finish ',
                    'consumes': ['application/json'],
                    'parameters': [
                        {
                            'in': 'body',
                            'name': 'body',
                            'required': true,
                            'schema': {
                                'type': 'object',
                                'properties': {
                                    'no': {
                                        'type': 'integer'
                                    },
                                    'progress': {
                                        'type': 'string'
                                    },
                                    'price': {
                                        'type': 'integer'
                                    }
                                }
                            }
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/orders/{orderNo}': {
                'delete': {
                    'tags': ['Orders'],
                    'summary': 'Delete Orders in Database',
                    'consumes': ['application/json'],
                    'parameters': [
                        {
                            'in': 'path',
                            'name': 'orderNo',
                            'required': true,
                            'type': 'integer'
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/clinic/detail/{clinicNo}': {
                'get': {
                    'tags': ['Clinic'],
                    'summary': 'Patient Cure Detail Info',
                    'produces': ['application/json'],
                    'parameters': [
                        {
                            'in': 'path',
                            'name': 'clinicNo',
                            'required': true,
                            'type': 'integer'
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/clinic': {
                'post': {
                    'tags': ['Clinic'],
                    'summary': 'Add Clinic in Database',
                    'produces': ['application/json'],
                    'parameters': [
                        {
                            'in': 'body',
                            'name': 'body',
                            'required': true,
                            'schema': {
                                'type': 'object',
                                'properties': {
                                    'member_no': {
                                        'type': 'integer'
                                    },
                                    'doctor_message': {
                                        'type': 'string'
                                    },
                                    'mention': {
                                        'type': 'string'
                                    },
                                    'orders_no': {
                                        'type': 'integer'
                                    },
                                }
                            }
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/clinic/pay': {
                'post': {
                    'tags': ['Clinic'],
                    'summary': 'Get Patient Pay Info',
                    'produces': ['application/json'],
                    'parameters': [
                        {
                            'in': 'body',
                            'name': 'body',
                            'required': true,
                            'schema': {
                                '$ref': '#/definitions/Patient'
                            }
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/history': {
                'post': {
                    'tags': ['History'],
                    'summary': 'Add History in Database',
                    'consumes': ['application/json'],
                    'parameters': [
                        {
                            'in': 'body',
                            'name': 'body',
                            'required': true,
                            'schema': {
                                '$ref': '#/definitions/History'
                            }
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/prescription': {
                'post': {
                    'tags': ['Prescription'],
                    'summary': 'Add Prescription in Database',
                    'consumes': ['application/json'],
                    'parameters': [
                        {
                            'in': 'body',
                            'name': 'body',
                            'required': true,
                            'schema': {
                                '$ref': '#/definitions/Prescription'
                            }
                        }
                    ],
                    'responses': {
                        '200': {
                            'description': 'successful operation'
                        }
                    }
                }
            },
            '/api/clinic_cure': {
                'post': {
                    'tags': ['Clinic_cure'],
                    'summary': 'Add Clinic_cure in Database',
                    'consumes': ['application/json'],
                    'parameters': [
                        {
                            'in': 'body',
                            'name': 'body',
                            'required': true,
                            'schema': {
                                '$ref': '#/definitions/Clinic_cure'
                            }
                        }
                    ]
                }
            }
        },
        definitions: 
        {
            'Member': {
                type: 'object',
                properties: {
                    name: {
                        type: 'string'
                    },
                    id: {
                        type: 'string'
                    },
                    password: {
                        type: 'string'
                    },
                    registration_no: {
                        type: 'string'
                    },
                    email: {
                        type: 'string'
                    },
                    cellphone: {
                        type: 'string'
                    },
                    role: {
                        type: 'string',
                        enum: ['admin', 'nurse', 'doctor']
                    },
                    profile: {
                        type: 'string'
                    },
                    address: {
                        type: 'string'
                    },
                    working: {
                        type: 'boolean'
                    },
                    zipcode: {
                        type: 'string'
                    },
                    detailaddress: {
                        type: 'string'
                    },
                    hire_date: {
                        type: 'string',
                        format: 'date'
                    },
                    retire_date: {
                        type: 'string',
                        format: 'date'
                    }
                }
            },
            'Patient': {
                type: 'object',
                properties: {
                    name: {
                        type: 'string'
                    },
                    registration_no: {
                        type: 'string'
                    },
                    cellphone: {
                        type: 'string'
                    },
                    address: {
                        type: 'string'
                    },
                    insurance: {
                        type: 'boolean'
                    },
                    memo: {
                        type: 'string'
                    },
                    detailaddress: {
                        type: 'string'
                    },
                    zipcode: {
                        type: 'string'
                    },
                    visit: {
                        type: 'boolean'
                    }
                }
            },
            'Orders': {
                type: 'object',
                properties: {
                    member_no: {
                        type: 'integer'
                    },
                    patientNo: {
                        type: 'integer'
                    },
                    reg_date: {
                        type: 'string',
                        format: 'date'
                    },
                    nurse_message: {
                        type: 'string'
                    },
                    progress: {
                        type: 'string',
                        enum: ['진료대기', '진료중', '수납대기', '완료']
                    },
                    price: {
                        type: 'string'
                    }
                }
            },
            'Clinic': {
                type: 'object',
                properties: {
                    member_no: {
                        type: 'integer'
                    },
                    reg_date: {
                        type: 'string',
                        format: 'date'
                    },
                    doctor_message: {
                        type: 'string'
                    },
                    mention: {
                        type: 'string'
                    },
                    orders_no: {
                        type: 'integer'
                    }
                }
            },
            'History': {
                type: 'object',
                properties: {
                    name: {
                        type: 'string'
                    },
                    code: {
                        type: 'string'
                    },
                    clinic_no: {
                        type: 'integer'
                    },
                    priority: {
                        type: 'string',
                        enum: ['주', '부']
                    }
                }
            },
            'Prescription': {
                type: 'object',
                properties: {
                    clinic_no: {
                        type: 'integer'
                    },
                    dose: {
                        type: 'string'
                    },
                    daily_dose: {
                        type: 'string'
                    },
                    total_dose: {
                        type: 'string'
                    },
                    medicine_code: {
                        type: 'string'
                    },
                    medicine_name: {
                        type: 'string'
                    }
                }
            },
            'Clinic_cure': {
                type: 'object',
                properties: {
                    cure_no: {
                        type: 'integer'
                    },
                    clinic_no: {
                        type: 'integer'
                    }
                }
            },
        }
    },
    apis: [__dirname + '/../../routes/*.js']
};


const specs = swaggereJsdoc(options);

module.exports = {
    swaggerUi,
    specs
};