const express = require('express');
const controller = require('../controllers/patient');

const router = express.Router();
router.route('').get(controller.readAll);
router.route('').post(controller.add);
router.route('/info/:patientNo').get(controller.getInfo);
router.route('/:patientNo').post(controller.update);
router.route('/:no').put(controller.read);
router.route(['/:division','/:division/:keyword']).get(controller.search);

module.exports = router;