const express = require('express');
const controller = require('../controllers/prescription');

const router = express.Router();
router.route('').post(controller.add);

module.exports = router;