const express = require('express');
const controller = require('../controllers/clinic');

const router = express.Router();
router.route('').post(controller.add);
router.route('/pay').post(controller.pay);
router.route('/detail/:clinicNo').get(controller.detail);

module.exports = router;