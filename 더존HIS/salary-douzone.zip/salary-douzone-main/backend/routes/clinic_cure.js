const express = require('express');
const controller = require('../controllers/clinic_cure');

const router = express.Router();
router.route('').post(controller.add);

module.exports = router