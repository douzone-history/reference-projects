const express = require('express');
const controller = require('../controllers/member');
const router = express.Router();

router.route('').get(controller.readAll);
router.route('').post(controller.addMember);
router.route('/login').post(controller.login);
router.route(['/:division','/:division/:keyword']).get(controller.search);
router.route('/:memberNo').post(controller.update);
router.route('/:no').put(controller.read);

module.exports = router;