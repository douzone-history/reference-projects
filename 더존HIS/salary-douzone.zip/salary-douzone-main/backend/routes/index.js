const errorRouter = require('./error');
const auth = require('./auth');

const applicationRouter = {
    setup: async function(application){

        application
        .all('*', function(req, res, next) {
            res.locals.req = req;
            res.locals.res = res;
            next();
        })

        .use('/api/disease', require('./disease'))
        .use('/api/member', require('./member'))
        .use('/api/medicine', require('./medicine'))
        .use('/api/patient', require('./patient'))
        .use('/api/orders',require('./orders'))
        .use('/api/chat',require('./chat'))
        .use('/api/clinic', require('./clinic'))
        .use('/api/history', require('./history'))
        .use('/api/prescription', require('./prescription'))
        .use('/api/clinic_cure', require('./clinic_cure'))
        
        .use(errorRouter.error404) // 404 error
        .use(errorRouter.error500) // 500 error
    }
};

module.exports = { applicationRouter };