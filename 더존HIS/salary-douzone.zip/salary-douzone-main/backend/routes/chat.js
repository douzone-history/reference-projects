const express = require('express');
const controller = require('../controllers/chat');

const router = express.Router();
router.route('').post(controller.send);
router.route('').get(controller.readAll);


module.exports = router;