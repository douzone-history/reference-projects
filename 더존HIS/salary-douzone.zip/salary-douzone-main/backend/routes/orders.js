const express = require('express');
const controller = require('../controllers/orders');

const router = express.Router();
router.route('').get(controller.readAll);
router.route('').post(controller.add);
router.route('/record/:patientNo').get(controller.record);
router.route('/update').post(controller.update);
router.route('/:orderNo').delete(controller.delete);


module.exports = router;