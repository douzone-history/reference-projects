const dbconn = require('./dbconn');

module.exports = {
    findAll: async function () {
        const conn = dbconn();
        conn.connect();
        const sql = "select user_no, user_name, msg from message order by no;"

        try {
            const result = await conn.query(sql);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    send: async function (message) {
        const conn = dbconn()
        conn.connect();
        const sql = `insert into message values(default,${message.no},'${message.name}','${message.message}')`
        try {
            const result = await conn.query(sql);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    }
}