const dbconn = require('./dbconn');

module.exports = {
    findAll: async function () {
        const conn = dbconn();
        conn.connect();
        const sql = `select b.no as no,
                            b.name as name,
                            b.registration_no as registration_no,
                            b.cellphone as cellphone,
                            b.address as address,
                            b.insurance as insurance,
                            b.memo as memo,
                            b.detailaddress as detailaddress,
                            b.zipcode as zipcode,
                            b.visit as visit,
                            a.no as "orderNo",
                            a.member_no as member_no,
                            a.reg_date as reg_date,
                            a.nurse_message as nurse_message,
                            a.progress as progress,
                            a.price as price
                    from orders a , patient b where (b.no = a.patient_no) and (current_date = date(a.reg_date)) order by a.no;`
        try {
            const result = await conn.query(sql);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    add: async function (patient, nurseMemo, memberNo) {
        const conn = dbconn()
        conn.connect();
        const sql = `insert into orders values(default,${memberNo},${patient.no},now(),'${nurseMemo}','진료대기',0)`
        const sql2 = "select * from orders order by no desc limit 1"
        try {
            await conn.query(sql);
            const result = await conn.query(sql2);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    update: async function (patient) {
        const conn = dbconn();
        conn.connect();
        
        const sql = `update orders 
                     set progress = '${patient.progress}',
                         price = '${patient.price ? patient.price : 0}'
                     where no = ${patient.orderNo}
                     and (current_date = date(reg_date))`
        try {
            await conn.query(sql);
            if(patient.progress === '완료') {
                const sql2 = `update patient set visit = true where no = '${patient.patientNo}'`
                await conn.query(sql2);
            }
            
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    delete: async function (no) {
        const conn = dbconn();
        conn.connect();

        const sql = `delete from orders where no = ${no}`
        try {
            await conn.query(sql);
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    record: async function (no) {
        const conn = dbconn();
        conn.connect();
        
        const sql = `select distinct on(b.reg_date) a.no as "orderNo", d.name as memberName, b.no, b.reg_date, c.name, b.doctor_message
                     from orders a, clinic b, history c, member d
                     where a.patient_no = ${no}
                     and a.no = b.orders_no
                     and b.no = c.clinic_no
                     and c.priority = '주'
                     and d.no = b.member_no
                     order by b.reg_date desc`;

        try {
            const results = await conn.query(sql);
            return results.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    }
}