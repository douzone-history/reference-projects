const dbconn = require('./dbconn');

module.exports = {
    add: async function(medicines) {
        let clinicNo = medicines[0];
        let medicine = medicines[1];

        for(var i = 0; i < medicine.length-1; i++) {
            const conn = dbconn();
            conn.connect();
            const sql = `insert into prescription values(default, ${clinicNo}, '${medicine[i].dose}', '${medicine[i].daily_dose}', '${medicine[i].total_dose}', '${medicine[i].itemSeq}', '${medicine[i].itemName}')`

            try {
                await conn.query(sql);
            } catch (err) {
                console.error(err);
            } finally {
                conn.end();
            }
        }
    }
}