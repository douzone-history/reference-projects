const dbconn = require('./dbconn');

module.exports = {
    findAll: async function () {
        const conn = dbconn();
        conn.connect();
        const sql = "select * from patient order by name ,registration_no;"
        try {
            const result = await conn.query(sql);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    find: async function (division,keyword) {
        const conn = dbconn();
        conn.connect();
        let sql = '';
        if(division == 'all') {
            sql = `select * from patient where name like '%${keyword}%' or registration_no like '%${keyword}%'`
        } else {
            sql = `select * from patient where ${division} like '%${keyword}%'`
        }

        try {
            const results = await conn.query(sql);
            return results.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }

    },
    add: async function (patient) { 
        const conn = dbconn()
        conn.connect();
        patient.insurance == 'true' ? patient.insurance = true : patient.insurance = false;
        const sql = `insert into patient values(default,'${patient.name}',  '${patient.registration_no}',  '${patient.cellphone}', '${patient.address}', ${patient.insurance} ,'${patient.memo? patient.memo : ''}','${patient.detailaddress}',${patient.zipcode}, false)`
        const sql2 = `select * from patient order by no desc limit 1`
        try {
            await conn.query(sql);
            const result = await conn.query(sql2);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }

    },
    update: async function(patient) {
        const conn = dbconn();
        conn.connect();
        patient.insurance == '있음' ? patient.insurance = true : patient.insurance = false;
        const sql = `update patient set no ='${patient.no}', name = '${patient.name}', registration_no='${patient.registration_no}',cellphone='${patient.cellphone}',address='${patient.address}', insurance='${patient.insurance}', detailaddress='${patient.detailaddress}', zipcode='${patient.zipcode}' where no='${patient.no}'`
        try {
            const result = await conn.query(sql);
            return result;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    read: async function(patientNo) {
        const conn = dbconn();
        conn.connect();
        const sql = `select * from patient a, orders b where a.no = ${patientNo} and b.patient_no = ${patientNo} and date(b.reg_date) = current_date`;
        try {
            const result = await conn.query(sql);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    findByNo: async function (no) {
        const conn = dbconn();
        conn.connect();
        const sql = `select * from patient where no= ${no}`
        try {
            const result = await conn.query(sql);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
}
