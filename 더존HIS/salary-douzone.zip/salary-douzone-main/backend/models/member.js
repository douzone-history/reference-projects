const dbconn = require('./dbconn');

module.exports = {
    findAll: async function () {
        const conn = dbconn();
        conn.connect();
        const sql = "select * from member where role not in ('admin') order by no;"

        try {
            const result = await conn.query(sql);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    create: async function ({ url, member }) {
        const conn = dbconn();
        conn.connect();
        const dsql = `insert into member 
        values(default, '${member.name}',
        (select 'D' || trim(to_char(now(), 'YYMM'))||trim(to_char((select count(*) from member where extract (YEAR from hire_date) = extract(YEAR from now()) and EXTRACT (MONTH FROM hire_date) = extract(MONTH FROM now()))+1,'00'))),
        (select 'D' || trim(to_char(now(), 'YYMM'))||trim(to_char((select count(*) from member where extract (YEAR from hire_date) = extract(YEAR from now()) and EXTRACT (MONTH FROM hire_date) = extract(MONTH FROM now()))+1,'00'))),
        '${member.registration_no}',
        '${member.email}',
        '${member.cellphone}',
        '${member.role}',
        '${url}',
        '${member.address}',
        'true',
        '${member.zipcode}',
        '${member.detailaddress}',
        '${member.hire_date}', null)`;

        const nsql = `insert into member 
        values(default, '${member.name}', (select 'N' || trim(to_char(now(), 'YYMM'))||trim(to_char((select count(*) from member where extract (YEAR from hire_date) = extract(YEAR from now()) and EXTRACT (MONTH FROM hire_date) = extract(MONTH FROM now()))+1,'00'))), (select 'N' || trim(to_char(now(), 'YYMM'))||trim(to_char((select count(*) from member where extract (YEAR from hire_date) = extract(YEAR from now()) and EXTRACT (MONTH FROM hire_date) = extract(MONTH FROM now()))+1,'00'))), '${member.registration_no}', '${member.email}', '${member.cellphone}', '${member.role}', '${url}', '${member.address}', 'true', '${member.zipcode}', '${member.detailaddress}', '${member.hire_date}', null)`;

        const selectSql = 'select * from member order by no desc limit 1';

        try {
            await conn.query(member.role == 'doctor' ? dsql : nsql);
            const result = await conn.query(selectSql);

            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    find: async function (division, keyword) {
        const conn = dbconn();
        conn.connect();
        let sql = '';
        if (division == 'all') {
            sql = `select * from member where name like '%${keyword}%' or id like '%${keyword}%'`
        } else {
            sql = `select * from member where ${division} like '%${keyword}%'`
        }

        try {
            const results = await conn.query(sql);
            return results.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    update: async function ({ url, member }) {
        const conn = dbconn();
        conn.connect();

        const sql = member.working === 'true' ?
            `update member set name = '${member.name}', password = '${member.password}', working = '${member.working}', profile = '${url}', registration_no = '${member.registration_no}', email = '${member.email}', cellphone = '${member.cellphone}', address='${member.address}', zipcode='${member.zipcode}', detailaddress='${member.detailaddress}' where no = '${member.no}'` :
            `update member set working='${member.working}', retire_date = '${member.retire_date}' where no = '${member.no}'`

        try {
            const result = await conn.query(sql);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    findByIdAndPW: async function (user) {
        const conn = dbconn();
        conn.connect();
        const sql = `select * from member where id= '${user.id}' and password='${user.password}'`
        try {
            const result = await conn.query(sql);
            if (result.rowCount == 0) {
                return null;
            }

            if (result.rows[0].working === true) {
                return result.rows
            } else {
                return 'retired';
            }

        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    findByNo: async function (no) {
        const conn = dbconn();
        conn.connect();
        const sql = `select * from member where no= ${no}`
        try {
            const result = await conn.query(sql);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    }
}