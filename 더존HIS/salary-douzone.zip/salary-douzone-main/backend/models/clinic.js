const dbconn = require('./dbconn')

module.exports = {
    add: async function (patient) {
        const conn = dbconn()
        conn.connect();
        const sql = `insert into clinic values(default, ${patient.member_no}, now(), '${patient.doctor_message}', '${patient.mention}', ${patient.orderNo})`
        const sql2 = "select * from clinic order by no desc limit 1"
        try {
            await conn.query(sql);
            const result = await conn.query(sql2);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    pay: async function(patient) {
        const conn = dbconn()
        conn.connect();
        const sql = `select a.insurance, c.mention, d.cure_no, e.no
                     from patient a 
                     left join orders b
                     on a.no = b.patient_no
                     left join clinic c
                     on b.no = c.orders_no
                     left join clinic_cure d
                     on c.no = d.clinic_no
                     left join prescription e
                     on c.no = e.clinic_no
                     where a.no = ${patient.no}
                     and (current_date = c.reg_date)`
        try {
            const result = await conn.query(sql);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    },
    detail: async function(no) {
        const conn = dbconn()
        conn.connect();
        const sql = `select a.medicine_name, b.name as disease_name, d.name as cure_name
                     from prescription a, history b, clinic_cure c, cure d
                     where a.clinic_no = ${no}
                     and b.clinic_no = ${no}
                     and c.clinic_no = ${no}
                     and c.cure_no = d.no`
        try {
            const result = await conn.query(sql);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    }
}