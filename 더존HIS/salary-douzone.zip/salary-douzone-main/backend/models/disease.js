const fs = require('fs');
const util = require('util');
const path = require('path');


module.exports = {
    findAll: async function() {
        try {
            const readFile = util.promisify(fs.readFile).bind(fs);
            const data = await readFile(path.resolve('.', 'backend', 'public', 'disease.json'), 'utf8');
            return JSON.parse(data);
        } catch(e) {
            console.error(e);
        }
    },
    find: async function(diseaseNo) {
        const conn = dbconn()
        conn.connect();
        const sql = "select * from disease where no="+diseaseNo;

        try {
            const result = await conn.query(sql);
            return result.rows;
        } catch (err) {
            console.error(err);
        } finally {
            conn.end();
        }
    }
}