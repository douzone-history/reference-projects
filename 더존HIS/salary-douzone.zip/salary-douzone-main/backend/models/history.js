const dbconn = require('./dbconn');

module.exports = {
    add: async function(diseases) {
        let clinicNo = diseases[0];
        let disease = diseases[1];
        for(var i = 0; i < disease.length-1; i++) {
            const conn = dbconn();
            conn.connect();
            const sql = `insert into history values(default, '${disease[i].sickNm}', '${disease[i].sickCd}', ${clinicNo}, '${disease[i].priority}')`

            try {
                await conn.query(sql);
            } catch (err) {
                console.error(err);
            } finally {
                conn.end();
            }
        }
    }
}