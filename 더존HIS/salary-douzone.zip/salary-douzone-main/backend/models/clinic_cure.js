const dbconn = require('./dbconn');

module.exports = {
    add: async function (cures) {
        let clinicNo = cures[0];
        let cure = cures[1];

        if (cure.injection) {
            const conn = dbconn();
            conn.connect();
            const sql = `insert into clinic_cure values(1, ${clinicNo})`

            try {
                await conn.query(sql);
            } catch (err) {
                console.error(err);
            } finally {
                conn.end();
            }
        }
        if (cure.dressing) {
            const conn = dbconn();
            conn.connect();
            const sql = `insert into clinic_cure values(2, ${clinicNo})`

            try {
                await conn.query(sql);
            } catch (err) {
                console.error(err);
            } finally {
                conn.end();
            }
        }
        if (cure.gips) {
            const conn = dbconn();
            conn.connect();
            const sql = `insert into clinic_cure values(3, ${clinicNo})`

            try {
                await conn.query(sql);
            } catch (err) {
                console.error(err);
            } finally {
                conn.end();
            }
        }
        if (cure.physics) {
            const conn = dbconn();
            conn.connect();
            const sql = `insert into clinic_cure values(4, ${clinicNo})`

            try {
                await conn.query(sql);
            } catch (err) {
                console.error(err);
            } finally {
                conn.end();
            }
        }
        if (cure.xray) {
            const conn = dbconn();
            conn.connect();
            const sql = `insert into clinic_cure values(5, ${clinicNo})`

            try {
                await conn.query(sql);
            } catch (err) {
                console.error(err);
            } finally {
                conn.end();
            }
        }
    }
}