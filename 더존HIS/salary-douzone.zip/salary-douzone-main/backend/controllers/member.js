const model = require('../models/member');
const fs = require('fs');
const path = require('path');

module.exports = {
    readAll: async function (req, res, next) {
        try {
            const results = await model.findAll();
            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
    addMember: async function (req, res, next) {
        try {
            const profile = req.file;

            let url = '';
            if (!profile) {
                url = '/default/profile.jpg'
            } else {
                const content = fs.readFileSync(profile.path);
                const storeDirectory = path.join(path.dirname(require.main.filename), process.env.STATIC_RESOURCES_DIRECTORY, process.env.UPLOADIMAGE_STORE_LOCATION);
                const storePath = path.join(storeDirectory, profile.filename) + path.extname(profile.originalname);
                url = path.join(process.env.UPLOADIMAGE_STORE_LOCATION, profile.filename) + path.extname(profile.originalname);

                fs.existsSync(storeDirectory) || fs.mkdirSync(storeDirectory);
                fs.writeFileSync(storePath, content, { flag: 'w+' });
                fs.unlinkSync(profile.path);
            }

            const result = await model.create({
                url: url.replace(/\\/gi, '/'),
                member: req.body || ''
            });

            res
                .status(200)
                .send({
                    result: 'success',
                    data: result,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
    search: async function (req, res, next) {
        let results;
        let division = req.params.division;
        let keyword = req.params.keyword || '';

        try {
            if (division === 'all' && keyword === '') {
                results = await model.findAll();
            } else {
                results = await model.find(division, keyword);
            }

            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err)
        }
    },
    update: async function (req, res, next) {
        try {
            const profile = req.file;
            let url = '';
            if (!profile) {
                url = req.body.profile;
            } else {
                const content = fs.readFileSync(profile.path);
                const storeDirectory = path.join(path.dirname(require.main.filename), process.env.STATIC_RESOURCES_DIRECTORY, process.env.UPLOADIMAGE_STORE_LOCATION);
                const storePath = path.join(storeDirectory, profile.filename) + path.extname(profile.originalname);
                url = path.join(process.env.UPLOADIMAGE_STORE_LOCATION, profile.filename) + path.extname(profile.originalname);

                fs.existsSync(storeDirectory) || fs.mkdirSync(storeDirectory);
                fs.writeFileSync(storePath, content, { flag: 'w+' });
                fs.unlinkSync(profile.path);
            }

            const results = await model.update({
                url: url.replace(/\\/gi, '/'),
                member: req.body || ''
            });

            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
    login: async function (req, res, next) {
        try {
            const result = await model.findByIdAndPW(req.body);

            res
                .status(200)
                .send({
                    result: 'success',
                    data: result,
                    message: null
                })

        } catch (err) {
            next(err);
        }
    },
    read: async function (req, res, next) {
        try {
            const user = await model.findByNo(req.params.no);

            res
                .status(200)
                .send({
                    result: 'success',
                    data: user,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
    updateInfo: async function (req, res, next) {
        try {
            const results = await model.update(req.body);

            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    }

}