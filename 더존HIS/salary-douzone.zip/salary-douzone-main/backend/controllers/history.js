const model = require('../models/history');

module.exports = {
    add: async function(req, res, next) {
        try {
            const results = await model.add(req.body);
            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    }
}