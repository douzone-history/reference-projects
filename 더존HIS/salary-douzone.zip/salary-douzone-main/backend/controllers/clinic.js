const model = require('../models/clinic');

module.exports = {
    add: async function (req, res, next) {
        try {
            const result = await model.add(req.body);
            res
                .status(200)
                .send({
                    result: 'success',
                    data: result,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
    pay: async function (req, res, next) {
        var cure_no = []
        var prescription = []
        var sum = 0;
        try {
            const results = await model.pay(req.body);
            const insurance = results[0].insurance
            const mention = results[0].mention;

            for(var i = 0; i < results.length; i++) {
                if(results[i].cure_no != null){
                    cure_no[i] = results[i].cure_no;
                }
                if(results[i].no != null){
                    prescription[i] = results[i].no;
                }
            }

            cure_no = new Set(cure_no);
            cure_no = [...cure_no];
            for (var i = 0; i < cure_no.length; i++) {
                if (cure_no[i] == 1) {
                    sum += 1000
                } else if (cure_no[i] == 2) {
                    sum += 2000
                } else if (cure_no[i] == 3) {
                    sum += 4000
                } else if (cure_no[i] == 4) {
                    sum += 8000
                } else if (cure_no[i] == 5) {
                    sum += 16000
                }
            }

            prescription = new Set(prescription);
            prescription = [...prescription];

            var basic = req.body.age < 7 || req.body.age > 65 ? 5000 : 7000
            var nationBasic = insurance ? basic * 0.25 : 0
            var _cure = sum
            var nationCure = insurance ? _cure * 0.25 : 0
            var pres = prescription.length * 3000
            var nationPres = insurance ? pres * 0.25 : 0
            var total = (req.body.age < 7 || req.body.age > 65 ? 5000 : 7000) + (prescription.length * 3000) + sum
            var nationTotal = insurance ? total * 0.25 : 0;
            var surcharge = (parseInt(req.body.reg_date.substring(11,13)) + 9) >= 18 ? (total*0.3) : 0;
            var nationSurcharge = insurance ? surcharge * 0.25 : 0;

            if (insurance) {
                basic -= nationBasic;
                surcharge -= nationSurcharge;
                _cure -= nationCure;
                pres -= nationPres;
                total -= nationTotal;
            }

            const pay = ([
                { menu: '기본 진료비', selfprice: basic.toLocaleString('ko-KR'), nationprice: nationBasic.toLocaleString('ko-KR') },
                { menu: '야간 할증료', selfprice: surcharge.toLocaleString('ko-KR'), nationprice:nationSurcharge.toLocaleString('ko-KR')},
                { menu: '시술 처치료', selfprice: _cure.toLocaleString('ko-KR'), nationprice: nationCure.toLocaleString('ko-KR') },
                { menu: '투약 조제료', selfprice: pres.toLocaleString('ko-KR'), nationprice: nationPres.toLocaleString('ko-KR') },
                { menu: '합계', selfprice: (total + surcharge).toLocaleString('ko-KR'), nationprice: (nationTotal + nationSurcharge).toLocaleString('ko-KR') },
            ])
            const newResults = [mention, pay];

            res
                .status(200)
                .send({
                    result: 'success',
                    data: newResults,
                    message: null
                })
        } catch (err) {
            next(err)
        }
    },
    detail: async function (req, res, next) {
        var medicine = [];
        var disease = [];
        var cure = [];
        var detail = [];

        try {
            const results = await model.detail(req.params.clinicNo);
            for (var i = 0; i < results.length; i++) {
                medicine[i] = results[i].medicine_name;
                disease[i] = results[i].disease_name;
                cure[i] = results[i].cure_name;
            }
            medicine = new Set(medicine);
            medicine = [...medicine];

            disease = new Set(disease);
            disease = [...disease]

            cure = new Set(cure);
            cure = [...cure]

            const count = Math.max(medicine.length, disease.length, cure.length);
            for (var i = 0; i < count; i++) {
                detail[i] = {
                    medicine: medicine[i] || '',
                    disease: disease[i] || '',
                    cure: cure[i] || ''
                }
            }

            res
                .status(200)
                .send({
                    result: 'success',
                    data: detail,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    }
}