const model = require('../models/orders');

module.exports = {
    readAll: async function (req, res, next) {
        try {
            const results = await model.findAll();
            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
    add: async function (req, res, next) {
        try {
            const selectpatient = req.body[0];
            const nurseMemo = req.body[1];
            const memberNo = req.body[2];
            const result = await model.add(selectpatient, nurseMemo, memberNo);
            res
                .status(200)
                .send({
                    result: 'success',
                    data: result,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
    update: async function (req, res, next) {
        try {
            const results = await model.update(req.body);
            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
    delete: async function (req, res, next) {
        try {
            const results = await model.delete(req.params.orderNo);
            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
    record: async function (req, res, next) {
        try {
            const results = await model.record(req.params.patientNo);
            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    }
}