const model = require('../models/disease');

module.exports = {
    readAll: async function(req, res, next) {
        try {
            const results = await model.findAll();
            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
    read: async function(req, res, next) {
        try {
            const result = await model.find(req.params.diseaseNo);

            res
                .status(200)
                .send({
                    result: 'success',
                    data: result,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    }
}