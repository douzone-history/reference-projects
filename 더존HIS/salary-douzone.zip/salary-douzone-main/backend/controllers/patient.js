const model = require('../models/patient');

module.exports = {
    readAll: async function (req, res, next) {
        try {
            const results = await model.findAll();
            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
    add: async function (req, res, next) {
        try {
            const result = await model.add(req.body);
            res
                .status(200)
                .send({
                    result: 'success',
                    data: result,
                    message: null
                })
        } catch (err) {
            next(err);
        }

    },
    search: async function(req, res, next) {
        let results;
        let division = req.params.division;
        let keyword = req.params.keyword || '';

        try {
            if(division === 'all' && keyword === '') {
                results = await model.findAll();
            } else {
                results = await model.find(division, keyword); 
            }

            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err)
        }
    },
    update : async function(req, res, next) {
        try {
            const results = await model.update(req.body);
            res
                .status(200)
                .send({
                    result: 'success',
                    data: results,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
    getInfo: async function(req, res, next) {
        try {
            const patientNo = parseInt(req.params.patientNo);
            const result = await model.read(patientNo);
            res
                .status(200)
                .send({
                    result: 'success',
                    data: result,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    }, 
    read: async function (req, res, next) {
        try {
            const user = await model.findByNo(req.params.no);

            res
                .status(200)
                .send({
                    result: 'success',
                    data: user,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    },
}