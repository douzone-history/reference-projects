const model = require('../models/clinic_cure');

module.exports = {
    add: async function(req, res, next) {
        try {
            const result = await model.add(req.body);
            res
                .status(200)
                .send({
                    result: 'success',
                    data: result,
                    message: null
                })
        } catch (err) {
            next(err);
        }
    }
}