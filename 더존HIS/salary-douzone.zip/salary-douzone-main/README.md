# 더조은HIS(DOUZONE=HIS)

더조은HIS(DOUZONE=HIS)는 환자가 병원에 왔을 때 접수하고, 의사가 진료 및 처방을 내리고, 진료가 끝난 후 수납을 하는 병원의 전박적인 업무를 자동화한 작은범위의 서브시스템으로 구성된 HIS(Healthcare Information System) 입니다.

## 목차
- [개발환경 및 사용언어](#개발환경-및-사용-언어)
- [데모](#데모)
- [사용 방법](#사용-방법)
- [버그 리포트 및 문의](#버그-리포트-및-문의)
- [라이센스](#라이센스)

## 개발환경 및 사용 언어
``backend``
- Visual Studio Code
- Node.js 14.17.1
- PostgreSQL 12.7
- Express 4.17.1
 
``frontend``
- Visual Studio Code
- React 17.0.2

``dependencies``
- @material-ui
- multer
- pg
- react-daum-postcode
- react-hook-form
- react-router-dom
- socket.io
- swagger
- css/sass/file loader

## 데모
별도의 설치없이 http://www.douzonehis.shop 로 접속하여 이용할 수 있습니다.

## 사용 방법
1. repository clone
> 원하는 디렉토리에 더조은HIS repository를 클론합니다.
```bash
git clone https://github.com/salary-douzone/salary-douzone.git
```
2. module 및 라이브러리 설치
> 빌드를 위한 패키지 모듈을 설치합니다.
```bash
npm install
```
3. application 실행
> localhost:9999로 접속하여 실행 할 수 있습니다.
```bash
npm run dev
```

## 버그 리포트 및 문의
만약 사용 중, 버그나 오류 및 에러를 발견하신다면 깃허브의 [issues](https://github.com/salary-douzone/salary-douzone/issues)에 버그를 제보 해주세요.

## 라이센스
더조은HIS(DOUZONE=HIS) is released under the [MIT license](https://github.com/salary-douzone/salary-douzone/blob/develop/LICENSE).