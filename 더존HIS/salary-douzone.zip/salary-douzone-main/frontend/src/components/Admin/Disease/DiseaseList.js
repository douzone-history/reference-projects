import React, { Fragment, useEffect, useState } from 'react';
import DiseaseListItems from './DiseaseListItems';

export default function DiseaseList({ diseases, getDiseaseRow, division, keyword }) {
    const [filterDisease, setFilterDisease] = useState([]);

    useEffect(() => {
        if (division === 'all') {
            setFilterDisease(diseases.filter(disease =>
                disease.sickCd.toUpperCase().indexOf(keyword.toUpperCase()) != -1 || disease.sickNm.toUpperCase().indexOf(keyword.toUpperCase()) != -1));
        } else if (division === 'sickCd') {
            setFilterDisease(diseases.filter(disease =>
                disease.sickCd.toUpperCase().indexOf(keyword.toUpperCase()) != -1));
        } else if (division === 'sickNm') {
            setFilterDisease(diseases.filter(disease =>
                disease.sickNm.toUpperCase().indexOf(keyword.toUpperCase()) != -1));
        }
    }, [division, keyword])

    return (
        <Fragment>
            {
                keyword == '' ?
                    <DiseaseListItems items={diseases}
                        getDiseaseRow={getDiseaseRow} />
                    :
                    <DiseaseListItems items={filterDisease}
                        getDiseaseRow={getDiseaseRow} />
            }
        </Fragment>
    );
}