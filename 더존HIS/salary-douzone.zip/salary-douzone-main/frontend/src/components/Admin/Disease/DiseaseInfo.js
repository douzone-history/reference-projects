import Box from '@material-ui/core/Box';
import blue from '@material-ui/core/colors/blue';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';
import React, { Fragment } from 'react';

const columns = [
    { id: 'sickCd', label: '코드' },
    { id: 'sickNm', label: '이름' },
]

const useStyles = makeStyles(() => ({
    container: {
        border: '1px solid rgba(133,133, 133, 0.5)',
        borderRadius: 5,
    },
    head: {
        backgroundColor: blue[500],
        color: 'white',
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'center',
        width: '30%',
    },
    box: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    }
}));

export default function DiseaseInfo({ disease }) {
    const classes = useStyles();

    return (
        <Fragment>
            <Box className={classes.box}>
                <TableContainer
                    className={classes.container}>
                    <Table>
                        {columns.map((column, index) => (
                            <TableBody key={index}>
                                <TableRow>
                                    <TableCell className={classes.head}>
                                        {column.label}
                                    </TableCell>
                                    <TableCell>
                                        {disease[column.id]}
                                    </TableCell>
                                </TableRow>
                            </TableBody>
                        ))}
                    </Table>
                </TableContainer>
            </Box>
        </Fragment>
    );
}