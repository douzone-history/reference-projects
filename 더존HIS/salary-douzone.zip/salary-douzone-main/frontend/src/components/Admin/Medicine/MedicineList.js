import React, { Fragment, useEffect, useState } from 'react';
import MedicineListItems from './MedicineListItems';

export default function MedicineList({ medicines, getMedicineRow, division, keyword }) {
    const [filterMedicine, setFilterMedicine] = useState([]);

    useEffect(() => {
        if (division === 'all') {
            setFilterMedicine(medicines.filter(medicine =>
                medicine.itemSeq.indexOf(keyword) != -1 || medicine.itemName.toUpperCase().indexOf(keyword.toUpperCase()) != -1));
        } else if (division === 'itemSeq') {
            setFilterMedicine(medicines.filter(medicine =>
                medicine.itemSeq.indexOf(keyword) != -1));
        } else if (division === 'itemName') {
            setFilterMedicine(medicines.filter(medicine =>
                medicine.itemName.toUpperCase().indexOf(keyword.toUpperCase()) != -1));
        }
    }, [division, keyword])

    return (
        <Fragment>
            {
                keyword == '' ?
                    <MedicineListItems items={medicines}
                        getMedicineRow={getMedicineRow} />
                    :
                    <MedicineListItems items={filterMedicine}
                        getMedicineRow={getMedicineRow} />
            }
        </Fragment>
    );
}