import Box from '@material-ui/core/Box';
import blue from '@material-ui/core/colors/blue';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';
import React, { Fragment } from 'react';

const columns = [
    { id: 'itemSeq', label: '코드' },
    { id: 'itemName', label: '이름' },
    { id: 'entpName', label: '업체명' },
    { id: 'efcyQesitm', label: '효능' },
    { id: 'atpnQesitm', label: '주의사항' },
    { id: 'seQesitm', label: '부작용' }
]

const useStyles = makeStyles(() => ({
    container: {
        border: '1px solid black',
        borderRadius: 5
    },
    head: {
        backgroundColor: blue[500],
        color: 'white',
        padding: 10,
        textAlign: 'center',
        width: '20%',
    },
    box: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    img: {
        width: 250,
        height: 200,
        margin: 20,
        border: '1px solid black',
    },
    info: {
        padding: 10,
        '& p': {
            margin: 4,
        },
    },
}));

export default function MedicineInfo({ medicine }) {
    const classes = useStyles();

    return (
        <Fragment>
            <Box className={classes.box}>
                <img src={medicine.itemImage} className={classes.img} alt='이미지 없음' />
            </Box>
            <Box className={classes.box}>
                <TableContainer
                    className={classes.container}>
                    <Table>
                        {columns.map((column, index) => (
                            <TableBody key={index}>
                                <TableRow>
                                    <TableCell className={classes.head}>
                                        {column.label}
                                    </TableCell>
                                    <TableCell className={classes.info}>
                                        <span dangerouslySetInnerHTML={{ __html: medicine[column.id] }} />
                                    </TableCell>
                                </TableRow>
                            </TableBody>
                        ))}
                    </Table>
                </TableContainer>
            </Box>
        </Fragment>
    );
}