import MenuItem from '@material-ui/core/MenuItem';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import React, { useState } from 'react';

const menus = [
  { value: 'all', label: '전체' },
  { value: 'itemSeq', label: '코드' },
  { value: 'itemName', label: '이름' }
];

const useStyles = makeStyles((theme) => ({
  root: {
    '& .MuiTextField-root': {
      width: '100px',
    },
    display: 'flex',
  },
}));

export default function MedicineSelect({ notifyDivision }) {
  const classes = useStyles();
  const [menu, setMenu] = useState('all');

  const handleChange = (e) => {
    notifyDivision(e.target.value);
    setMenu(e.target.value);
  };

  return (
    <div className={classes.root}>
      <TextField
        select
        value={menu}
        onChange={handleChange}
        variant="outlined"
      >
        {menus.map((option) => (
          <MenuItem key={option.value} value={option.value}>
            {option.label}
          </MenuItem>
        ))}
      </TextField>
    </div>
  );
}