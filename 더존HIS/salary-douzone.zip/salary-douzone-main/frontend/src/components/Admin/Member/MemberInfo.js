import Box from '@material-ui/core/Box';
import Button from '@material-ui/core/Button';
import Checkbox from '@material-ui/core/Checkbox';
import blue from '@material-ui/core/colors/blue';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormGroup from '@material-ui/core/FormGroup';
import IconButton from '@material-ui/core/IconButton';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import React, { Fragment, useEffect, useState } from 'react';
import DaumPostcode from "react-daum-postcode";
import { Controller, useForm } from "react-hook-form";
import styles from '../../../assets/scss/member.scss';
import moment from 'moment';

const useStyles = makeStyles((theme) => ({
    input: {
        display: 'none',
    },
    box: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    buttons: {
        margin: 10,
        backgroundColor: blue[500],
        color: 'white',
        fontWeight: 'bold',
        "&:hover": {
            backgroundColor: blue[500]
        }
    },
    paper: {
        backgroundColor: theme.palette.background.paper,
        border: '2px solid #000',
        boxShadow: theme.shadows[5],
        padding: theme.spacing(2, 4, 3),
    },
    textField: {
        display: 'flex',
        marginBottom: 20,
    },
    retireBtn: {
        backgroundColor: blue[500],
        color: 'white',
        marginTop: -65,
        float: 'right',
        padding: 10,
        "&:hover": {
            backgroundColor: blue[500]
        }
    },
    closeBtn: {
        float: 'right'
    }
}));

export default function MemberInfo({ modifyMember, member }) {
    const classes = useStyles();
    const { register, handleSubmit, control, setValue, formState: { errors } } = useForm();
    const [open, setOpen] = useState(false);
    const [post, setPost] = useState(false);
    const [check, setCheck] = useState('');
    const [inputs, setInputs] = useState({
        name: '',
        email: '',
        id: '',
        password: '',
        address: '',
        role: '',
        zipcode: '',
        detailaddress: '',
        working: '',
        registration_no: '',
        cellphone: '',
        profile: '',
        url: '',
        retire_date: ''
    });

    let hire_date = '';
    if (inputs.hire_date) {
        hire_date = moment(inputs.hire_date).format('YYYY-MM-DD');
    }

    useEffect(() => {
        setInputs(member);
        setCheck(member.role);
        setValue('name', member.name)
        setValue('email', member.email)
        setValue('detailaddress', member.detailaddress)
        setValue('cellphone', member.cellphone)
    }, [member]);

    const handleClickOpen = () => {
        setOpen(true);
        setPost(true);
    };

    const onCompletePost = (data) => {
        setInputs({
            ...inputs,
            address: data.address,
            zipcode: data.zonecode
        });
        setPost(false);
    }

    const handleRetire = () => {
        setInputs({
            ...inputs,
            working: false,
            retire_date: moment().format('YYYY-MM-DD')
        })
        modifyMember.updateMember({ ...inputs, working: false, retire_date: moment().format('YYYY-MM-DD') });
    }

    const handleChange = (e) => {
        const { value, name } = e.target;

        if (name == 'role') {
            if (value == 'doctor') {
                setCheck('doctor');
            } else if (value == 'nurse') {
                setCheck('nurse');
            }
        }

        if (name != 'profile') {
            setInputs({
                ...inputs,
                [name]: value
            });
        } else if (e.target.files[0]) {
            const reader = new FileReader();
            reader.addEventListener('load', () => {
                setInputs({
                    ...inputs,
                    profile: reader.result,
                    url: e.target.files[0]
                });
            });
            reader.readAsDataURL(e.target.files[0]);
        }
    }

    return (
        <Fragment>
            {inputs.working ?
                <Button onClick={handleRetire} className={classes.retireBtn}>
                    퇴사
                </Button>
                : null}

            <form className={styles.Form} onSubmit={handleSubmit(() => modifyMember.updateMember(inputs))} onChange={handleChange}>
                <Box className={classes.box}>
                    {inputs.working ?
                        <input type="file" accept="image/*" name="profile" id="profile" onChange={handleChange} className={classes.input} />
                        : null}
                    <label htmlFor="profile">
                        <IconButton aria-label="upload picture" component="span">
                            <img src={inputs.profile} />
                        </IconButton>
                    </label>
                </Box>
                <Box className={classes.box}>
                    <FormGroup row value={check} onChange={handleChange}>
                        <FormControlLabel
                            control={
                                <Controller
                                    control={control}
                                    inputRef={register()}
                                    render={() => (
                                        inputs.working ?
                                            <Checkbox
                                                style={{ color: blue[500] }}
                                                name="role"
                                                checked={'doctor' == check}
                                                value='doctor'
                                                disabled
                                            /> :
                                            <Checkbox
                                                style={{ color: '#dddddd' }}
                                                name="role"
                                                checked={'doctor' == check}
                                                value='doctor'
                                                disabled
                                            />
                                    )}
                                />
                            }
                            label='의사'
                        />
                        <FormControlLabel
                            control={
                                <Controller
                                    control={control}
                                    inputRef={register()}
                                    render={() => (
                                        inputs.working ?
                                            <Checkbox
                                                style={{ color: blue[500] }}
                                                name="role"
                                                checked={'nurse' == check}
                                                value='nurse'
                                                disabled
                                            />
                                            :
                                            <Checkbox
                                                style={{ color: '#dddddd' }}
                                                name="role"
                                                checked={'nurse' == check}
                                                value='nurse'
                                                disabled
                                            />
                                    )}
                                />
                            }
                            label='간호사'
                        />
                    </FormGroup>
                </Box>

                <div className={styles.textField}>
                    <TextField
                        className={classes.textField}
                        margin='normal'
                        variant='outlined'
                        placeholder='이름'
                        value={inputs.name || ''}
                        autoFocus
                        disabled={!inputs.working}
                        {...register("name", {
                            required: true,
                            pattern: /[가-힣]/g
                        })}
                    />
                    {errors?.name?.type === "required" && <p>이름을 입력해주세요.</p>}
                    {errors?.name?.type === "pattern" && (
                        <p>이름을 정확히 입력해주세요.</p>
                    )}

                    <TextField
                        className={classes.textField}
                        margin='normal'
                        variant='outlined'
                        value={inputs.id || ''}
                        disabled
                    />

                    <TextField
                        type="password"
                        className={classes.textField}
                        margin='normal'
                        variant='outlined'
                        value={inputs.password || ''}
                        disabled
                    />

                    <TextField
                        className={classes.textField}
                        value={inputs.registration_no || ''}
                        variant='outlined'
                        disabled
                        margin='normal'
                    />

                    <TextField
                        className={classes.textField}
                        placeholder='이메일'
                        disabled={!inputs.working}
                        variant='outlined'
                        value={inputs.email || ''}
                        margin='normal'
                        {...register("email", {
                            required: true,
                            pattern: /\d*([a-z])\d*[@]([a-z]+\.)+(com|net|kr)/g
                        })}
                    />
                    {errors?.email?.type === "required" && <p>이메일을 입력해주세요.</p>}
                    {errors?.email?.type === "pattern" && (
                        <p>이메일을 정확히 입력해주세요.</p>
                    )}

                    {post ? <Dialog open={open}>
                        <DialogTitle>주소검색
                            <Button onClick={() => setOpen(false)} className={classes.closeBtn}>
                                x
                            </Button>
                        </DialogTitle>
                        <DialogContent>
                            <DaumPostcode onComplete={onCompletePost} style={{ height: '560px', width: '400px' }} />
                        </DialogContent>
                    </Dialog> : null}

                    <div className={styles.AddressBtn}>
                        <TextField
                            placeholder="우편번호"
                            value={inputs.zipcode || ''}
                            variant='outlined'
                            disabled
                            {...register("zipcode", {
                                required: true,
                                value: inputs.zipcode,
                            })}
                        />

                        {inputs.working ?
                            <Button onClick={handleClickOpen}>
                                주소찾기
                            </Button>
                            :
                            <Button disabled style={{ backgroundColor: "#dddddd" }}>
                                주소찾기
                            </Button>
                        }
                    </div>

                    <TextField
                        className={classes.textField}
                        variant='outlined'
                        placeholder='주소'
                        margin='normal'
                        disabled
                        value={inputs.address || ''}
                        {...register("address", {
                            required: true,
                            value: inputs.address
                        })}
                    />
                    {errors?.address?.type === "required" && <p>주소를 입력해주세요.</p>}

                    <TextField
                        className={classes.textField}
                        variant='outlined'
                        placeholder='상세주소'
                        disabled={!inputs.working}
                        value={inputs.detailaddress || ''}
                        margin='normal'
                        {...register("detailaddress", {
                            required: true,
                        })}
                    />
                    {errors?.detailaddress?.type === "required" && <p>상세 주소를 입력해주세요.</p>}

                    <TextField
                        className={classes.textField}
                        variant='outlined'
                        margin="normal"
                        placeholder='전화번호'
                        disabled={!inputs.working}
                        value={inputs.cellphone || ''}
                        {...register("cellphone", {
                            required: true,
                            pattern: (/(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/, "$1-$2-$3")
                        })}
                    />
                    {errors?.cellphone?.type === "required" && <p>전화번호를 입력해주세요.</p>}
                    {errors?.cellphone?.type === "pattern" && (
                        <p>전화번호를 정확히 입력해주세요.</p>
                    )}

                    <TextField
                        className={classes.textField}
                        variant='outlined'
                        value={hire_date}
                        disabled
                        label="입사일"
                        type="date"
                        InputLabelProps={{ shrink: true }}
                    />

                    {!inputs.working ?
                        <TextField
                            className={classes.textField}
                            variant='outlined'
                            value={inputs.retire_date && moment(inputs.retire_date).format('YYYY-MM-DD') || ''}
                            disabled
                            label="퇴사일"
                            InputLabelProps={{ shrink: true }}
                            type="date"
                        />
                        : null}
                    {inputs.working ? <Button type="submit">수정</Button> : null}
                </div>
            </form>
        </Fragment>
    );
}