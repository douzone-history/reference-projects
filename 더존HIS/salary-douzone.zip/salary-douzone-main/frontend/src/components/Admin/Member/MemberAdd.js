import Box from '@material-ui/core/Box';
import Button from '@material-ui/core/Button';
import Checkbox from '@material-ui/core/Checkbox';
import blue from '@material-ui/core/colors/blue';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormGroup from '@material-ui/core/FormGroup';
import IconButton from '@material-ui/core/IconButton';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import React, { Fragment, useState } from 'react';
import DaumPostcode from "react-daum-postcode";
import { Controller, useForm } from "react-hook-form";
import defaultImage from '../../../assets/img/default.jpg';
import styles from '../../../assets/scss/member.scss';
import moment from 'moment';

const useStyles = makeStyles(() => ({
    input: {
        display: 'none',
    },
    box: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    profile: {
        width: 150,
        height: 150,
        borderRadius: 75,
        border: '5px solid #eeeeee',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    textField: {
        display: 'flex',
        marginBottom: 20,
    },
}));

export default function MemberAdd({ modifyMember }) {
    const classes = useStyles();
    const [inputs, setInputs] = useState({
        name: '',
        id: '',
        password: '',
        role: 'doctor',
        registration_no: '',
        email: '',
        address: '',
        detailaddress: '',
        zipcode: '',
        cellphone: '',
        working: true,
        profile: defaultImage,
        url: ''
    });
    const { register, handleSubmit, control, reset, formState: { errors } } = useForm();
    const [open, setOpen] = useState(false);
    const [post, setPost] = useState(false);
    const [check, setCheck] = useState('doctor');

    const handleClickOpen = () => {
        setOpen(true);
        setPost(true);
    };

    const onCompletePost = (data) => {
        setInputs({
            ...inputs,
            address: data.address,
            zipcode: data.zonecode
        });
        setPost(false);
    }

    const handleChange = (e) => {
        const { value, name } = e.target;

        if (name == 'role') {
            if (value == 'doctor') {
                setCheck('doctor');
            } else {
                setCheck('nurse');
            }
        }

        if (name != 'profile') {
            setInputs({
                ...inputs,
                [name]: value
            });
        } else if (e.target.files[0]) {
            const reader = new FileReader();
            reader.addEventListener('load', () => {
                setInputs({
                    ...inputs,
                    profile: reader.result,
                    url: e.target.files[0]
                });
            });
            reader.readAsDataURL(e.target.files[0]);
        }
    }

    const onSubmit = () => {
        modifyMember.addMember({ ...inputs, hire_date: moment().format("YYYY-MM-DD")});
        setInputs({
            ...inputs,
            profile: defaultImage,
            address: '',
            zipcode: '',
            hire_date: moment().format("YYYY-MM-DD")
        });
        reset();
    };

    return (
        <Fragment>
            <form className={styles.Form} onSubmit={handleSubmit(onSubmit)} onChange={handleChange}>
                <Box className={classes.box}>
                    <input type="file" accept="image/*" name="profile" id="profile" onChange={handleChange} className={classes.input} />
                    <label htmlFor="profile">
                        <IconButton aria-label="upload picture" component="span">
                            <img src={inputs.profile} />
                        </IconButton>
                    </label>
                </Box>
                <Box className={classes.box}>
                    <FormGroup row value={check} onChange={handleChange}>
                        <FormControlLabel
                            control={
                                <Controller
                                    control={control}
                                    inputRef={register()}
                                    render={() => (
                                        <Checkbox
                                            style={{ color: blue[500] }}
                                            name="role"
                                            checked={'doctor' == check}
                                            value='doctor'
                                        />
                                    )}
                                />
                            }
                            label='의사'
                        />
                        <FormControlLabel
                            control={
                                <Controller
                                    control={control}
                                    inputRef={register()}
                                    render={() => (
                                        <Checkbox
                                            style={{ color: blue[500] }}
                                            name="role"
                                            checked={'nurse' == check}
                                            value='nurse'
                                        />
                                    )}
                                />
                            }
                            label='간호사'
                        />
                    </FormGroup>
                </Box>

                <div className={styles.textField}>
                    <TextField
                        className={classes.textField}
                        margin='normal'
                        variant='outlined'
                        placeholder='이름'
                        autoFocus
                        {...register("name", {
                            required: true,
                            pattern: /[가-힣]/g
                        })}
                    />
                    {errors?.name?.type === "required" && <p>이름을 입력해주세요.</p>}
                    {errors?.name?.type === "pattern" && (
                        <p>이름을 정확히 입력해주세요.</p>
                    )}

                    <TextField
                        className={classes.textField}
                        placeholder='주민등록번호'
                        variant='outlined'
                        margin='normal'
                        {...register("registration_no", {
                            required: true,
                            pattern: /\d{2}([0]\d|[1][0-2])([0][1-9]|[1-2]\d|[3][0-1])[-]*[1-4]\d{6}/g
                        })}
                    />
                    {errors?.registration_no?.type === "required" && <p>주민등록번호를 입력해주세요.</p>}
                    {errors?.registration_no?.type === "pattern" && (
                        <p>주민등록번호를 정확히 입력해주세요.</p>
                    )}

                    <TextField
                        className={classes.textField}
                        placeholder='이메일'
                        variant='outlined'
                        margin='normal'
                        {...register("email", {
                            required: true,
                            pattern: /\d*([a-z])\d*[@]([a-z]+\.)+(com|net|kr)/g
                        })}
                    />
                    {errors?.email?.type === "required" && <p>이메일을 입력해주세요.</p>}
                    {errors?.email?.type === "pattern" && (
                        <p>이메일을 정확히 입력해주세요.</p>
                    )}

                    {post ? <Dialog open={open}>
                        <DialogTitle>주소검색 <Button onClick={() => setOpen(false)} color="primary">
                            x
                        </Button></DialogTitle>
                        <DialogContent>
                            <DaumPostcode onComplete={onCompletePost} />
                        </DialogContent>
                    </Dialog> : null}

                    <div className={styles.AddressBtn}>
                        <TextField
                            placeholder="우편번호"
                            value={inputs.zipcode}
                            variant='outlined'
                            disabled
                            {...register("zipcode", {
                                required: true,
                                value: inputs.zipcode,
                            })}
                        />

                        <Button onClick={handleClickOpen}>
                            주소찾기
                        </Button>
                    </div>

                    <TextField
                        className={classes.textField}
                        variant='outlined'
                        placeholder='주소'
                        margin='normal'
                        disabled
                        value={inputs.address}
                        {...register("address", {
                            required: true,
                            value: inputs.address
                        })}
                    />
                    {errors?.address?.type === "required" && <p>주소를 입력해주세요.</p>}

                    <TextField
                        className={classes.textField}
                        variant='outlined'
                        placeholder='상세주소'
                        margin='normal'
                        {...register("detailaddress", {
                            required: true,
                        })}
                    />
                    {errors?.detailaddress?.type === "required" && <p>상세 주소를 입력해주세요.</p>}

                    <TextField
                        className={classes.textField}
                        variant='outlined'
                        placeholder='전화번호'
                        {...register("cellphone", {
                            required: true,
                            pattern: (/(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/, "$1-$2-$3")
                        })}
                    />
                    {errors?.cellphone?.type === "required" && <p>전화번호를 입력해주세요.</p>}
                    {errors?.cellphone?.type === "pattern" && (
                        <p>전화번호를 정확히 입력해주세요.</p>
                    )}

                    <Button type="submit">등록</Button>
                </div>
            </form>
        </Fragment>
    );
}