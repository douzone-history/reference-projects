import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import React, { useEffect, useState } from 'react';

const columns = [
  { id: 'no', label: '번호' },
  { id: 'name', label: '이름' },
  { id: 'id', label: '아이디' },
  { id: 'role', label: '구분' },
  { id: 'working', label: '재직여부' },
];

const useStyles = makeStyles({
  cell: {
    textAlign: 'center',
    width: '20%',
  }
});

export default function MemberList({ members, modifyMember, notifyWoriking }) {
  const classes = useStyles();
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [value, setValue] = useState(false);
  const emptyRows = rowsPerPage - Math.min(rowsPerPage, members.length - page * rowsPerPage);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(event.target.value);
    setPage(0);
  };

  useEffect(() => {
    setPage(0);
  }, [members])

  return (
    <Paper>
      <TableContainer>
        <Table aria-label="sticky table">
          <TableHead>
            <TableRow>
              {columns.map((column, index) => (
                <TableCell
                  key={index}
                  className={classes.cell}
                  onClick={(e) => {
                    if (column.id === 'working') {
                      notifyWoriking(value);
                      setValue(!value);
                    }
                  }}>
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>

          <TableBody>
            {(rowsPerPage > 0
              ? members.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              : row).map((row, index) => {

                return (
                  <TableRow
                    hover role="checkbox"
                    tabIndex={-1}
                    key={row.no}
                    onClick={() => modifyMember.getMemberRow(row)}>
                    {columns.map((column, idx) => {
                      let value = row[column.id];
                      if (column.id == 'no') {
                        value = (page * rowsPerPage) + index + 1;
                      } else if (column.id == 'role') {
                        if (value === 'nurse') {
                          value = '간호사'
                        } else {
                          value = '의사'
                        }
                      } else if (column.id == 'working') {
                        value = value ? '재직중' : '퇴사';
                      }

                      return (
                        <TableCell key={idx} className={classes.cell}>
                          {column.format && typeof value === 'number' ? column.format(value) : value}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                );
              })}
            {emptyRows > 0 && (
              <TableRow style={{ height: 53 * emptyRows }}>
                <TableCell colSpan={6} />
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        component="div"
        count={members.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Paper>
  );
}