import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import HealingIcon from '@material-ui/icons/Healing';
import LocalHospitalIcon from '@material-ui/icons/LocalHospital';
import PeopleIcon from '@material-ui/icons/People';
import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from '../../assets/scss/mainListItems.scss';

export const mainListItems = (
  <nav className={styles.mainListItems} >
    <NavLink to={'/admin/member'}>
      <ListItem button>
        <ListItemIcon>
          <PeopleIcon />
        </ListItemIcon>
        <ListItemText primary="사용자관리" />
      </ListItem>
    </NavLink>

    <NavLink to={'/admin/disease'}>
      <ListItem button>
        <ListItemIcon>
          <LocalHospitalIcon />
        </ListItemIcon>
        <ListItemText primary="코드관리" />
      </ListItem>
    </NavLink>

    <NavLink to={'/admin/medicine'}>
      <ListItem button>
        <ListItemIcon>
          <HealingIcon />
        </ListItemIcon>
        <ListItemText primary="의약품관리" />
      </ListItem>
    </NavLink>
  </nav>
);