import blue from '@material-ui/core/colors/blue';
import CssBaseline from '@material-ui/core/CssBaseline';
import Fab from '@material-ui/core/Fab';
import { makeStyles } from '@material-ui/core/styles';
import ChatIcon from '@material-ui/icons/Chat';
import React, { Fragment, useEffect, useState } from 'react';
import io from 'socket.io-client';
import Chat from './Chat';
import Footer from './Footer';
import Header from './Header';

const socket = io.connect("http://localhost:8888", { transports: ['websocket'] });
const useStyles = makeStyles((theme) => ({
    root: {
        display: 'flex',
    },
    content: {
        flexGrow: 1,
        height: '100vh',
        overflow: 'auto',
        height: '100%',
    },
    chat: {
        position: 'fixed',
        bottom: theme.spacing(2),
        right: theme.spacing(2),
        backgroundColor: blue[500],
        color: '#fff'
    },
    chatWindow: {
        position: 'fixed',
        bottom: theme.spacing(14),
        right: theme.spacing(2),
    },
    appBarSpacer: theme.mixins.toolbar,
}))

export default function SiteLayout({ children }) {
    const classes = useStyles();
    const [visible, setVisible] = useState(false)
    const [chatArr, setChatArr] = useState([]);

    useEffect(() => {
        socket.on("receive", (message) => {
            setChatArr((chatArr) => chatArr.concat(message));
        }); //receive message이벤트에 대한 콜백을 등록해줌

    }, []);

    useEffect(async () => {
        try {
            const response = await fetch('/api/chat', {
                method: 'get',
                mode: 'same-origin',
                header: {
                    'Content-Type': 'application/json'
                },
                body: null
            })

            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }

            const json = await response.json();
            if (json.result !== 'success') {
                throw new Error(`${json.result} ${json.message}`);
            }
            setChatArr(json.data.map((item) => {
                return {
                    no: item.user_no,
                    id: item.user_name,
                    message: item.msg
                }
            }));

        } catch (err) {
            console.error(err);
        }
    }, [])

    const showChat = () => {
        setVisible(!visible)
    }

    const notifyMessage = {
        send: async function (message) {
            socket.emit("send", {
                no: sessionStorage.getItem('no'),
                id: sessionStorage.getItem('name'),
                role: sessionStorage.getItem('role'),
                message: message
            });

            try {
                const msg = {
                    no: sessionStorage.getItem('no'),
                    name: sessionStorage.getItem('name'),
                    message: message
                }
                const response = await fetch('/api/chat', {
                    method: 'post',
                    mode: 'same-origin',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify(msg)
                });

                if (!response.ok) {
                    throw new Error(`${response.status} ${response.statusText}`);
                }
                const json = await response.json();
                if (json.result !== 'success') {
                    throw new Error(`${json.result} ${json.message}`);
                }
            } catch (err) {
                console.error(err);
            }
        }
    }

    return (
        <div className={classes.root}>
            <Fragment>
                <CssBaseline />
                <Header />
                <main className={classes.content}>
                    <div className={classes.appBarSpacer} />
                    {children}
                    <Footer />
                </main>
                {sessionStorage.getItem('role') != 'admin' ?
                    <Fab aria-label={'chat'} className={classes.chat} onClick={showChat} >
                        <ChatIcon />
                    </Fab> : null
                }

                {visible ?
                    <div className={classes.chatWindow}>
                        <Chat chatArr={chatArr} notifyMessage={notifyMessage} />
                    </div>
                    : null}
            </Fragment>
        </div >
    );
}