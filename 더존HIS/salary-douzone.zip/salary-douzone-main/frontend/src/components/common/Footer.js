import Box from '@material-ui/core/Box';
import Typography from '@material-ui/core/Typography';
import React from 'react';

export default function Footer() {
    return (
        <Box pt={4}>
            <Box clone p={5} mx={2} my={3}>
                <Typography variant="body2" color="textSecondary" align="center" >
                    {'Copyright © '}
                    더조은HIS
                    {new Date().getFullYear()}
                    {'.'}
                </Typography>
            </Box>
        </Box>
    );
}