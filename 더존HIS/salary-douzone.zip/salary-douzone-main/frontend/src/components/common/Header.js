import AppBar from '@material-ui/core/AppBar';
import Box from '@material-ui/core/Box';
import Button from '@material-ui/core/Button';
import blue from '@material-ui/core/colors/blue';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Divider from '@material-ui/core/Divider';
import Drawer from '@material-ui/core/Drawer';
import IconButton from '@material-ui/core/IconButton';
import List from '@material-ui/core/List';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import MenuIcon from '@material-ui/icons/Menu';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import DaumPostcode from "react-daum-postcode";
import { useForm } from "react-hook-form";
import styles from '../../assets/scss/header.scss';
import { mainListItems } from './ListItems';

const drawerWidth = sessionStorage.getItem('role') == 'admin' ? 240 : 0;
const useStyles = makeStyles((theme) => ({
  toolbar: {
    paddingRight: 24,
  },
  toolbarIcon: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: '0 8px',
    ...theme.mixins.toolbar,
  },
  appBar: {
    background: blue[500],
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
  },
  menuButton: {
    marginRight: 36,
  },
  menuButtonHidden: {
    display: 'none',
  },
  title: {
    flexGrow: 1,
  },
  dialogTitle: {
    backgroundColor: blue[500],
    color: 'white'
  },
  profileButton: {
    '& button': {
      color: 'inherit',
      paddingRight: 0
    },
    marginTop: 10,
    textAlign: 'right',
  },
  drawerPaper: {
    position: 'relative',
    whiteSpace: 'nowrap',
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerPaperClose: {
    overflowX: 'hidden',
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    width: theme.spacing(7),
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9),
    },
  },
  box: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
}));

export default function Header() {
  const classes = useStyles();
  const [open, setOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [member, setMember] = useState([]);
  const [post, setPost] = useState(false);
  const { register, handleSubmit, setValue, formState: { errors } } = useForm();

  const onCompletePost = (data) => {
    setMember({
      ...member,
      address: data.address,
      zipcode: data.zonecode
    });
    setPost(false);
  }

  const logout = () => {
    sessionStorage.removeItem('no');
    sessionStorage.removeItem('role');
    sessionStorage.removeItem('name');
    sessionStorage.removeItem('isAuth');
    window.location.href = '/';
  }

  const handleAddressOpen = () => {
    setOpen(true);
    setPost(true);
  };

  const handleChange = (e) => {
    const { value, name } = e.target;
    if (name != 'profile') {
      setMember({
        ...member,
        [name]: value
      });
    } else if (e.target.files[0]) {
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        setMember({
          ...member,
          profile: reader.result,
          url: e.target.files[0]
        });
      });
      reader.readAsDataURL(e.target.files[0]);
    }
  }

  const onSubmit = async () => {
    try {
      let formData = new FormData();
      for (let item in member) {
        formData.append(item, member[item]);
      }
      const response = await fetch('/api/member/' + member.no, {
        method: 'post',
        mode: 'same-origin',
        headers: {
          'Accept': 'application/json'
        },
        body: formData
      })

      if (!response.ok) {
        throw new Error(`${response.status} ${response.statusText}`);
      }

      const json = await response.json();
      if (json.result !== 'success') {
        throw new Error(`${json.result} ${json.message}`);
      }
      setDialogOpen(false)
    } catch (error) {
      console.error(error);
    }
  };

  let welcome = '';
  if (sessionStorage.getItem('role') === 'nurse') {
    welcome = sessionStorage.getItem('name') + ' 간호사님'
  } else if (sessionStorage.getItem('role') === 'doctor') {
    welcome = sessionStorage.getItem('name') + ' 의사님'
  } else {
    welcome = '관리자님'
  }

  // 로그인 정보 가져오는  API
  useEffect(
    async () => {
      try {
        const response = await fetch(`/api/member/${sessionStorage.getItem('no')}`, {
          method: 'put',
          mode: 'same-origin',
          header: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(sessionStorage.getItem('no'))
        })

        if (!response.ok) {
          throw new Error(`${response.status} ${response.statusText}`);
        }

        const json = await response.json();
        if (json.result !== 'success') {
          throw new Error(`${json.result} ${json.message}`);
        }
        setMember(json.data[0]);
        setValue('name', member.name);
        setValue('email', member.email);
        setValue('detailaddress', member.detailaddress);
        setValue('cellphone', member.cellphone);
      } catch (err) {
        console.error(err);
      }
    }, []);

  return (
    <header>
      <AppBar position="absolute" className={clsx(classes.appBar, open && classes.appBarShift)}>
        <Toolbar className={classes.toolbar}>
          {sessionStorage.getItem('role') === 'admin' ?
            <IconButton
              edge="start"
              color="inherit"
              aria-label="open drawer"
              onClick={() => setOpen(true)}
              className={clsx(classes.menuButton, open && classes.menuButtonHidden)} >
              <MenuIcon />
            </IconButton> : null}
          <Typography component="h1" variant="h5" color="inherit" className={classes.title}> 더조은HIS </Typography>

          <div className={classes.profileButton}>
            <Typography> {welcome}</Typography>
            {sessionStorage.getItem('role') !== 'admin' ?
              <Button onClick={() => setDialogOpen(true)}>
                정보수정
              </Button> : null}

            <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)}>
              <form className={styles.Form} onSubmit={handleSubmit(onSubmit)} onChange={handleChange}>
                <DialogContent>
                  <Box className={classes.box}>
                    <input type="file" accept="image/*" name="profile" id="profile" onChange={handleChange} style={{ display: 'none' }} />
                    <label htmlFor="profile">
                      <IconButton component="span">
                        <img src={member.profile} />
                      </IconButton>
                    </label>
                  </Box>

                  <div className={styles.textField}>
                    <TextField
                      label="이름"
                      className={classes.textField}
                      margin='normal'
                      fullWidth
                      placeholder='이름'
                      value={member.name}
                      autoFocus
                      InputLabelProps={{ shrink: true }}
                      {...register("name", {
                        required: true,
                        pattern: /[가-힣]/g
                      })}
                    />
                    {errors?.name?.type === "required" && <p>이름을 입력해주세요.</p>}
                    {errors?.name?.type === "pattern" && (
                      <p>이름을 정확히 입력해주세요.</p>
                    )}

                    <TextField
                      className={classes.textField}
                      label="아이디"
                      margin='normal'
                      fullWidth
                      value={member.id}
                      disabled
                      InputLabelProps={{ shrink: true }}
                    />

                    <TextField
                      type="password"
                      label="비밀번호"
                      fullWidth
                      value={member.password}
                      className={classes.textField}
                      margin='normal'
                      InputLabelProps={{ shrink: true }}
                      {...register("password", {
                        required: true,
                        minLength: 6
                      })}
                    />
                    {errors?.password?.type === "minLength" && <p>비밀번호는 최소 6글자 이상이어야 합니다.</p>}

                    <TextField
                      className={classes.textField}
                      placeholder='이메일'
                      label="이메일"
                      value={member.email}
                      margin='normal'
                      fullWidth
                      InputLabelProps={{ shrink: true }}
                      {...register("email", {
                        required: true,
                        pattern: /\d*([a-z])\d*[@]([a-z]+\.)+(com|net|kr)/g
                      })}
                    />
                    {errors?.email?.type === "required" && <p>이메일을 입력해주세요.</p>}
                    {errors?.email?.type === "pattern" && (
                      <p>이메일을 정확히 입력해주세요.</p>
                    )}

                    {post ? <Dialog open={open}>
                      <DialogTitle id="form-dialog-title">주소검색
                        <Button onClick={() => setPost(false)} color="primary"> x</Button>
                      </DialogTitle>
                      <DialogContent>
                        <DaumPostcode onComplete={onCompletePost} />
                      </DialogContent>
                    </Dialog> : null}

                    <div className={styles.AddressBtn}>
                      <TextField
                        placeholder="우편번호"
                        label="우편번호"
                        value={member.zipcode}
                        fullWidth
                        disabled
                        InputLabelProps={{ shrink: true }}
                        {...register("zipcode", {
                          required: true,
                          value: member.zipcode,
                        })}
                      />

                      <Button onClick={handleAddressOpen}> 주소찾기 </Button>
                    </div>

                    <TextField
                      className={classes.textField}
                      placeholder='주소'
                      margin='normal'
                      label='주소'
                      fullWidth
                      disabled
                      value={member.address}
                      InputLabelProps={{ shrink: true }}
                      {...register("address", {
                        required: true,
                        value: member.address
                      })}
                    />
                    {errors?.address?.type === "required" && <p>주소를 입력해주세요.</p>}

                    <TextField
                      className={classes.textField}
                      placeholder='상세주소'
                      fullWidth
                      value={member.detailaddress}
                      label="상세주소"
                      margin='normal'
                      InputLabelProps={{
                        shrink: true,
                      }}
                      {...register("detailaddress", {
                        required: true,
                      })}
                    />
                    {errors?.detailaddress?.type === "required" && <p >상세 주소를 입력해주세요.</p>}

                    <TextField
                      className={classes.textField}
                      placeholder='전화번호'
                      fullWidth
                      margin='normal'
                      label="전화번호"
                      value={member.cellphone}
                      InputLabelProps={{
                        shrink: true,
                      }}
                      {...register("cellphone", {
                        required: true,
                        pattern: (/(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/, "$1-$2-$3")
                      })}
                    />
                    {errors?.cellphone?.type === "required" && <p>전화번호를 입력해주세요.</p>}
                    {errors?.cellphone?.type === "pattern" && (
                      <p>전화번호를 정확히 입력해주세요.</p>
                    )}
                  </div>
                </DialogContent>
                <DialogActions>
                  <Button type="submit" fullWidth>수정</Button>
                  <Button type="button" onClick={() => setDialogOpen(false)} fullWidth>취소</Button>
                </DialogActions>
              </form>
            </Dialog>
            <Button onClick={logout}>로그아웃</Button>
          </div>
        </Toolbar>
      </AppBar>

      {sessionStorage.getItem('role') === 'admin' ?
        <Drawer
          variant="permanent"
          classes={{
            paper: clsx(classes.drawerPaper, !open && classes.drawerPaperClose),
          }}
          open={open}>
          <div className={classes.toolbarIcon}>
            <IconButton onClick={() => setOpen(false)}>
              <ChevronLeftIcon />
            </IconButton>
          </div>
          <Divider />
          <List>{mainListItems}</List>
        </Drawer> : null}
    </header>
  );
}