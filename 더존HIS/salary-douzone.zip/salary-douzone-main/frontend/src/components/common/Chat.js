import Button from '@material-ui/core/Button';
import InputBase from '@material-ui/core/InputBase';
import React, { useEffect, useRef, useState } from 'react';
import styles from '../../assets/scss/chat.scss';

export default function Chat({ chatArr, notifyMessage }) {
    const [message, setMessage] = useState('');
    const scroll = useRef();
    const inputMessage = useRef();

    useEffect(() => {
        scroll.current.scrollTo(0, scroll.current.scrollHeight);
    }, [chatArr])

    const buttonHandler = () => {
        notifyMessage.send(message);
        setMessage('');
        inputMessage.current.focus();
        //버튼을 클릭했을 때 send message이벤트 발생
    };
    const onKeyPress = (e) => {
        if (e.key == 'Enter') {
            buttonHandler();
        }
    }

    const onChange = (e) => {
        setMessage(e.target.value)
    };

    return (
        <div className={styles.Paper}>
            <div className={styles.Background} >
                <div className={styles.Scrollbar} ref={scroll}>
                    {chatArr.map((ele, idx) => (
                        sessionStorage.getItem('no') == ele.no ?
                            <div key={idx} className={styles.myMessageArea}>
                                <span className={styles.myMessage}>
                                    <div>{ele.id}</div>
                                    <div>{ele.message}</div>
                                </span>
                            </div>
                            :
                            <div key={idx} className={styles.otherMessageArea}>
                                <span className={styles.otherMessage}>
                                    <div>{ele.id}</div>
                                    <div>{ele.message}</div>
                                </span>
                            </div>
                    ))}
                </div>
                <div className={styles.input}>
                    <InputBase
                        name={'message'}
                        ref={inputMessage}
                        placeholder="내용을 입력해주세요"
                        className={styles.textField}
                        value={message}
                        onChange={onChange}
                        onKeyPress={message == '' ? null : onKeyPress}
                    />
                    <div>
                        <Button
                            className={styles.btn}
                            onClick={buttonHandler}
                            disabled={message == ''}>
                            전송
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}