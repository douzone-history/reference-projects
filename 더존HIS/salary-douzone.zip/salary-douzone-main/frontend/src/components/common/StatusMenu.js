import blue from '@material-ui/core/colors/blue';
import { makeStyles } from '@material-ui/core/styles';
import React from 'react';

const useStyles = makeStyles(() => ({
    menubar: {
        padding: 0,
        backgroundColor: 'white',
    },
    tabs: {
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        fontSize: 15,
        fontWeight: 'bold',
        display: 'inline-block',
        color: blue[500],
        padding: '.3rem',
        width: '110px',
        textAlign: 'center',
        border: `2px solid ${blue[500]} `,
        marginRight: '2px',
        borderTop: `3px solid ${blue[600]}`,
        borderRight: `4px solid ${blue[600]}`
    },
    active: {
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        fontSize: 15,
        fontWeight: 'bold',
        display: 'inline-block',
        color: 'white',
        padding: '.3rem',
        border: `2px solid ${blue[500]} `,
        backgroundColor: blue[500],
        height: '100%',
        width: '110px',
        textAlign: 'center',
        marginRight: '2px',
        borderTop: `3px solid ${blue[500]}`,
        borderRight: `4px solid ${blue[500]}`
    },
    ultag: {
        margin: '0px 0px 5px 0px',
        padding: 0
    }
}));

export default function StatusMenu({ handleStatusMenu, statusMenu, patientOrderList }) {
    const classes = useStyles();
    const notifyStatusMenu = (index) => {
        handleStatusMenu(index)
    }

    let waitCure = 0;
    let cure = 0;
    let waitPay = 0;
    let complete = 0;
    if (patientOrderList != [])
        patientOrderList.forEach((item, index) => {
            if (item.progress == '진료대기') {
                waitCure++;
            } else if (item.progress == '진료중') {
                cure++;
            } else if (item.progress == '수납대기') {
                waitPay++;
            } else if (item.progress == '완료') {
                complete++;
            }
        })

    const allPatient = patientOrderList.length

    return (
        <div className={classes.menubar}>
            <ul className={classes.ultag}>
                <li
                    className={`${statusMenu === 0 ? classes.active : classes.tabs}`}
                    onClick={() => notifyStatusMenu(0)}>{`전체 (${allPatient})`}</li>
                <li
                    className={`${statusMenu === 1 ? classes.active : classes.tabs}`}
                    onClick={() => notifyStatusMenu(1)}>{`진료대기 (${waitCure})`}</li>
                <li
                    className={`${statusMenu === 2 ? classes.active : classes.tabs}`}
                    onClick={() => notifyStatusMenu(2)}>{`진료중 (${cure})`}</li>
                <li
                    className={`${statusMenu === 3 ? classes.active : classes.tabs}`}
                    onClick={() => notifyStatusMenu(3)}>{`수납대기 (${waitPay})`}</li>
                <li
                    className={`${statusMenu === 4 ? classes.active : classes.tabs}`}
                    onClick={() => notifyStatusMenu(4)}>{`완료 (${complete})`}</li>
            </ul>
        </div>
    );
}