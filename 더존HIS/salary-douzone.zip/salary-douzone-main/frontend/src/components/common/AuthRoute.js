import React from 'react';
import { Redirect, Route } from 'react-router-dom';

export default function AuthRoute({ component: Component, role, ...rest }) {
    let componentRole = '';
    if (sessionStorage.getItem('role') === 'admin') {
        componentRole = '/admin';
    } else if (sessionStorage.getItem('role') === 'nurse') {
        componentRole = '/nurse';
    } else {
        componentRole = '/doctor';
    }

    return (
        // Auth User 구분
        <Route {...rest} render={props => (
            sessionStorage.getItem('isAuth') === 'true' && role === sessionStorage.getItem('role') ?
                <Component {...props} />
                : sessionStorage.getItem('isAuth') === 'true' ?
                    <Redirect to={componentRole} /> :
                    <Component {...props} />
        )} />
    );
};
