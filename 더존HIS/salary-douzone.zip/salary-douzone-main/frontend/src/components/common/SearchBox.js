import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import React from 'react';

const useStyles = makeStyles((theme) => ({
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    width: '100%',
  },
}));

export default function SearchBox({ notifyKeyword, keyword }) {
  const classes = useStyles();

  const onChange = function (e) {
    notifyKeyword(e.target.value);
  };

  const onFocus = function (e) {
    notifyKeyword('');
  }

  return (
    <TextField
      placeholder="내용을 입력해주세요"
      className={classes.textField}
      variant="outlined"
      value={keyword}
      onChange={onChange}
      onFocus={onFocus}
    />
  );
}
