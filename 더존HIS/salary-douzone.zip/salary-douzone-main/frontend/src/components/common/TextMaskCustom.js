import PropTypes from "prop-types";
import React from 'react';
import MaskedInput from "react-text-mask";

export default function TextMaskCustom(props) {
    const { inputRef, ...other } = props;

    return (
        (() => {
            switch (props.name) {
                case 'registration_no':
                    return (
                        <MaskedInput
                            {...other}
                            ref={(ref) => {
                                inputRef(ref ? ref.inputElement : null);
                            }}
                            mask={[
                                /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, "-", /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/
                            ]}
                            placeholderChar={"\u2000"}
                            showMask

                        />
                    )

                case 'email':
                    return (
                        <MaskedInput
                            {...other}
                            ref={(ref) => {
                                inputRef(ref ? ref.inputElement : null);
                            }}
                            mask={[
                                "@",
                            ]}
                            placeholderChar={"\u2000"}
                            showMask
                        />
                    )

                case 'cellphone':
                    return (
                        <MaskedInput
                            {...other}
                            ref={(ref) => {
                                inputRef(ref ? ref.inputElement : null);
                            }}
                            mask={[
                                /\d/, /\d/, /\d/, "-", /\d/, /\d/, /\d/, /\d/, "-", /\d/, /\d/, /\d/, /\d/,
                            ]}
                            placeholderChar={"\u2000"}
                            showMask
                        />
                    )
            }
        })()
    );
}

TextMaskCustom.propTypes = {
    inputRef: PropTypes.func.isRequired
};