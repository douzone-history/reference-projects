import { Typography } from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import React, { useState, useEffect } from 'react';
import Modal from 'react-modal';
import modalStyles from '../../assets/scss/patientHistory.scss';

const columns = [
  { id: 'reg_date', label: '날짜' },
  { id: 'name', label: '주상병' },
];

const detailColumns = [
  { id: 'cure', label: '치료' },
  { id: 'medicine', label: '처방 의약품' },
  { id: 'disease', label: '상병 내역' },
]

export default function PatientHistory({ clinicHistory, getDetailHistory, detail }) {
  const [page, setPage] = useState(0);
  const [detailPage, setDetailPage] = useState(0);
  const [openModal, setOpenModal] = useState(false);
  const [orderInfo, setOrderInfo] = useState('');
  const rowsPerPage = 5;
  const emptyRows = rowsPerPage - Math.min(5, clinicHistory.length - page * rowsPerPage);
  const detailEmptyRows = rowsPerPage - Math.min(5, detail.length - detailPage * rowsPerPage);
  
  useEffect(() => {
    setPage(0);
  }, [getDetailHistory])

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeDetailPage = (event, newPage) => {
    setDetailPage(newPage);
  };

  const handleHistory = (row) => {
    setOrderInfo(row);
    setOpenModal(true)
    getDetailHistory(row);
  }

  const closeModal = () => {
    setDetailPage(0);
    setOpenModal(false);
  }

  return (
    <Paper>
      {/* 내원 이력 테이블 */}
      <Table>
        <TableHead>
          <TableRow>
            {columns.map((column, idx) => (
              <TableCell
                className={modalStyles.tableHead}
                key={column.id}
              >
                {column.label}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {clinicHistory.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, idx) => {
            return (
              <TableRow
                tabIndex={-1}
                key={idx}
                onClick={() => handleHistory(row)}>
                {columns.map((column, idx) => {
                  const value = row[column.id];
                  return (
                    <TableCell key={idx} className={modalStyles.alignCell}>
                      <div className={modalStyles.textContainer}>
                        {value}
                      </div>
                    </TableCell>
                  );
                })}
              </TableRow>
            );
          })}
          {emptyRows > 0 && (
            <TableRow style={{ height: 53 * emptyRows }}>
              <TableCell colSpan={6} />
            </TableRow>
          )}
        </TableBody>
      </Table>
      <TablePagination
        rowsPerPageOptions={[5]}
        component="div"
        count={clinicHistory.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
      />

      {/* 내원 이력 상세 테이블 */}
      <Modal
        isOpen={openModal}
        onRequestClose={closeModal}
        shouldCloseOnOverlayClick={true}
        className={modalStyles.Modal}
        overlayClassName={modalStyles.Overlay}
      >

        <h1>진료기록부</h1>
        <div className={modalStyles.writeContent}>
          <div className={modalStyles.writeInfo}>
            <Typography>차트번호 : {orderInfo.orderNo} </Typography>
            <Typography>작성자 : {orderInfo.membername} </Typography>
            <Typography>날짜 : {orderInfo.reg_date}</Typography>
          </div>
        </div>

        <Table className={modalStyles.messageTable}>
          <TableBody>
            <TableRow>
              <TableCell className={modalStyles.messageHead}>환자상태 및<br /> 의사소견</TableCell>
              <TableCell className={modalStyles.messageContent}>{orderInfo.doctor_message}</TableCell>
            </TableRow>
          </TableBody>
        </Table>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                {detailColumns.map((column, idx) => (
                  <TableCell
                    className={modalStyles.detailTableHead}
                    key={column.id}
                  >
                    {column.label}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {detail.slice(detailPage * rowsPerPage, detailPage * rowsPerPage + rowsPerPage).map((row, idx) => {
                return (
                  <TableRow
                    tabIndex={-1}
                    key={idx}>
                    {detailColumns.map((column, idx) => {
                      const value = row[column.id];
                      return (
                        <TableCell key={idx} className={modalStyles.alignCell}>
                          {value}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                );
              })}
              {detailEmptyRows > 0 && (
                <TableRow style={{ height: 53 * detailEmptyRows }}>
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5]}
          component="div"
          count={detail.length}
          rowsPerPage={rowsPerPage}
          page={detailPage}
          onPageChange={handleChangeDetailPage}
        />
      </Modal>

    </Paper>
  );
}
