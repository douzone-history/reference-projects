import blue from '@material-ui/core/colors/blue';
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import React, { useRef, useState } from 'react';

const columns = [
    { id: 'no', label: '번호', width: '10%' },
    { id: 'name', label: '이름', width: '15%' },
    { id: 'registration_no', label: '주민등록번호', width: '20%' },
    { id: 'cellphone', label: '전화번호', width: '20%' },
    { id: 'address', label: '주소', width: '35%' },
];

const useStyles = makeStyles(() => ({
    root: {
        width: '100%',
    },
    head: {
        fontSize: 16,
        textAlign: 'center',
        backgroundColor: blue[500],
        color: 'white',
        fontWeight: 'bold',
    },
    alignCell: {
        textAlign: 'center',
    },
    textContainer: {
        display: 'block',
        width : '200px',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow : 'ellipsis'
    }
}));


export default function PatientList({ patient, getPatientRow }) {
    const classes = useStyles();
    const rowRef = useRef(null);
    const [page, setPage] = useState(0);
    const emptyRows = 5 - Math.min(5, patient.length - page * 5);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    return (
        <Paper className={classes.root}>
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            {columns.map((column, index) => (
                                <TableCell
                                    className={classes.head}
                                    key={index}
                                    style={{ width: column.width }}
                                >
                                    {column.label}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>

                    <TableBody>
                        {patient.slice(page * 5, page * 5 + 5).map((row, index) => {
                            return (
                                <TableRow
                                    hover role="checkbox"
                                    tabIndex={-1}
                                    key={index}
                                    onClick={() => getPatientRow.find(row)}>
                                    {columns.map((column, idx) => {
                                        let value = row[column.id];
                                        if (column.id == 'no') {
                                            value = (page * 5) + index + 1;
                                        } else if (column.id == 'address') {
                                            value += ' ' + row.detailaddress;
                                        }
                                        return (
                                            <TableCell
                                                className={classes.alignCell}
                                                key={idx}
                                                ref={rowRef} >
                                                {column.id == 'address' ?
                                                    <div className={classes.textContainer} >
                                                        {value}
                                                    </div> :
                                                    value
                                                }
                                            </TableCell>
                                        );
                                    })}
                                </TableRow>
                            );
                        })}
                        {emptyRows > 0 && (
                            <TableRow style={{ height: 53 * emptyRows }}>
                                <TableCell colSpan={6} />
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </TableContainer>

            <TablePagination
                rowsPerPageOptions={[5]}
                component="div"
                count={patient.length}
                rowsPerPage={5}
                page={page}
                onPageChange={handleChangePage}
            />
        </Paper>
    );
}
