import blue from '@material-ui/core/colors/blue';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';
import React from 'react';

const columns = [
  { id: 'name', label: '이름' },
  { id: 'registration_no', label: '주민등록번호' },
  { id: 'age', label: '나이' },
  { id: 'gender', label: '성별' },
  { id: 'cellphone', label: '전화번호' },
  { id: 'address', label: '주소' },
  { id: 'visit', label: '초진/재진' },
  { id: 'insurance', label: '보험' },
]

const useStyles = makeStyles((theme) => ({
  container: {
    border: '1px solid rgba(133, 133, 133, 0.5)'
  },
  head: {
    fontSize: 16,
    textAlign: 'center',
    width: '30%',
    backgroundColor: blue[500],
    color: 'white',
    fontWeight: 'bold'
  }
}));

export default function PatientInfo({ patient }) {
  const classes = useStyles();

  return (
    <TableContainer className={classes.container}>
      <Table className={classes.table}>
        {columns.map((column, index) => (
          <TableBody key={index}>
            <TableRow>
              <TableCell className={classes.head} >
                {column.label}
              </TableCell>
              <TableCell>
                {column.id == 'address' ? patient[column.id] && patient[column.id] + ' ' + patient.detailaddress : patient[column.id]}
              </TableCell>
            </TableRow>
          </TableBody>
        ))}
      </Table>
    </TableContainer>
  );
}