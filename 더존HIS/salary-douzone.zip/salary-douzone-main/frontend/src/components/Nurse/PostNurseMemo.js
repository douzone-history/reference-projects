import React from 'react';
import TextField from '@material-ui/core/TextField';

export default function PostNurseMemo({ handleNurseMemo, nurseMemo }) {
    const notifyNurseMemo = (e) => {
        handleNurseMemo(e.target.value);
    }

    return (
        <div>
            <TextField
                multiline
                variant="outlined"
                rows={4}
                fullWidth
                value={nurseMemo ? nurseMemo : ''}
                onChange={notifyNurseMemo}
            />
        </div>
    );
}