import Button from '@material-ui/core/Button';
import blue from '@material-ui/core/colors/blue';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import React, { useEffect, useState } from 'react';

const columns = [
    { id: 'no', label: '순번' },
    { id: 'name', label: '이름' },
    { id: 'gender', label: '성별'},
    { id: 'age', label: '나이'},
    { id: 'progress', label: '상태' },
    { id: 'button', label: '' },
];

const useStyles = makeStyles(() => ({
    root: {
        width: '100%',
    },
    head: {
        fontSize: 16,
        textAlign: 'center',
        backgroundColor: blue[500],
        color: 'white',
        fontWeight: 'bold',
        width : '16%'
    },
    content: {
        textAlign: 'center',
        padding: 0,
        height: 53
    },
    btn: {
        margin: 0
    }
}));

const initialState = {
    mouseX: null,
    mouseY: null,
};

export default function PatientOrderList({ patientOrderList, updateCuringStatus, getPatientInfo, cancelOrder, statusMenu }) {
    const classes = useStyles();
    const [page, setPage] = useState(0);
    const [state, setState] = useState(initialState);
    const [selectOrder, setSelectOrder] = useState();
    const emptyRows = 5 - Math.min(5, patientOrderList.length - page * 5);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handlePatient = (patient) => {
        updateCuringStatus(patient);
    }

    const notifyPatient = (patient) => {
        getPatientInfo(patient);
    }

    const handleContextMenu = (e, row) => {
        if (row.progress == '진료대기') {
            e.preventDefault()
            setSelectOrder(row)
            setState({
                mouseX: e.clientX,
                mouseY: e.clientY,
            });
        }
    }

    const handleCancelOrder = () => {
        setPage(0);
        cancelOrder(selectOrder);
        setState(initialState);
    }

    useEffect(() => {
        setPage(0);
    }, [statusMenu])

    return (
        <Paper className={classes.root}>
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            {columns.map((column, index) => (
                                <TableCell className={classes.head}
                                    key={index}
                                >
                                    {column.label}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>

                    <TableBody>
                        {patientOrderList.slice(page * 5, page * 5 + 5).map((row, index) => {
                            return (
                                <TableRow
                                    hover role="checkbox"
                                    tabIndex={-1}
                                    key={index}
                                    onContextMenu={(e) => handleContextMenu(e, row)}
                                    onClick={() => notifyPatient(row)}>
                                    {columns.map((column) => {
                                        let value;
                                        if (column.id == 'no') {
                                            value = (page * 5) + index + 1;
                                        } else if (column.id == 'button') {
                                            value = row['progress'] == '진료대기' ? (
                                                <Button className={classes.btn}
                                                    variant="outlined"
                                                    color="primary"
                                                    onClick={() => handlePatient(row)}>진료</Button>)
                                                : null
                                        } else {
                                            value = row[column.id]
                                        }
                                        return (
                                            <TableCell className={classes.content} key={column.id}>
                                                {value}
                                            </TableCell>
                                        );
                                    })}
                                    <Menu
                                        keepMounted
                                        open={state.mouseY !== null}
                                        onClose={() => setState(initialState)}
                                        anchorReference="anchorPosition"
                                        anchorPosition={
                                            state.mouseY !== null && state.mouseX !== null
                                                ? { top: state.mouseY, left: state.mouseX }
                                                : undefined
                                        }
                                    >
                                        <MenuItem onClick={() => handleCancelOrder()}>접수취소</MenuItem>
                                    </Menu>
                                </TableRow>
                            );
                        })}
                        {emptyRows > 0 && (
                            <TableRow style={{ height: 53 * emptyRows }}>
                                <TableCell colSpan={6} />
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[5]}
                component="div"
                count={patientOrderList.length}
                rowsPerPage={5}
                page={page}
                onPageChange={handleChangePage}
            />
        </Paper>
    );
}