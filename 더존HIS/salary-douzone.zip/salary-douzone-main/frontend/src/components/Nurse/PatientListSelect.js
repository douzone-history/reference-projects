import MenuItem from '@material-ui/core/MenuItem';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import React, { useState } from 'react';

const menus = [
  { value: 'all', label: '전체' },
  { value: 'name', label: '이름' },
  { value: 'registration_no', label: '생년월일' }
];

const useStyles = makeStyles(() => ({
  root: {
    '& .MuiTextField-root': {
      width: '120px',
    },
    display: 'flex',
  },
}));

export default function PatientListSelect({ notifyDivision }) {
  const classes = useStyles();
  const [menu, setMenu] = useState('all');

  const handleChange = (e) => {
    setMenu(e.target.value);
    notifyDivision(e.target.value);
  };

  return (
    <div className={classes.root} >
      <TextField
        select
        value={menu}
        onChange={handleChange}
        variant="outlined"
      >
        {menus.map((option) => (
          <MenuItem
            key={option.value}
            value={option.value}
            name={option.label}>
            {option.label}
          </MenuItem>
        ))}
      </TextField>
    </div>
  );
}
