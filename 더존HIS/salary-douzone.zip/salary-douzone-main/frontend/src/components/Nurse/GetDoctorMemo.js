import TextField from '@material-ui/core/TextField';
import React from 'react';

export default function GetDoctorMemo({ doctorMemo }) {
    return (
        <div>
            <TextField
                multiline
                variant="outlined"
                rows={4}
                fullWidth
                value={ doctorMemo }
            />
        </div>
    );
}