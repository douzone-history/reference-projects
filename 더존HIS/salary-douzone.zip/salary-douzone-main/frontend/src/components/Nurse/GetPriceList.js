import blue from '@material-ui/core/colors/blue';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import React from 'react';

const columns = [
  { id: 'menu', label: '항목' },
  { id: 'selfprice', label: '본인부담금' },
  { id: 'nationprice', label: '공단부담금' },
];

const useStyles = makeStyles(() => ({
  head: {
    backgroundColor: blue[500],
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
  },
  row: {
    fontSize: 16,
    textAlign: 'center',
  }
}));

export default function GetPriceList({ pay }) {
  const classes = useStyles();

  return (
    <TableContainer>
      <Table>
        <TableHead>
          <TableRow>
            {
              columns.map((column, idx) => (
                <TableCell
                  className={classes.head}
                  key={idx}>
                  {column.label}
                </TableCell>
              ))
            }
          </TableRow>
        </TableHead>
        <TableBody >
          {
            pay.map((row, idx) => {
              return (
                <TableRow key={idx}>
                  {
                    columns.map((column, index) => {
                      const value = row[column.id];
                      return (
                        <TableCell
                          key={index}
                          className={classes.row}>
                          {value}
                        </TableCell>
                      )
                    })
                  }
                </TableRow>
              );
            })
          }
        </TableBody>
      </Table>
    </TableContainer>
  );
}
