import Button from '@material-ui/core/Button';
import blue from '@material-ui/core/colors/blue';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import InputBase from "@material-ui/core/InputBase";
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';
import React, { Fragment, useEffect, useState } from 'react';
import DaumPostcode from "react-daum-postcode";
import TextMaskCustom from '../common/TextMaskCustom';

const columns = [
  { id: 'name', label: '이름' },
  { id: 'registration_no', label: '주민등록번호' },
  { id: 'cellphone', label: '전화번호' },
  { id: 'address', label: '주소' },
  { id: 'insurance', label: '보험' },
]
const useStyles = makeStyles(() => ({

  head: {
    fontSize: 16,
    textAlign: 'center',
    width: '30%',
    backgroundColor: blue[500],
    color: 'white',
    fontWeight: 'bold'
  },
  box: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttons: {
    backgroundColor: blue[500],
    color: 'white',
    fontWeight: 'bold',
    float: 'right',
    marginTop: -60,
    "&:hover": {
      backgroundColor: blue[500],
    },
  }
}));

export default function PatientUpdate({ patient, patientUpdate }) {
  const classes = useStyles();
  const [open, setOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [post, setPost] = useState(false);
  const [input, setInput] = useState({
    name: '',
    address: '',
    cellphone: '',
    zipcode: '',
    detailaddress: '',
    insurance: ''
  });

  const onCompletePost = (data) => {
    setInput({
      ...input,
      address: data.address,
      zipcode: data.zonecode
    });
    setPost(false);
  }

  const handleAddressOpen = () => {
    setOpen(true);
    setPost(true);
  };

  const onChange = e => {
    setInput({
      ...input,
      [e.target.name]: e.target.value
    });
  };

  const handleClose = () => {
    setDialogOpen(false);
    setInput(patient)
  };

  useEffect(() => {
    setInput(patient);
  }, [patient]);

  const handleUpdate = async () => {
    try {
      const response = await fetch('/api/patient/' + patient.no, {
        method: 'POST',
        mode: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(input)
      })

      if (!response.ok) {
        throw new Error(`${response.status} ${response.statusText}`);
      }

      const json = await response.json();
      if (json.result !== 'success') {
        throw new Error(`${json.result} ${json.message}`);
      }
      patientUpdate(input)
      setDialogOpen(false)
    } catch (error) {
      console.error(error);
    }
  }

  return (
    <Fragment>
      <Button className={classes.buttons} onClick={() => setDialogOpen(true)} >환자정보수정</Button>
      <Dialog open={dialogOpen} onClose={handleClose}>
        <DialogTitle> 환자 정보 수정</DialogTitle>
        <DialogContent>
          <TableContainer className={classes.container}>
            <Table className={classes.table} >
              {columns.map((column, index) => (
                <TableBody key={index}>
                  <TableRow>
                    <TableCell className={classes.head} >
                      {column.label}
                    </TableCell>
                    <TableCell>
                      {(() => {
                        switch (column.id) {
                          case 'name':
                            return (
                              <InputBase
                                name={column.id}
                                onChange={onChange}
                                value={input[column.id] || ''}
                              />
                            )

                          case 'registration_no':
                            return (
                              <InputBase
                                name={column.id}
                                value={input[column.id] || ''}
                                inputComponent={TextMaskCustom}
                                disabled
                              />
                            )

                          case 'cellphone':
                            return (
                              <InputBase
                                name={column.id}
                                value={input[column.id] || ''}
                                onChange={onChange}
                                inputComponent={TextMaskCustom}
                              />
                            )

                          case 'address':
                            return (
                              <div>
                                <InputBase
                                  placeholder='우편번호'
                                  name='zipcode'
                                  value={input.zipcode || ''}
                                  disabled
                                />
                                <Button color="primary" onClick={handleAddressOpen}>
                                  주소찾기
                                </Button>

                                {post ? <Dialog open={open} >
                                  <DialogTitle>주소검색<Button onClick={() => setPost(false)} color="primary">
                                    x
                                  </Button></DialogTitle>
                                  <DialogContent>
                                    <DaumPostcode onComplete={onCompletePost} />
                                  </DialogContent>
                                </Dialog> : null}

                                <InputBase
                                  placeholder='주소'
                                  name='address'
                                  value={input.address || ''}
                                  fullWidth
                                  disabled
                                />

                                <InputBase
                                  placeholder='상세주소를 입력하세요.'
                                  name='detailaddress'
                                  value={input.detailaddress || ''}
                                  onChange={onChange}
                                  fullWidth
                                />
                              </div>
                            )

                          case 'insurance':
                            return (
                              <div>
                                <label htmlFor="true">유</label>
                                <input type="radio" id="true" name={column.id} value="있음" checked={input.insurance == '있음' || input.insurance == 'true'} onChange={onChange} />
                                <label htmlFor="false">무</label>
                                <input type="radio" id="false" name={column.id} value="없음" checked={input.insurance == '없음' || input.insurance == 'false'} onChange={onChange} />
                              </div>
                            )
                        }
                      })()}
                    </TableCell>
                  </TableRow>
                </TableBody>
              ))}
            </Table>
          </TableContainer>
        </DialogContent>
        <DialogActions>
          <Button color="primary" fullWidth onClick={handleUpdate} >
            수정
          </Button>
          <Button onClick={handleClose} color="primary" fullWidth>
            취소
          </Button>
        </DialogActions>
      </Dialog>
    </Fragment>
  );
}
