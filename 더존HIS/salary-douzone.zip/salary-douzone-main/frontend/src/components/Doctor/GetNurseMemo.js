import TextField from '@material-ui/core/TextField';
import React from 'react';

export default function GetNurseMemo({ nurseMemo }) {

    return (
        <div>
            <TextField
                multiline
                variant="outlined"
                rows={4}
                fullWidth
                value={nurseMemo !== 'undefined' ? nurseMemo : ''}
            />
        </div>
    )
}