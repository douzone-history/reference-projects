import Checkbox from '@material-ui/core/Checkbox';
import blue from '@material-ui/core/colors/blue';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import { makeStyles } from '@material-ui/core/styles';
import React from 'react';

const useStyles = makeStyles(() => ({
  main: {
    borderRadius: 5,
    border: "1px solid black",
    padding : 20,
    paddingRight : 0
  },
  props: {
    width: 30
  }
}));

const columns = [
  { id: 'injection', label: '주사' },
  { id: 'dressing', label: '드레싱' },
  { id: 'gips', label: '깁스' },
  { id: 'physics', label: '물리치료' },
  { id: 'xray', label: 'X-ray'}
]

export default function MedicalCure({ handleAddCure, addCure }) {
  const classes = useStyles();
  const handleCure = (e) => {
    let { value, name } = e.target
    value = value === 'true' ? false : true;
    handleAddCure(value, name);
  }

  return (
    <div className={classes.main}>
      {columns.map((column, index) => (
        <FormControlLabel
          key={index}
          control={
            <Checkbox
              name={column.id}
              style={{color : blue[500]}}
              className={classes.props}
              value={addCure[column.id]}
              onClick={handleCure}
              checked={addCure[column.id]} />
          }
          label={column.label}
        />
      ))}
    </div>
  );
}