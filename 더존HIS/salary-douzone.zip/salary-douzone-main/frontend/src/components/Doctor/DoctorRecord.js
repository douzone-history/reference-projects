import TextField from '@material-ui/core/TextField';
import React from 'react';

export default function DoctorRecord({ handleDoctorMemo, doctorMemo }) {
    const notifyMemo = (e) => {
        handleDoctorMemo(e.target.value);
    }

    return (
        <div>
            <TextField
                multiline
                variant="outlined"
                rows={4}
                fullWidth
                onChange={notifyMemo}
                value={doctorMemo ? doctorMemo : ''}
            />
        </div>
    )
}