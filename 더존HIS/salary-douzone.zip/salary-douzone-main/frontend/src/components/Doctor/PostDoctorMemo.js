import TextField from '@material-ui/core/TextField';
import React from 'react';

export default function PostDoctorMemo({ handleMention, mention }) {
    const notifyMemo = (e) => {
        handleMention(e.target.value);
    }

    return (
        <div>
            <TextField
                multiline
                variant="outlined"
                rows={4}
                fullWidth
                value={ mention ? mention : ''}
                onChange={notifyMemo}
            />
        </div>
    )
}