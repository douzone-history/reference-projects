import blue from '@material-ui/core/colors/blue';
import IconButton from '@material-ui/core/IconButton';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import TextField from '@material-ui/core/TextField';
import SearchIcon from '@material-ui/icons/Search';
import React, { useState } from 'react';
import Modal from 'react-modal';
import modalStyles from '../../assets/scss/doctormodal.scss';
Modal.setAppElement('body');

const columns = [
    { id: 'sickCd', label: '상병코드' },
    { id: 'sickNm', label: '상병명' },
    { id: 'priority', label: '주,부상병' },
];

const diseaseColumns = [
    { id: 'sickCd', label: '상병코드', width: '35%' },
    { id: 'sickNm', label: '상병명', width: '65%' },
]

const useStyles = makeStyles(() => ({
    head: {
        backgroundColor: blue[500],
        color: 'white',
        fontSize: 16,
        textAlign: 'center',
        width: '30%',
        fontWeight: 'bold'
    },
    diseaseCell: {
        textAlign: 'center',
    },
    textContainer: {
        display: 'block',
        width : '158px',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow : 'ellipsis'
    }
}));

const initialState = {
    mouseX: null,
    mouseY: null,
};

export default function PatientDisease({ diseases, handleDiseaseKeyword, handleAddDisease, updateDisease, updatePriority, modifyDiseaseHandle, removeDisease, checkDiseaseFirst, handleDiseaseFirst, isChecked }) {
    const classes = useStyles();
    const listPerPage = 5;
    const [listPage, setListPage] = useState(0);
    const [diseasePage, setDiseasePage] = useState(0);
    const [diseasePerPage, setDiseasePerPage] = useState(5);
    const [diseaseModal, setDiseaseModal] = useState(false);
    const [state, setState] = useState(initialState);
    const [selectDisease, setSelectDisease] = useState();
    const [firstAddFlag, setFirstAddFlag] = useState(false);
    const emptyRows = 5 - Math.min(5, updateDisease.length - listPage * 5);

    const handleListPage = (event, newPage) => {
        setListPage(newPage);
    };

    const handleDiseasePage = (event, newPage) => {
        setDiseasePage(newPage);
    };

    const handleChangeDiseasePerPage = (event) => {
        setDiseasePerPage(+event.target.value);
        setDiseasePage(0);
    };

    const initKeyword = (e) => {
        if(!firstAddFlag) {
            handleDiseaseFirst(true);
        }
        handleDiseaseKeyword('all');
        setDiseaseModal(false);
    }

    const notifyKeyword = (e) => {
        handleDiseaseKeyword(e.target.value);
        setDiseasePage(0);
    }

    const selectDiseaseRow = (flag, idx) => {
        modifyDiseaseHandle(flag, idx);
        setDiseaseModal(true);
    }

    const modifyDisease = (row) => {
        if(!firstAddFlag){
            setFirstAddFlag(true);
        }
        handleAddDisease(row)
        setDiseaseModal(false);
    }

    const handlePriority = (event, idx) => {
        updatePriority(event, idx);
    }

    const handleFirstAdd = (e) => {
        if (checkDiseaseFirst) {
            handleDiseaseFirst(false);
            setDiseaseModal(true);
        } else {
            e.preventDefault();
        }
    }

    const handleContextMenu = (e, row, idx) => {
        if (row.sickCd != '') {
            e.preventDefault()
            setSelectDisease({ row, idx })
            setState({
                mouseX: e.clientX,
                mouseY: e.clientY,
            });
        }
    }

    const handleCancelOrder = () => {
        setListPage(0);
        removeDisease(selectDisease);
        setState(initialState);
    }

    return (
        <Paper>
            {/* 상병 내역 테이블 */}
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            {columns.map((column, idx) => (
                                <TableCell
                                    className={classes.head}
                                    key={column.id}
                                >
                                    {column.label}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>

                    <TableBody onClick={isChecked.progress == '진료중' ? handleFirstAdd : null}>
                        {updateDisease.slice(listPage * listPerPage, listPage * listPerPage + listPerPage).map((row, idx) => {
                            return (
                                <TableRow
                                    hover role="updatePrioritybox"
                                    tabIndex={-1}
                                    key={idx}
                                    onContextMenu={(e) => handleContextMenu(e, row, (listPage * listPerPage) + idx)}
                                >
                                    {columns.map((column, index) => {
                                        const value = column.id === 'priority' ? 'combo' : row[column.id];
                                        return (
                                            value === 'combo' ?
                                                <TableCell
                                                    className={classes.diseaseCell}
                                                    key={index}>
                                                    {row['sickNm'] != '' ?
                                                        <select name="disease"
                                                            onClick={() => handlePriority(event, (listPage * listPerPage) + idx)}
                                                        >
                                                            <option value='none'>구분</option>
                                                            <option value='주'>주상병</option>
                                                            <option value='부'>부상병</option>
                                                        </select> : null}
                                                </TableCell>
                                                :
                                                <TableCell
                                                    className={classes.diseaseCell}
                                                    key={index}
                                                    onClick={() => ( (column.id === 'sickCd' || column.id === 'sickNm') && row[column.id] !== '') ?
                                                        selectDiseaseRow(true, (listPage * listPerPage) + idx) : selectDiseaseRow(false, (listPage * listPerPage) + idx)}>
                                                    <div className={classes.textContainer}>
                                                        {value}
                                                    </div>
                                                </TableCell>
                                        );
                                    })}

                                    <Menu
                                        open={state.mouseY !== null}
                                        onClose={() => setState(initialState)}
                                        anchorReference="anchorPosition"
                                        anchorPosition={
                                            state.mouseY !== null && state.mouseX !== null
                                                ? { top: state.mouseY, left: state.mouseX }
                                                : undefined
                                        }
                                    >
                                        <MenuItem onClick={() => handleCancelOrder(row)}>항목 삭제</MenuItem>
                                    </Menu>
                                </TableRow>
                            );
                        })}
                        {emptyRows > 0 && (
                            <TableRow style={{ height: 53 * emptyRows }}>
                                <TableCell colSpan={6} />
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[5]}
                component="div"
                count={updateDisease.length}
                rowsPerPage={listPerPage}
                page={listPage}
                onPageChange={handleListPage}
            />

            {/* 상병명 및 상병 코드 클릭 모달 */}
            <Modal
                isOpen={diseaseModal}
                onRequestClose={initKeyword}
                shouldCloseOnOverlayClick={true}
                className={modalStyles.Modal}
                overlayClassName={modalStyles.Overlay}
            >
                <div>
                    <TextField
                        label="상병명 및 상병 코드를 입력하세요"
                        style={{ width: 635, fontSize: 20, paddingLeft: 20 }}
                        onChange={notifyKeyword}
                    />

                    <IconButton
                        aria-label="delete"
                        style={{ marginTop: 20 }}>
                        <SearchIcon fontSize='large' />
                    </IconButton>
                </div>

                {/* 상병명 및 상병 코드 테이블 */}
                <TableContainer>
                    <Table aria-label="sticky table">
                        <TableHead style={{ backgroundColor: blue[500] }}>
                            <TableRow>
                                {diseaseColumns.map((column, idx) => (
                                    <TableCell
                                        key={idx}
                                        align={'center'}
                                        style={{ width: column.width, color: 'white', maxWidth: 200 }}
                                    >
                                        {column.label}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>

                        <TableBody>
                            {diseases.slice(diseasePage * diseasePerPage, diseasePage * diseasePerPage + diseasePerPage).map((row, idx) => {
                                return (
                                    <TableRow
                                        hover role="updatePrioritybox"
                                        tabIndex={-1}
                                        key={idx}
                                        onClick={() => modifyDisease(row)}>
                                        {diseaseColumns.map((column, idx) => {
                                            const value = row[column.id];
                                            return (
                                                <TableCell key={idx} className={classes.diseaseCell}>
                                                    {value}
                                                </TableCell>
                                            );
                                        })}
                                    </TableRow>
                                );
                            })}
                        </TableBody>
                    </Table>
                </TableContainer>

                <TablePagination
                    rowsPerPageOptions={[5]}
                    component="div"
                    count={diseases.length}
                    rowsPerPage={diseasePerPage}
                    page={diseasePage}
                    onPageChange={handleDiseasePage}
                    onRowsPerPageChange={handleChangeDiseasePerPage}
                />
            </Modal>
        </Paper>
    );
}