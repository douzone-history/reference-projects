import blue from '@material-ui/core/colors/blue';
import IconButton from '@material-ui/core/IconButton';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import TextField from '@material-ui/core/TextField';
import SearchIcon from '@material-ui/icons/Search';
import React, { useState } from 'react';
import Modal from 'react-modal';
import modalStyles from '../../assets/scss/doctormodal.scss';
Modal.setAppElement('body');

const columns = [
    { id: 'itemSeq', label: 'EDI코드' },
    { id: 'itemName', label: '명칭' },
    { id: 'dose', label: '용량' },
    { id: 'daily_dose', label: '일 투여량' },
    { id: 'total_dose', label: '총 투여량' },
];

const medicineColumns = [
    { id: 'itemSeq', label: 'EDI코드', width: '35%' },
    { id: 'itemName', label: '명칭', width: '65%' },
]

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
    },
    container: {
        maxHeight: 440,
    },
    head: {
        backgroundColor: blue[500],
        color: theme.palette.text.primary,
        fontSize: 16,
        textAlign: 'center',
    },
    textContainer: {
        display: 'block',
        width : '100px',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow : 'ellipsis',
        textAlign: 'left',
    }
}));

const initialState = {
    mouseX: null,
    mouseY: null,
};

export default function Prescription({ medicines, handleMedicineKeyword, handleAddMedicine, updateMedicine, updateDose, modifyMedicineHandle, removeMedicine, checkMedicineFirst, handleMedicineFirst, isChecked }) {
    const classes = useStyles();
    const listPerPage = 5;
    const [listPage, setListPage] = useState(0);
    const [medicinePage, setMedicinePage] = useState(0);
    const [medicinePerPage, setMedicinePerPage] = useState(5);
    const [medicineModal, setMedicineModal] = useState(false);
    const [state, setState] = useState(initialState);
    const [selectMedicine, setSelectMedicine] = useState();
    const [firstAddFlag, setFirstAddFlag] = useState(false);
    const emptyRows = 5 - Math.min(5, updateMedicine.length - listPage * 5);

    const handleListPage = (event, newPage) => {
        setListPage(newPage);
    };

    const handleMedicinePage = (event, newPage) => {
        setMedicinePage(newPage);
    };

    const handleChangeMedicinePerPage = (event) => {
        setMedicinePerPage(+event.target.value);
        setMedicinePage(0);
    };

    const initKeyword = () => {
        if(!firstAddFlag) {
            handleMedicineFirst(true);
        }
        handleMedicineKeyword('all');
        setMedicineModal(false);
    }

    const notifyKeyword = (e) => {
        handleMedicineKeyword(e.target.value);
        setMedicinePage(0);
    }

    const selectMedicineRow = (flag, idx) => {
        modifyMedicineHandle(flag, idx)
        setMedicineModal(true);
    }

    const modifyMedicine = (row) => {
        if(!firstAddFlag){
            setFirstAddFlag(true);
        }
        handleAddMedicine(row)
        setMedicineModal(false);
    }

    const handleDose = (event, id, idx) => {
        updateDose(event, id, idx);
    }

    const handleFirstAdd = (e) => {
        if (checkMedicineFirst) {
            handleMedicineFirst(false);
            setMedicineModal(true);
        } else {
            e.preventDefault();
        }
    }

    const handleContextMenu = (e, row, idx) => {
        if (row.itemSeq != '') {
            e.preventDefault()
            setSelectMedicine({ row, idx })
            setState({
                mouseX: e.clientX,
                mouseY: e.clientY,
            });
        }
    }

    const handleCancelOrder = () => {
        setListPage(0);
        removeMedicine(selectMedicine);
        setState(initialState);
    }

    return (
        <Paper className={classes.root}>
            <TableContainer
                className={classes.container}>
                <Table>
                    <TableHead>
                        <TableRow>
                            {columns.map((column, idx) => (
                                <TableCell
                                    className={classes.head}
                                    key={column.id}
                                    align={'center'}
                                    style={{ width: column.width, color: 'white', fontWeight: 'bold' }}
                                >
                                    {column.label}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>

                    <TableBody onClick={isChecked.progress == '진료중' ? handleFirstAdd : null}>
                        {
                            updateMedicine.slice(listPage * listPerPage, listPage * listPerPage + listPerPage).map((row, idx) => {
                                return (
                                    <TableRow
                                        hover role="checkbox"
                                        tabIndex={-1}
                                        key={idx}
                                        onContextMenu={(e) => handleContextMenu(e, row, (listPage * listPerPage) + idx)}
                                    >
                                        {columns.map((column, index) => {
                                            const value = column.id === 'dose' || column.id === 'daily_dose' || column.id === 'total_dose' ? 'input' : row[column.id];
                                            return (
                                                value === 'input' ?
                                                <TableCell
                                                    key={index}
                                                    align={'center'}>
                                                    {row['itemName'] != '' ?
                                                        <input
                                                            type="number"
                                                            min={0}
                                                            value={row[column.id]}
                                                            style={{ width: 45, fontSize: 15, textAlign: 'center' }}
                                                            onChange={() => handleDose(event, column.id, (listPage * listPerPage) + idx)} />
                                                        : null}
                                                </TableCell>
                                                    : <TableCell
                                                        key={index}
                                                        align={'center'}
                                                        onClick={() => ( (column.id === 'itemSeq' || column.id === 'itemName') && row[column.id] !== '') ?
                                                            selectMedicineRow(true, (listPage * listPerPage) + idx) : selectMedicineRow(false, (listPage * listPerPage) + idx)}>
                                                        <div className={classes.textContainer}>
                                                            {value}
                                                        </div>
                                                    </TableCell>
                                            );
                                        })}

                                        <Menu
                                            keepMounted
                                            open={state.mouseY !== null}
                                            onClose={() => setState(initialState)}
                                            anchorReference="anchorPosition"
                                            anchorPosition={
                                                state.mouseY !== null && state.mouseX !== null
                                                    ? { top: state.mouseY, left: state.mouseX }
                                                    : undefined
                                            }
                                        >
                                            <MenuItem onClick={() => handleCancelOrder(row)}>항목 삭제</MenuItem>
                                        </Menu>

                                    </TableRow>
                                );
                            })
                        }
                        {
                            emptyRows > 0 && (
                                <TableRow style={{ height: 53 * emptyRows }}>
                                    <TableCell colSpan={6} />
                                </TableRow>
                            )
                        }
                    </TableBody>
                </Table>
            </TableContainer>

            <TablePagination
                rowsPerPageOptions={[5]}
                component="div"
                count={updateMedicine.length}
                rowsPerPage={listPerPage}
                page={listPage}
                onPageChange={handleListPage}
            />

            {/*  */}
            <Modal
                isOpen={medicineModal}
                onRequestClose={initKeyword}
                shouldCloseOnOverlayClick={true}
                className={modalStyles.Modal}
                overlayClassName={modalStyles.Overlay}
                style={{ content: { width: 750, height: 550 } }}>
                <div>
                    <TextField
                        label="EDI 코드 및 명칭을 입력하세요"
                        style={{ width: 635, fontSize: 20, paddingLeft: 20 }}
                        onChange={notifyKeyword}
                    />

                    <IconButton
                        aria-label="delete"
                        style={{ marginTop: 20, paddingLeft: 18 }}>
                        <SearchIcon fontSize='large' />
                    </IconButton>
                </div>

                <TableContainer
                    className={classes.container}
                    style={{ width: 735, height: 360, marginTop: 5, }}>
                    <Table aria-label="sticky table">
                        <TableHead style={{ backgroundColor: blue[500] }}>
                            <TableRow>
                                {medicineColumns.map((column, idx) => (
                                    <TableCell
                                        key={idx}
                                        align={'center'}
                                        style={{ width: column.width, color: 'white', maxWidth: 200 }}
                                    >
                                        {column.label}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>

                        <TableBody>
                            {medicines.slice(medicinePage * medicinePerPage, medicinePage * medicinePerPage + medicinePerPage).map((row, idx) => {
                                return (
                                    <TableRow
                                        hover role="checkbox"
                                        tabIndex={-1}
                                        key={idx}
                                        onClick={() => modifyMedicine(row)}>
                                        {medicineColumns.map((column, idx) => {
                                            const value = row[column.id];
                                            return (
                                                <TableCell key={idx} align={'center'}>
                                                    {column.format && typeof value === "number"
                                                        ? column.format(value)
                                                        : value}
                                                </TableCell>
                                            );
                                        })}
                                    </TableRow>
                                );
                            })}
                        </TableBody>
                    </Table>
                </TableContainer>

                <TablePagination
                    rowsPerPageOptions={[5]}
                    component="div"
                    count={medicines.length}
                    rowsPerPage={medicinePerPage}
                    page={medicinePage}
                    onPageChange={handleMedicinePage}
                    onRowsPerPageChange={handleChangeMedicinePerPage}
                />
            </Modal>
        </Paper>
    );
}
