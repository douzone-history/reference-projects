import blue from '@material-ui/core/colors/blue';
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import React, { useState, useEffect } from 'react';

const columns = [
    { id: 'no', label: '순번' },
    { id: 'name', label: '이름' },
    { id: 'gender', label: '성별' },
    { id: 'age', label: '나이' },
    { id: 'progress', label: '상태' }
];

const useStyles = makeStyles(() => ({
    head: {
        backgroundColor: blue[500],
        fontSize: 16,
        textAlign: 'center',
        color: 'white',
        fontWeight: 'bold',
        width: '20%',
    },
    alignCell: {
        textAlign: 'center',
    }
}));

export default function PatientOrderList({ patientOrderList, getPatientInfo, statusMenu }) {
    const classes = useStyles();
    const [page, setPage] = useState(0);
    const emptyRows = 5 - Math.min(5, patientOrderList.length - page * 5);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const notifyPatient = (patient) => {
        getPatientInfo(patient);
    }

    useEffect(() => {
        setPage(0);
    },[statusMenu])

    return (
        <Paper>
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            {columns.map((column, index) => (
                                <TableCell className={classes.head}
                                    key={index}>
                                    {column.label}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>

                    <TableBody>
                        {patientOrderList.slice(page * 5, page * 5 + 5).map((row, index) => {
                            return (
                                <TableRow
                                    hover role="checkbox"
                                    tabIndex={-1}
                                    key={index}
                                    onClick={() => notifyPatient(row)}>
                                    {columns.map((column) => {
                                        let value = column.id == 'no' ? (page * 5) + index + 1 : row[column.id];
                                        return (
                                            <TableCell className={classes.alignCell}
                                                key={column.id}>
                                                {value}
                                            </TableCell>
                                        );
                                    })}
                                </TableRow>
                            );
                        })}
                        {emptyRows > 0 && (
                            <TableRow style={{ height: 53 * emptyRows }}>
                                <TableCell colSpan={6} />
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </TableContainer>

            <TablePagination
                rowsPerPageOptions={[5]}
                component="div"
                count={patientOrderList.length}
                rowsPerPage={5}
                page={page}
                onPageChange={handleChangePage}
            />
        </Paper>
    );
}
