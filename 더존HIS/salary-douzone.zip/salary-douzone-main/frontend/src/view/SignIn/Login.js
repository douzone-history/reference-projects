import LocalHospitalIcon from '@material-ui/icons/LocalHospital';
import Avatar from '@material-ui/core/Avatar';
import Box from '@material-ui/core/Box';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography';
import React, { useState } from 'react';
import styles from '../../assets/scss/Login.scss';

function Copyright() {
  return (
    <Typography variant="body2" color="textSecondary" align="center">
      {'Copyright © 더조은HIS '}
      {new Date().getFullYear()}
    </Typography>
  );
}

export default function Login() {
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState({
    id: "",
    password: "",
  });
  const { id, password } = user;
  const [modalConent, setModalConent] = useState('');

  const handleClickOpen = async function () {
    try {
      const response = await fetch('/api/member/login', {
        method: 'POST',
        mode: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(user)
      })

      if (!response.ok) {
        throw new Error(`${response.status} ${response.statusText}`);
      }

      const json = await response.json();
      if (json.result !== 'success') {
        throw new Error(`${json.result} ${json.message}`);
      }

      if (json.data === null) {
        setOpen(true);
        setUser({
          ...user,
          password: ''
        })
        setModalConent('아이디나 비밀번호가 일치하지 않습니다.');
      } else if (json.data == 'retired') {
        setOpen(true);
        setUser({
          ...user,
          password: ''
        })
        setModalConent(`사용할 수 없는 계정입니다. 관리자에게 문의하세요.`);
      } else {
        window.sessionStorage.setItem('isAuth', true);
        window.sessionStorage.setItem('no', json.data[0].no);
        window.sessionStorage.setItem('role', json.data[0].role);
        window.sessionStorage.setItem('name', json.data[0].name);

        if (json.data[0].role === 'doctor') {
          window.location.href = '/doctor'
        } else if (json.data[0].role === 'nurse') {
          window.location.href = '/nurse'
        } else {
          window.location.href = '/admin'
        }
      }

    } catch (err) {
      console.error(err);
    }
  };

  const onChangeUser = (e) => {
    setUser({
      ...user,
      [e.target.name]: e.target.value,
    });
  };

  const onKeyPress = (e) => {
    if (e.key == 'Enter') {
      handleClickOpen();
    }
  }

  return (
    <Grid container component="main" className={styles.root}>
      <CssBaseline />
      <Grid item xs={12} sm={8} md={5}>
        <div className={styles.paper}>
          <Avatar className={styles.avatar}>
            <LocalHospitalIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            더조은HIS
          </Typography>

          <form className={styles.form} noValidate onKeyPress={onKeyPress}>
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              label="아이디"
              name="id"
              value={id}
              autoComplete="id"
              autoFocus
              onChange={onChangeUser}
            />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              name="password"
              label="비밀번호"
              type="password"
              value={password}
              onChange={onChangeUser}
              autoComplete="current-password"
            />

            <Button className={styles.button} onClick={handleClickOpen} >
              로그인
            </Button>

            {!open ? null :
              <Dialog open={open}>
                <DialogContent>
                  {modalConent}
                </DialogContent>
                <DialogActions>
                  <Button onClick={() => setOpen(false)} fullWidth>
                    확인
                  </Button>
                </DialogActions>
              </Dialog>
            }

            <Box mt={5}>
              <Copyright />
            </Box>
          </form>
        </div>
      </Grid>
    </Grid>
  );
}