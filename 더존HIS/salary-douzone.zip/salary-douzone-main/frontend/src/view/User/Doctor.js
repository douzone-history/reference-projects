import Box from '@material-ui/core/Box';
import Button from '@material-ui/core/Button';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import blue from '@material-ui/core/colors/blue';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import { makeStyles } from '@material-ui/core/styles';
import moment from 'moment';
import React, { useEffect, useState } from 'react';
import update from 'react-addons-update';
import io from 'socket.io-client';
import GridContainer from '../../components/common/GridContainer';
import GridItem from '../../components/common/GridItem';
import PatientHistory from '../../components/common/PatientHistory';
import SiteLayout from '../../components/common/SiteLayout';
import StatusMenu from '../../components/common/StatusMenu';
import DoctorRecord from '../../components/Doctor/DoctorRecord';
import GetNurseMemo from '../../components/Doctor/GetNurseMemo';
import MedicalCure from '../../components/Doctor/MedicalCure';
import PatientDisease from '../../components/Doctor/PatientDisease';
import PatientInfo from '../../components/Doctor/PatientInfo';
import PatientOrderList from '../../components/Doctor/PatientOrderList';
import PostDoctorMemo from '../../components/Doctor/PostDoctorMemo';
import Prescription from '../../components/Doctor/Prescription';

const socket = io.connect("http://localhost:8888", { transports: ['websocket'] });
const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

const useStyles = makeStyles(() => ({
    box: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    buttons: {
        marginTop: 10,
        color: 'white',
        backgroundColor: blue[500]
    },
    dialogTitle: {
        backgroundColor: blue[500], color: 'white'
    },
}));

export default function Doctor() {
    var clinicNo = 0;
    const classes = useStyles();
    const [diseases, setDiseases] = useState([]);
    const [medicines, setMedicines] = useState([]);
    const [addCure, setAddCure] = useState({
        injection: false,
        dressing: false,
        gips: false,
        physics: false,
        xray: false
    });
    const [filterDiseases, setFilterDiseases] = useState([]);
    const [diseaseKeyword, setDiseaseKeyword] = useState('all');
    const [filterMedicines, setFilterMedicines] = useState([]);
    const [medicineKeyword, setMedicineKeyword] = useState('all');
    const [doctorMemo, setDoctorMemo] = useState('');
    const [mention, setMention] = useState('');
    const [nurseMemo, setNurseMemo] = useState('');
    const [selectpatient, setSelectPatient] = useState([]);
    const [statusMenu, setStatusMenu] = useState(0);
    const [patientOrderList, setPatientOrderList] = useState([]);
    const [progress, setProgress] = useState(false);
    const [alertModal, setAlertModal] = useState(false);
    const [alertPatient, setAlertPatient] = useState({ name: '', gender: '', age: '', memo: '' });
    const [medicineIndex, setMedicineIndex] = useState(0);
    const [updateMedicineFlag, setUpdateMedicineFlag] = useState(false);
    const [updateMedicine, setUpdateMedicine] = useState([])
    const [diseaseIndex, setDiseaseIndex] = useState(0);
    const [updateDiseaseFlag, setUpdateDiseaseFlag] = useState(false);
    const [updateDisease, setUpdateDisease] = useState([]);
    const [clinicHistory, setClinicHistory] = useState([])
    const [detail, setDetail] = useState([]);
    const [firstMedicineAdd, setFirstMedicineAdd] = useState(false)
    const [firstDiseaseAdd, setFirstDiseaseAdd] = useState(false)
    const [checkMedicineFirst, setCheckMedicineFirst] = useState(true);
    const [checkDiseaseFirst, setCheckDiseaseFirst] = useState(true);
    const [incorrect, setIncorrect] = useState(false);
    const [diseaseMessage,setDiseaseMessage] = useState('');
    const [medicineMessage,setMedicineMessage] = useState('');

    const handleMedicineFirst = (flag) => {
        setCheckMedicineFirst(flag);
    }

    const handleDiseaseFirst = (flag) => {
        setCheckDiseaseFirst(flag);
    }

    const modifyDiseaseHandle = (flag, idx) => {
        setUpdateDiseaseFlag(flag);
        setDiseaseIndex(idx);
    }

    const handleAddDisease = (newDisease) => {
        if (updateDiseaseFlag) {
            setUpdateDisease(update(updateDisease, {
                [diseaseIndex]: {
                    sickCd: { $set: newDisease.sickCd },
                    sickNm: { $set: newDisease.sickNm }
                },
            }));
        } else {
            if (diseaseIndex == 0 && !firstDiseaseAdd) {
                setFirstDiseaseAdd(true);
                setUpdateDisease(update(updateDisease, {
                    $push: [{
                        sickCd: newDisease.sickCd,
                        sickNm: newDisease.sickNm,
                        priority: 'none'
                    }, {
                        sickCd: '',
                        sickNm: '',
                        priority: 'none'
                    }]
                }));
            } else {
                setUpdateDisease(update(updateDisease, {
                    [diseaseIndex]: {
                        sickCd: { $set: newDisease.sickCd },
                        sickNm: { $set: newDisease.sickNm },
                    },
                    $push: [{
                        sickCd: '',
                        sickNm: '',
                        priority: 'none'
                    }]
                }));
            }
        }
    }

    const updatePriority = (event, idx) => {
        setUpdateDisease(update(updateDisease, {
            [idx]: {
                priority: { $set: event.target.value }
            }
        }))
    }

    const modifyMedicineHandle = (flag, idx) => {
        setUpdateMedicineFlag(flag);
        setMedicineIndex(idx);
    }

    const handleAddMedicine = (newMedicine) => {
        if (updateMedicineFlag) {
            setUpdateMedicine(update(updateMedicine, {
                [medicineIndex]: {
                    itemName: { $set: newMedicine.itemName },
                    itemSeq: { $set: newMedicine.itemSeq }
                },
            }));
        } else {
            if (medicineIndex == 0 && !firstMedicineAdd) {
                setFirstMedicineAdd(true);
                setUpdateMedicine(update(updateMedicine, {
                    $push: [{
                        itemName: newMedicine.itemName,
                        itemSeq: newMedicine.itemSeq,
                        dose: '',
                        daily_dose: '',
                        total_dose: ''
                    }, {
                        itemName: '',
                        itemSeq: '',
                        dose: '',
                        daily_dose: '',
                        total_dose: ''
                    }]
                }));
            } else {
                setUpdateMedicine(update(updateMedicine, {
                    [medicineIndex]: {
                        itemName: { $set: newMedicine.itemName },
                        itemSeq: { $set: newMedicine.itemSeq },
                    },
                    $push: [{
                        itemName: '',
                        itemSeq: '',
                        dose: '',
                        daily_dose: '',
                        total_dose: ''
                    }]
                }));
            }
        }
    }

    const updateDose = (event, id, idx) => {
        setUpdateMedicine(update(updateMedicine, {
            [idx]: {
                [id]: { $set: event.target.value }
            }
        }))
    }

    const getDetailHistory = async function (clinic) {
        try {
            const response = await fetch(`/api/clinic/detail/${clinic.no}`, {
                method: 'get',
                headers: { 'Content-Type': 'application/json' },
                body: null
            })

            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }

            const json = await response.json();
            if (json.result !== 'success') {
                throw new Error(`${json.result} ${json.message}`);
            }

            setDetail(json.data);
        } catch (err) {
            console.error(err);
        }
    }

    useEffect(
        async () => {
            try {
                const response = await fetch('/api/disease', {
                    method: 'get',
                    headers: { 'Content-Type': 'application/json' },
                    body: null
                });

                if (!response.ok) {
                    throw new Error(`${response.status} ${response.statusText}`);
                }

                const json = await response.json();
                if (json.result !== 'success') {
                    throw new Error(`${json.result} ${json.message}`);
                }
                setDiseases(json.data);
            } catch (err) {
                console.error(err);
            }

            try {
                const response = await fetch('/api/medicine', {
                    method: 'get',
                    headers: { 'Content-Type': 'application/json' }
                });

                if (!response.ok) {
                    throw new Error(`${response.status} ${response.statusText}`);
                }

                const json = await response.json();
                if (json.result !== 'success') {
                    throw new Error(`${json.result} ${json.message}`);
                }
                setMedicines(json.data);
            } catch (err) {
                console.error(err);
            }

            try {
                const response = await fetch('/api/orders', {
                    method: 'get',
                    mode: 'same-origin',
                    header: {
                        'Content-Type': 'application/json'
                    },
                    body: null
                })

                if (!response.ok) {
                    throw new Error(`${response.status} ${response.statusText}`);
                }

                const json = await response.json();
                if (json.result !== 'success') {
                    throw new Error(`${json.result} ${json.message}`);
                }

                const sendData = json.data.map((order) => {
                    const year = new Date().getFullYear();
                    const age = order.registration_no.substr(7, 1) <= '2' ? parseInt('19' + order.registration_no.substr(0, 2)) : parseInt('20' + order.registration_no.substr(0, 2));

                    return ({
                        ...order,
                        gender: order.registration_no.substr(7, 1) % 2 == '1' ? '남자' : '여자',
                        age: year - age,
                        memo: order.nurse_message,
                        visit: order.visit ? '재진' : '초진',
                        insurance: order.insurance ? '있음' : '없음'
                    })
                });

                setPatientOrderList(sendData);
            } catch (err) {
                console.error(err);
            }
        }, [])

    const getPatientInfo = async function (patient) {
        setSelectPatient(patient);
        setNurseMemo(patient.nurse_message);
        setDoctorMemo('');
        setMention('');
        setAddCure({
            injection: false,
            dressing: false,
            gips: false,
            physics: false,
            xray: false
        });
        setUpdateMedicine([])
        setUpdateDisease([])
        setCheckDiseaseFirst(true);
        setCheckMedicineFirst(true);

        patient.progress === '진료중' ? setProgress(true) : setProgress(false)
        try {
            const response = await fetch(`/api/orders/record/${patient.no}`, {
                method: 'get',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: null
            })
            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }

            const json = await response.json();
            if (json.result !== 'success') {
                throw new Error(`${json.result} ${json.message}`);
            }

            setClinicHistory(json.data.map(history => {
                return ({
                    ...history,
                    reg_date: moment(history.reg_date).format('YYYY년 MM월 DD일')
                })
            }))
        } catch (err) {
            console.error(err)
        }
    }

    useEffect(() => {
        socket.on("receivepatientlist", (item) => {
            setPatientOrderList(patientOrderList.concat(item));
        })
        return () => {
            socket.off("receivepatientlist")
        }
    }, [patientOrderList]);

    useEffect(() => {
        socket.on("receivecuringpatient", (patient) => {
            setPatientOrderList(
                patientOrderList.map(item => item.no === patient.no ? ({ ...item, progress: '진료중' }) : item)
            );
            setAlertModal(true)
            setAlertPatient(patient)
        })
        return () => {
            socket.off("receivecuringpatient");
        }
    }, [patientOrderList]);

    useEffect(() => {
        socket.on("receiveCancelOrder", no => {
            setPatientOrderList(patientOrderList.filter(item => item.orderNo !== no));
        })
        return () => {
            socket.off("receiveCancelOrder")
        }
    }, [patientOrderList]);

    useEffect(() => {
        socket.on("receivefinishpatient", (orderNo) => {
            setPatientOrderList(
                patientOrderList.map(item => item.orderNo === orderNo ? ({ ...item, progress: '완료' }) : item)
            );
        })
        return () => {
            socket.off("receivefinishpatient")
        }
    }, [patientOrderList]);

    useEffect(() => {
        socket.on("receiveUpdatePatient", (item) => {
            setPatientOrderList(
                patientOrderList.map(listItem => listItem.no == item.no ? { ...listItem, name: item.name } : listItem)
            );
        })
        return () => {
            socket.off("receivepatientupdate")
        }
    }, [patientOrderList]);

    useEffect(() => {
        socket.on('receivepaywaiting', (patient) => {
            setPatientOrderList(
                patientOrderList.map((item) => item.no === patient.no ? ({ ...item, progress: '수납대기' }) : item)
            );           
        })
        return () => {
            socket.off("receivepaywaiting");
        }
    }, [patientOrderList])

    const handleStatusMenu = function (index) {
        setStatusMenu(index);
    }

    const handleDiseaseKeyword = function (keyword) {
        setDiseaseKeyword(keyword);
    }

    const handleMedicineKeyword = function (keyword) {
        setMedicineKeyword(keyword);
    }

    const handleDoctorMemo = function (memo) {
        setDoctorMemo(memo);
    }

    const handleMention = function (mention) {
        setMention(mention);
    }

    const handleAddCure = function (value, name) {
        setAddCure({
            ...addCure,
            [name]: value
        });
    }

    useEffect(() => {
        setFilterDiseases(diseases.filter(disease => disease.sickCd.indexOf(diseaseKeyword) != -1 || disease.sickNm.indexOf(diseaseKeyword) != -1));
    }, [diseaseKeyword])

    useEffect(() => {
        setFilterMedicines(medicines.filter(medicine => medicine.itemSeq.indexOf(medicineKeyword) != -1 || medicine.itemName.indexOf(medicineKeyword) != -1));
    }, [medicineKeyword])

    const handleSubmit = async () => {
        let incorrectDisease = true;
        let isMainDisease = false;
        let incorrectMedicine = true;

        updateDisease.forEach((element, idx) => {
            if(idx == updateDisease.length - 1) {
            } else {
                element.priority == 'none' ? incorrectDisease = false : null
                element.priority == '주' ? isMainDisease = true : null
            }
        })
        updateMedicine.forEach((element,idx) => {
            if(idx == (updateMedicine.length - 1)){
            } else {
                element.dose == '' ? incorrectMedicine = false : Number(element.dose) <= 0 ? incorrectMedicine = false : null
                element.daily_dose == '' ? incorrectMedicine = false : Number(element.daily_dose) <= 0 ? incorrectMedicine = false : null
                element.total_dose == '' ? incorrectMedicine = false : Number(element.total_dose) <= 0 ? incorrectMedicine = false : null
            }
        })
        updateDisease.length == [] ? isMainDisease = true : updateDisease[0].sickCd == '' ? isMainDisease = true : null;
        
        !incorrectDisease || !isMainDisease ? setDiseaseMessage('상병내역을 확인해주세요.') : null;
        !incorrectMedicine ? setMedicineMessage('처방 의약품을 확인해주세요.') : null;

        if(incorrectDisease && incorrectMedicine && isMainDisease) {
            setProgress(false);
            try {
                await fetch('/api/orders/update', {
                    method: 'post',
                    mode: 'same-origin',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({
                        ...selectpatient,
                        progress: '수납대기'
                    })
                })
    
                setPatientOrderList(
                    patientOrderList.map(item => item.no === selectpatient.no ? ({ ...item, progress: '수납대기' }) : item)
                );
    
                socket.emit("sendpaywaiting", selectpatient);
            } catch (err) {
                console.error(err);
            }
    
            const newClinic = {
                member_no: sessionStorage.getItem("no"),
                doctor_message: doctorMemo,
                mention: mention ? mention : '',
                orderNo: selectpatient.orderNo
            }
            try {
                const response = await fetch('/api/clinic', {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify(newClinic)
                })
    
                if (!response.ok) {
                    throw new Error(`${response.status} ${response.statusText}`);
                }
    
                const json = await response.json();
                if (json.result !== 'success') {
                    throw new Error(`${json.result} ${json.message}`);
                }
                clinicNo = json.data[0].no;
            } catch (err) {
                console.error(err);
            }
    
            try {
                await fetch('/api/history', {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify([clinicNo, updateDisease])
                })
            } catch (err) {
                console.error(err);
            }
    
            try {
                await fetch('/api/prescription', {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify([clinicNo, updateMedicine])
                })
            } catch (err) {
                console.error(err);
            }
    
            try {
                await fetch('/api/clinic_cure', {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify([clinicNo, addCure])
                })
            } catch (err) {
                console.error(err);
            }
    
            setAddCure({
                injection: false,
                dressing: false,
                gips: false,
                physics: false,
                xray: false
            });
            setUpdateMedicine([])
            setUpdateDisease([])
            setDoctorMemo('');
            setMention('');
            setCheckDiseaseFirst(true);
            setCheckMedicineFirst(true);
        } else {
            setIncorrect(true)
        }
    }

    const removeDisease = (item) => {
        setUpdateDisease(update(updateDisease, {
            $splice:
                [[item.idx, 1]]
        }));
    }

    const removeMedicine = (item) => {
        setUpdateMedicine(update(updateMedicine, {
            $splice:
                [[item.idx, 1]]
        }));
    }

    return (
        <SiteLayout>
            <GridContainer>
                <GridItem xs={12} sm={12} md={5}>
                    <Card style={{ marginTop: 10 }}>
                        <CardHeader title="환자 정보" />
                        <CardContent>
                            <PatientInfo selectpatient={selectpatient} />
                        </CardContent>
                    </Card>

                    <Card style={{ marginTop: 10 }}>
                        <CardHeader title="간호사 메모" />
                        <CardContent>
                            <GetNurseMemo nurseMemo={nurseMemo} />
                        </CardContent>
                    </Card>

                    <Card style={{ marginTop: 10 }}>
                        <CardHeader title="환자접수현황" />
                        <CardContent>
                            <div>
                                <StatusMenu
                                    handleStatusMenu={handleStatusMenu}
                                    statusMenu={statusMenu}
                                    patientOrderList={patientOrderList} />
                                <PatientOrderList
                                    patientOrderList={
                                        statusMenu === 0 ? patientOrderList :
                                            statusMenu === 1 ? patientOrderList.filter(patient => patient.progress === '진료대기') :
                                                statusMenu === 2 ? patientOrderList.filter(patient => patient.progress === '진료중') :
                                                    statusMenu === 3 ? patientOrderList.filter(patient => patient.progress === '수납대기') :
                                                        patientOrderList.filter(patient => patient.progress === '완료')}
                                    getPatientInfo={getPatientInfo}
                                    statusMenu={statusMenu} />
                            </div>
                        </CardContent>
                    </Card>
                </GridItem>

                <GridItem xs={12} sm={12} md={4}>
                    <Card style={{ marginTop: 10 }}>
                        <CardHeader title="상병 내역" />
                        <CardContent>
                            <PatientDisease
                                diseases={diseaseKeyword === 'all' ? diseases : filterDiseases}
                                handleDiseaseKeyword={handleDiseaseKeyword}
                                handleAddDisease={handleAddDisease}
                                updateDisease={updateDisease}
                                updatePriority={updatePriority}
                                modifyDiseaseHandle={modifyDiseaseHandle}
                                removeDisease={removeDisease}
                                checkDiseaseFirst={checkDiseaseFirst}
                                handleDiseaseFirst={handleDiseaseFirst}
                                isChecked={selectpatient} />
                        </CardContent>
                    </Card>

                    <Card style={{ marginTop: 25 }}>
                        <CardHeader title="처방 의약품" />
                        <CardContent>
                            <Prescription
                                medicines={medicineKeyword === 'all' ? medicines : filterMedicines}
                                handleMedicineKeyword={handleMedicineKeyword}
                                handleAddMedicine={handleAddMedicine}
                                updateMedicine={updateMedicine}
                                updateDose={updateDose}
                                modifyMedicineHandle={modifyMedicineHandle}
                                removeMedicine={removeMedicine}
                                checkMedicineFirst={checkMedicineFirst}
                                handleMedicineFirst={handleMedicineFirst}
                                isChecked={selectpatient} />
                        </CardContent>
                    </Card>

                    <Card style={{ marginTop: 25 }}>
                        <CardHeader title="진료 기록" />
                        <CardContent>
                            <DoctorRecord
                                handleDoctorMemo={handleDoctorMemo}
                                doctorMemo={doctorMemo} />
                        </CardContent>
                    </Card>
                </GridItem>

                <GridItem xs={12} sm={12} md={3}>
                    <Card style={{ marginTop: 10 }}>
                        <CardHeader title="내원 이력" />
                        <CardContent>
                            <PatientHistory
                                clinicHistory={clinicHistory}
                                getDetailHistory={getDetailHistory}
                                detail={detail}
                            />
                        </CardContent>
                    </Card>

                    <Card style={{ marginTop: 50 }}>
                        <CardHeader title="치료" />
                        <CardContent>
                            <MedicalCure
                                handleAddCure={handleAddCure}
                                addCure={addCure} />
                        </CardContent>
                    </Card>
                    <Card style={{ marginTop: 50 }}>
                        <CardHeader title="전달사항" />
                        <CardContent>
                            <PostDoctorMemo
                                handleMention={handleMention}
                                mention={mention} />
                        </CardContent>
                    </Card>

                    <Box className={classes.box}>
                        {
                            progress ?
                                <Button
                                    className={classes.buttons}
                                    fullWidth
                                    onClick={handleSubmit}>
                                    완료
                                </Button>
                                : ''
                        }
                    </Box>
                </GridItem>

                <Dialog
                    open={alertModal}
                    TransitionComponent={Transition}
                >

                    <DialogTitle className={classes.dialogTitle}>알림</DialogTitle>
                    {alertPatient ?
                        (
                            <DialogContent style={{ display: 'flow' }}>
                                <div style={{ width: '500px', fontSize: "30px", fontFamily: 'monospace', fontWeight: 'bolder', display: 'flex', justifyContent: 'center', margin: '20px' }}>
                                    {(`${alertPatient.name} 님 / ${alertPatient.age} / ${alertPatient.gender}`)}
                                </div>
                                <div style={{ fontSize: '20px', display: 'flex', justifyContent: 'center' }}>
                                    {`${alertPatient.memo != undefined ? alertPatient.memo : ''}`}
                                </div>
                            </DialogContent>
                        ) : null}

                    <DialogActions>
                        <Button variant="outlined" onClick={() => setAlertModal(false)} color="primary" >
                            닫기
                        </Button>
                    </DialogActions>
                </Dialog>
                
                <Dialog
                    open={incorrect}
                    TransitionComponent={Transition}
                >

                    <DialogTitle className={classes.dialogTitle}>알림</DialogTitle>
                            <DialogContent style={{ display: 'flow' }}>
                                <div style={{ width: '500px', fontSize: "20px", fontFamily: 'monospace', fontWeight: 'bolder', display: 'flex', justifyContent: 'center', margin: '20px' }}>
                                    {diseaseMessage}
                                </div>
                                <div style={{ width: '500px', fontSize: "20px", fontFamily: 'monospace', fontWeight: 'bolder', display: 'flex', justifyContent: 'center', margin: '20px', marginBottom: '0px' }}>
                                    {medicineMessage}
                                </div>
                            </DialogContent>
                    <DialogActions>
                        <Button variant="outlined" onClick={() => {setIncorrect(false); setDiseaseMessage(''); setMedicineMessage('')}} color="primary" >
                            닫기
                        </Button>
                    </DialogActions>
                </Dialog>
            </GridContainer>
        </SiteLayout>
    );
}