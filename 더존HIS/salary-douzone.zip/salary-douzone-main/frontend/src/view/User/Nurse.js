import Button from '@material-ui/core/Button';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import blue from '@material-ui/core/colors/blue';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import IconButton from '@material-ui/core/IconButton';
import InputBase from "@material-ui/core/InputBase";
import Slide from '@material-ui/core/Slide';
import { makeStyles } from '@material-ui/core/styles';
import SearchIcon from '@material-ui/icons/Search';
import React, { useEffect, useState } from 'react';
import DaumPostcode from "react-daum-postcode";
import { useForm } from "react-hook-form";
import Modal from "react-modal";
import moment from "moment";
import io from 'socket.io-client';
import modalStyles from '../../assets/scss/modal.scss';
import GridContainer from '../../components/common/GridContainer';
import GridItem from '../../components/common/GridItem';
import PatientHistory from '../../components/common/PatientHistory';
import SearchBox from '../../components/common/SearchBox';
import SiteLayout from '../../components/common/SiteLayout';
import StatusMenu from '../../components/common/StatusMenu';
import TextMaskCustom from '../../components/common/TextMaskCustom';
import GetDoctorMemo from '../../components/Nurse/GetDoctorMemo';
import GetPriceList from '../../components/Nurse/GetPriceList';
import PatientInfo from '../../components/Nurse/PatientInfo';
import PatientList from '../../components/Nurse/PatientList';
import PatientSelect from '../../components/Nurse/PatientListSelect';
import PatientOrderList from '../../components/Nurse/PatientOrderList';
import PatientUpdate from '../../components/Nurse/PatientUpdate';
import PostNurseMemo from '../../components/Nurse/PostNurseMemo';

const socket = io.connect("http://localhost:8888", { transports: ['websocket'] });
const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

const useStyles = makeStyles(() => ({
    root: {
        display: 'flex',
    },
    toolbar: {
        paddingRight: 24,
    },
    title: {
        flexGrow: 1,
    },
    table: {
        minWidth: 650,
    },
    buttons: {
        backgroundColor: blue[500],
        color: 'white',
        fontWeight: 'bold',
        "&:hover": {
            backgroundColor: blue[500]
        },
        marginRight: 15
    },
    dialogTitle: {
        backgroundColor: blue[500],
        color: 'white'
    },
    dialogDuplicate:{
        width : 500,
        fontSize : 20,
        fontFamily:'monospace',
        fontWeight: 'bold',
        display: 'flex',
        justifyContent: 'center',
        margin : 20
    }
}));

export default function Nurse() {
    const classes = useStyles();
    const [keyword, setKeyword] = useState('');
    const [nurseMemo, setNurseMemo] = useState('');
    const [doctorMemo, setDoctorMemo] = useState('');
    const [division, setDivision] = useState('all');
    const [total, setTotal] = useState(0);
    const [statusMenu, setStatusMenu] = useState(0);
    const [selectOrder, setSelectOrder] = useState(0);
    const [selectOrderNo, setSelectOrderNo] = useState(0);
    const [open, setOpen] = useState(false);
    const [post, setPost] = useState(false);
    const [progress, setProgress] = useState(false);
    const [modalIsOpen, setModalIsOpen] = useState(false);
    const [duplication, setDuplication] = useState(false);
    const [detail, setDetail] = useState([]);
    const [patient, setPatient] = useState([]);
    const [selectpatient, setSelectPatient] = useState([]);
    const [clinicHistory, setClinicHistory] = useState([])
    const [patientOrderList, setPatientOrderList] = useState([]);
    const [pay, setPay] = useState([
        { menu: '기본 진료비', selfprice: '', nationprice: '' },
        { menu: '야간 할증료', selfprice: '', nationprice: '' },
        { menu: '시술 처치료', selfprice: '', nationprice: '' },
        { menu: '투약 조제료', selfprice: '', nationprice: '' },
        { menu: '합계', selfprice: '', nationprice: '' },
    ]);
    const [input, setInput] = useState({
        name: '',
        registration_no: '',
        cellphone: '',
        insurance: '',
        memo: '',
        address: '',
        detailaddress: '',
        zipcode: ''
    });

    // 내원 이력 상세 정보 가져오는 API
    const getDetailHistory = async function (clinic) {
        try {
            const response = await fetch(`/api/clinic/detail/${clinic.no}`, {
                method: 'get',
                headers: { 'Content-Type': 'application/json' },
                body: null
            })

            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }

            const json = await response.json();
            if (json.result !== 'success') {
                throw new Error(`${json.result} ${json.message}`);
            }
            setDetail(json.data);
        } catch (err) {
            console.error(err);
        }
    }

    const onChange = (e) => {
        setInput({
            ...input,
            [e.target.name]: e.target.value
        })
    };

    const onCompletePost = (data) => {
        setInput({
            ...input,
            address: data.address,
            zipcode: data.zonecode
        });
        setPost(false);
    };

    const handleAddressOpen = () => {
        setOpen(true);
        setPost(true);
    };

    const { register, reset, handleSubmit, formState: { errors } } = useForm();

    const onSubmit = async function (e) {
        setModalIsOpen(false);
        try {
            const response = await fetch('/api/patient', {
                method: 'post',
                mode: 'same-origin',

                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(input)
            });
            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }

            const json = await response.json();
            if (json.result !== 'success') {
                throw new Error(`${json.result} ${json.message}`);
            }

            socket.emit("sendAddPatient", json.data[0]);
        } catch (err) {
            console.error(err);
        }
    }

    const getPatientInfo = async (patient) => {
        setSelectOrder(patient.no);
        setSelectOrderNo(patient.orderNo);
        setNurseMemo('');
        setDoctorMemo('');
        setProgress(false);
        setPay([
            { menu: '기본 진료비', selfprice: '', nationprice: '' },
            { menu: '야간 할증료', selfprice: '', nationprice: '' },
            { menu: '시술 처치료', selfprice: '', nationprice: '' },
            { menu: '투약 조제료', selfprice: '', nationprice: '' },
            { menu: '합계', selfprice: '', nationprice: '' },
        ])

        try {
            const response = await fetch(`/api/orders/record/${patient.no}`, {
                method: 'get',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: null
            })
            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }

            const json = await response.json();
            if (json.result !== 'success') {
                throw new Error(`${json.result} ${json.message}`);
            }
            setClinicHistory(json.data.map(history => {
                return ({
                    ...history,
                    reg_date: moment(history.reg_date).format('YYYY년 MM월 DD일')
                })
            }))
        } catch (err) {
            console.error(err)
        }

        if (patient.progress === '수납대기') {
            setProgress(true);
            try {
                const response = await fetch(`/api/clinic/pay`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify(patient)
                })
                const json = await response.json();

                setDoctorMemo(json.data[0]);
                setPay(json.data[1]);
                setTotal(json.data[1][3].selfprice);
            } catch (err) {
                console.error(err);
            }
        }
    }

    const handleNurseMemo = (memo) => {
        setNurseMemo(memo);
    }

    const patientUpdate = (getItem) => {
        setSelectPatient({ ...selectpatient, ...getItem });

        socket.emit("sendUpdatePatient", getItem);
        socket.emit("sendUpdatePatientOfOrderList", getItem);
    }

    const handleOrder = async function () {
        let flag = true;
        patientOrderList.map(item => { item.no === selectpatient.no ? flag = false : null; })

        if (flag == true) {
            const addOrders = {
                ...selectpatient,
                progress: '진료대기',
                memo: nurseMemo
            }
            setNurseMemo('');
            const memberNo = sessionStorage.getItem('no');
            try {
                const response = await fetch('/api/orders', {
                    method: 'post',
                    mode: 'same-origin',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify([selectpatient, nurseMemo, memberNo])
                });
                if (!response.ok) {
                    throw new Error(`${response.status} ${response.statusText}`);
                }
                const json = await response.json();
                if (json.result !== 'success') {
                    throw new Error(`${json.result} ${json.message}`);
                }
                let orderNo = json.data[0].no

                socket.emit("sendpatientlist", { ...addOrders, orderNo });
            } catch (err) {
                console.error(err);
            }
        } else {
            setDuplication(true);
        }
    }

    useEffect(async () => {
        try {
            const response = await fetch('/api/patient', {
                method: 'get',
                mode: 'same-origin',
                header: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: null
            })

            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }

            const json = await response.json();
            if (json.result !== 'success') {
                throw new Error(`${json.result} ${json.message}`);
            }

            setPatient(json.data);

            setSelectPatient(makePatientInfo(json.data[0]));
        } catch (err) {
            console.error(err);
        }

        try {
            const response = await fetch('/api/orders', {
                method: 'get',
                mode: 'same-origin',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: null
            })

            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }

            const json = await response.json();
            if (json.result !== 'success') {
                throw new Error(`${json.result} ${json.message}`);
            }
            const sendData = json.data.map((order) => {
                const year = new Date().getFullYear();
                const age = order.registration_no.substr(7, 1) <= '2' ? parseInt('19' + order.registration_no.substr(0, 2)) : parseInt('20' + order.registration_no.substr(0, 2));

                return ({
                    ...order,
                    gender: order.registration_no.substr(7, 1) % 2 == '1' ? '남자' : '여자',
                    age: year - age,
                    memo: order.nurse_message,
                    visit: order.visit ? '재진' : '초진',
                    insurance: order.insurance ? '있음' : '없음'
                })
            });

            setPatientOrderList(sendData);
        } catch (err) {
            console.error(err);
        }

    }, []);

    const makePatientInfo = (info) => {
        const year = new Date().getFullYear();
        const age = info.registration_no.substr(7, 1) <= '2' ? parseInt('19' + info.registration_no.substr(0, 2)) : parseInt('20' + info.registration_no.substr(0, 2));
        const item = {
            ...info,
            age: year - age,
            gender: info.registration_no.substr(7, 1) % 2 == '1' ? '남자' : '여자',
            visit: info.visit ? '재진' : '초진',
            insurance: info.insurance ? '있음' : '없음',
            address: info.address,
            detailaddress: info.detailaddress
        }
        return item;
    }

    const notifyDivision = function (division) {
        setDivision(division);
    }

    const notifyKeyword = function (keyword) {
        setKeyword(keyword)
    }

    const handleStatusMenu = function (index) {
        setStatusMenu(index);
    }

    const cancelOrder = async (order) => {
        try {
            const response = await fetch('/api/orders/' + order.orderNo, {
                method: 'delete',
                mode: 'same-origin',
                headers: {
                    'Accept': 'application/json'
                },
                body: null
            })

            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }

            const json = await response.json();
            if (json.result !== 'success') {
                throw new Error(`${json.result} ${json.message}`);
            }
            setPatientOrderList(patientOrderList.filter(item => item.no !== order.no));

            socket.emit("sendCancelOrder", order.orderNo);
        } catch (err) {
            console.error(err);
        }
    }

    const handleFinish = async function () {
        setProgress(false);
        setDoctorMemo('');
        setPay([
            { menu: '기본 진료비', selfprice: '', nationprice: '' },
            { menu: '야간 할증료', selfprice: '', nationprice: '' },
            { menu: '시술 처치료', selfprice: '', nationprice: '' },
            { menu: '투약 조제료', selfprice: '', nationprice: '' },
            { menu: '합계', selfprice: '', nationprice: '' },
        ])

        try {
            await fetch('/api/orders/update', {
                method: 'post',
                mode: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    orderNo: selectOrderNo,
                    patientNo: selectOrder,
                    progress: '완료',
                    price: total
                })
            })

            setPatientOrderList(
                patientOrderList.map(item => item.orderNo === selectOrderNo ? ({ ...item, progress: '완료' }) : item)
            );
            socket.emit("sendfinishpatient", selectOrderNo);
            setPatient(
                patient.map(item => item.no === selectOrder ? ({ ...item, visit: true }) : item)
            );
            setSelectPatient({ ...selectpatient, visit: '재진' })

        } catch (err) {
            console.error(err)
        }
    }

    const updateCuringStatus = async function (patient) {
        try {
            const response = await fetch('/api/orders/update', {
                method: 'post',
                mode: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    ...patient,
                    progress: '진료중'
                })
            })

            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }

            const json = await response.json();
            if (json.result !== 'success') {
                throw new Error(`${json.result} ${json.message}`);
            }

            setPatientOrderList(
                patientOrderList.map(item => item.no === patient.no ? ({ ...item, progress: '진료중' }) : item)
            );
            socket.emit("sendcuringpatient", patient);
        } catch (err) {
            console.error(err);
        }
    }

    const getPatientRow = {
        find: async function (row) {
            setNurseMemo('')
            setDoctorMemo('')
            setSelectPatient(makePatientInfo(row));
        },
        search: async function () {
            let url = '';
            if (division === 'all' && keyword === '') {
                url = `/api/patient/${division}`;
            } else {
                url = `/api/patient/${division}/${keyword}`;
            }

            try {
                const response = await fetch(url, {
                    method: 'get',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: null
                })

                if (!response.ok) {
                    throw new Error(`${response.status} ${response.statusText}`);
                }
                const json = await response.json();

                if (json.result !== 'success') {
                    throw new Error(`${json.result} ${json.message}`);
                }
                setPatient(json.data);
            } catch (err) {
                console.error(err);
            }
        },
    }

    const initModal = (flag) => {
        setModalIsOpen(flag);
        setInput('');
        reset();
    }

    useEffect(() => {
        socket.on("receivepatientlist", (item) => {
            setPatientOrderList(patientOrderList.concat(item));
        })
        return () => {
            socket.off("receivepatientlist")
        }
    }, [patientOrderList]);

    useEffect(() => {
        socket.on("receivecuringpatient", (patient) => {
            setPatientOrderList(
                patientOrderList.map(item => item.no === patient.no ? ({ ...item, progress: '진료중' }) : item)
            );
        })
        return () => {
            socket.off("receivecuringpatient");
        }
    }, [patientOrderList]);

    useEffect(() => {
        socket.on("receiveCancelOrder", no => {
            setPatientOrderList(patientOrderList.filter(item => item.orderNo !== no));
        })
        return () => {
            socket.off("receiveCancelOrder")
        }
    }, [patientOrderList]);

    useEffect(() => {
        socket.on("receivefinishpatient", (orderNo) => {
            setPatientOrderList(
                patientOrderList.map(item => item.orderNo === orderNo ? ({ ...item, progress: '완료' }) : item)
            );
        })
        return () => {
            socket.off("receivefinishpatient")
        }
    }, [patientOrderList]);

    useEffect(() => {
        socket.on("receivepatientupdate", (item) => {
            setPatientOrderList(
                patientOrderList.map(listItem => listItem.no == item.no ? { ...listItem, name: item.name } : listItem)
            );
        })
        return () => {
            socket.off("receivepatientupdate")
        }
    }, [patientOrderList]);

    useEffect(() => {
        socket.on('receivepaywaiting', (patient) => {
            setPatientOrderList(
                patientOrderList.map((item) => item.no === patient.no ? ({ ...item, progress: '수납대기' }) : item)
            );
        })
        return () => {
            socket.off("receivepaywaiting");
        }
    }, [patientOrderList])

    useEffect(() => {
        socket.on('receiveAddPatient', (item) => {
            setPatient(patient.concat(item));           
        })
        return () => {
            socket.off("receiveAddPatient");
        }
    }, [patient])

    useEffect(() => {
        socket.on('receiveUpdatePatient', (getItem) => {
            setPatient(patient.map(item =>
                item.no == getItem.no ? { ...item, ...getItem } : item
            ))
        })
        return () => {
            socket.off("receiveUpdatePatient");
        }
    }, [patient])
    
    useEffect(()=> {
        socket.on('receiveUpdatePatientOfOrderList', (getItem) => {
            setPatientOrderList(patientOrderList.map(item =>
                item.no == getItem.no ? { ...item, name: getItem.name } : item
            ))
        })
        return () => {
            socket.off("receiveUpdatePatientOfOrderList");
        }
    },[patientOrderList])

    return (
        <SiteLayout>
            <GridContainer>
                <GridItem xs={12} sm={12} md={5}>
                    <Card style={{ marginTop: 10 }}>
                        <CardHeader title="환자조회" />
                        <div style={{ display: "flex", paddingLeft: 15 }}>
                            <PatientSelect notifyDivision={notifyDivision} />
                            <SearchBox
                                notifyKeyword={notifyKeyword}
                                placeholder={'내용을 입력하세요'} />
                            <IconButton aria-label="delete" onClick={getPatientRow.search}>
                                <SearchIcon />
                            </IconButton  >
                            <Button className={classes.buttons} onClick={() => initModal(true)}>
                                등록
                            </Button>
                        </div>
                        <CardContent>
                            <PatientList patient={patient} getPatientRow={getPatientRow} />
                        </CardContent>
                    </Card>

                    <Card style={{ marginTop: 10 }}>
                        <CardHeader title="환자접수현황" />
                        <CardContent>
                            <div>
                                <StatusMenu
                                    handleStatusMenu={handleStatusMenu}
                                    statusMenu={statusMenu}
                                    patientOrderList={patientOrderList} />
                                <PatientOrderList
                                    patientOrderList={
                                        statusMenu === 0 ? patientOrderList :
                                            statusMenu === 1 ? patientOrderList.filter(patient => patient.progress === '진료대기') :
                                                statusMenu === 2 ? patientOrderList.filter(patient => patient.progress === '진료중') :
                                                    statusMenu === 3 ? patientOrderList.filter(patient => patient.progress === '수납대기') :
                                                        patientOrderList.filter(patient => patient.progress === '완료')}
                                    updateCuringStatus={updateCuringStatus}
                                    cancelOrder={cancelOrder}
                                    getPatientInfo={getPatientInfo}
                                    statusMenu={statusMenu} />
                            </div>
                        </CardContent>
                    </Card>
                </GridItem>
                <GridItem xs={12} sm={12} md={4}>
                    <Card style={{ marginTop: 10 }}>
                        <CardHeader title="환자 정보" />
                        <CardContent>
                            <PatientUpdate patient={selectpatient == null ? '' : selectpatient} patientUpdate={patientUpdate} />
                            <PatientInfo patient={selectpatient == null ? '' : selectpatient} />
                        </CardContent>
                    </Card>
                    <Card style={{ marginTop: 10 }}>
                        <CardHeader title="간호사 메모" />
                        <CardContent>
                            <PostNurseMemo
                                handleNurseMemo={handleNurseMemo}
                                nurseMemo={nurseMemo} />
                        </CardContent>
                    </Card>
                    <Card style={{ marginTop: 10 }}>
                        <Button className={classes.buttons} fullWidth type='Button' onClick={handleOrder}>
                            접수
                        </Button>
                    </Card>
                </GridItem>

                <GridItem xs={12} sm={12} md={3}>
                    <Card style={{ marginTop: 10 }}>
                        <CardHeader title="내원 이력" />
                        <CardContent>
                            <PatientHistory
                                clinicHistory={clinicHistory}
                                getDetailHistory={getDetailHistory}
                                detail={detail} />
                        </CardContent>
                    </Card>
                    <Card style={{ marginTop: 10 }}>
                        <CardHeader title="전달사항" />
                        <CardContent>
                            <GetDoctorMemo doctorMemo={doctorMemo} />
                        </CardContent>
                    </Card>

                    <Card style={{ marginTop: 10 }}>
                        <CardHeader title="진료비" />
                        <CardContent>
                            <GetPriceList
                                pay={pay}
                            />
                        </CardContent>
                        {
                            progress ? <Button
                                className={classes.buttons}
                                fullWidth
                                onClick={handleFinish}>
                                수납완료
                            </Button>
                                : ''
                        }
                    </Card>
                </GridItem>

                <Modal
                    isOpen={modalIsOpen}
                    onRequestClose={() => setModalIsOpen(false)}
                    shouldCloseOnOverlayClick={true}
                    className={modalStyles.Modal}
                    overlayClassName={modalStyles.Overlay}
                    style={{ content: { width: 400 } }}>
                    <h3>환자 등록</h3>
                    <div>
                        <form
                            className={modalStyles.FormUpload}
                            onSubmit={handleSubmit(onSubmit)}
                            onChange={onChange}>
                            <label>이름</label>
                            <br />

                            <InputBase
                                type={'text'}
                                name={'name'}
                                placeholder={'이름'}
                                value={input.name || ''}
                                autoFocus
                                fullWidth
                                {...register("name", {
                                    required: true,
                                    pattern: /[가-힣]/g
                                })}
                            />
                            {errors?.name?.type === "required" && <p>이름을 입력해주세요.</p>}
                            {errors?.name?.type === "pattern" && (
                                <p>이름을 정확히 입력해주세요.</p>
                            )}
                            <br /><br />
                            <label>주민등록번호</label>
                            <br />
                            <InputBase
                                name={'registration_no'}
                                placeholder={'주민등록번호'}
                                value={input.registration_no || ''}
                                maxLength={"14"}
                                inputComponent={TextMaskCustom}
                                autoFocus
                                {...register("registration_no", {
                                    required: true,
                                    pattern: /\d{2}([0]\d|[1][0-2])([0][1-9]|[1-2]\d|[3][0-1])[-]*[1-4]\d{6}/g,
                                })}
                            />
                            {errors?.registration_no?.type === "required" && <p>주민등록번호를 입력해주세요.</p>}
                            {errors?.registration_no?.type === "pattern" && (
                                <p>주민등록번호를 정확히 입력해주세요.</p>
                            )}
                            <br /><br />

                            <label>전화번호</label>
                            <br />
                            <InputBase
                                type={'tel'}
                                name={'cellphone'}
                                placeholder={'전화번호'}
                                maxLength={"13"}
                                value={input.cellphone || ''}
                                inputComponent={TextMaskCustom}
                                autoFocus
                                {...register('cellphone', {
                                    required: true,
                                    pattern: (/(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/, "$1-$2-$3")
                                })}
                            />
                            {errors?.cellphone?.type === "required" && <p>전화번호를 입력해주세요.</p>}
                            {errors?.cellphone?.type === "pattern" && (
                                <p>전화번호를 정확히 입력해주세요.</p>
                            )}
                            <br /><br />
                            <label>우편번호 </label>
                            <br />
                            <InputBase
                                type={'text'}
                                name={'zipcode'}
                                placeholder={'우편번호'}
                                value={input.zipcode || ''}
                                disabled
                                {...register("zipcode", {
                                    required: true,
                                    value: input.zipcode,
                                })}
                            />
                            <Button color='primary' onClick={handleAddressOpen}> 주소찾기</Button>
                            {post ? <Dialog open={open}>
                                <DialogTitle >주소검색<Button onClick={() => setPost(false)} color="primary">
                                    x
                                </Button></DialogTitle>
                                <DialogContent>
                                    <DaumPostcode onComplete={onCompletePost} />
                                </DialogContent>
                            </Dialog> : null}
                            <InputBase
                                type={'text'}
                                name={'address'}
                                value={input.address || ''}
                                placeholder={'주소'}
                                disabled
                                style={{ width: '50%' }}
                                {...register("address", {
                                    required: true,
                                    value: input.address
                                })}
                            />
                            {errors?.address?.type === "required" && <p>주소를 입력해주세요.</p>}
                            <br />
                            <InputBase
                                type={'text'}
                                name={'detailaddress'}
                                placeholder={'상세주소'}
                                value={input.detailaddress || ''}
                                autoFocus
                                {...register("detailaddress", {
                                    required: true,
                                })}
                            />
                            {errors?.detailaddress?.type === "required" && <p>상세 주소를 입력해주세요.</p>}
                            <br /><br />

                            <label>보험</label>
                            <br />
                            <input
                                type={'radio'}
                                name={'insurance'}
                                value={true}
                            />
                            <label>유</label>
                            <input
                                type={'radio'}
                                name={'insurance'}
                                value={false}
                            />

                            <label>무</label>
                            <br /><br />
                            <label>특이사항</label>
                            <br />
                            <InputBase
                                type={'text'}
                                name={'memo'}
                                placeholder={'내용을 입력해주세요'}
                                value={input.memo || ''}
                                fullWidth
                            />
                            <br />
                            <div style={{ display: 'flex' }}>
                                <Button type="submit" color="primary" fullWidth>
                                    확인
                                </Button>
                                <Button color="primary" fullWidth onClick={() => initModal(false)}>
                                    취소
                                </Button>
                            </div>
                        </form>
                    </div>
                </Modal>

                <Dialog
                    open={duplication}
                    TransitionComponent={Transition}
                >
                    <DialogTitle className={classes.dialogTitle}>알림</DialogTitle>
                    {selectpatient ?
                        <div className={classes.dialogDuplicate}>
                            {`${selectpatient.name}님은 이미 접수 되었습니다.`}
                        </div>
                        : null}
                    <DialogActions>
                        <Button variant="outlined" onClick={() => setDuplication(false)} color="primary" >
                            닫기
                        </Button>
                    </DialogActions>
                </Dialog>
            </GridContainer>
        </SiteLayout>
    );
}