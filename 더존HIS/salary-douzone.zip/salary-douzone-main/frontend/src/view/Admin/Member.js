import Button from '@material-ui/core/Button';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import blue from '@material-ui/core/colors/blue';
import IconButton from '@material-ui/core/IconButton';
import SearchIcon from '@material-ui/icons/Search';
import React, { useEffect, useState } from 'react';
import MemberAdd from '../../components/Admin/Member/MemberAdd';
import MemberInfo from '../../components/Admin/Member/MemberInfo';
import MemberList from '../../components/Admin/Member/MemberList';
import MemberListSelect from '../../components/Admin/Member/MemberListSelect';
import GridContainer from '../../components/common/GridContainer';
import GridItem from '../../components/common/GridItem';
import SearchBox from '../../components/common/SearchBox';
import SiteLayout from '../../components/common/SiteLayout';

export default function Member() {
    const [members, setMembers] = useState([]);
    const [checkedMember, setCheckedMembers] = useState([]);
    const [selectMember, setSelectMember] = useState([]);
    const [addMember, setAddMember] = useState(false);
    const [division, setDivision] = useState('all');
    const [keyword, setKeyword] = useState('');
    const [workChecking, setworkChecking] = useState(false);
    const [workFlag, setWorkFlag] = useState(false);

    useEffect(async () => {
        try {
            const response = await fetch('/api/member', {
                method: 'get',
                mode: 'same-origin',
                header: {
                    'Content-Type': 'application/json'
                },
                body: null
            })

            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }

            const json = await response.json();
            if (json.result !== 'success') {
                throw new Error(`${json.result} ${json.message}`);
            }

            setCheckedMembers(json.data);
            setMembers(json.data);
            setSelectMember(json.data[0]);

        } catch (err) {
            console.error(err);
        }
    }, []);


    const notifyDivision = function (division) {
        setDivision(division);
    }

    const notifyKeyword = function (keyword) {
        setKeyword(keyword)
    }

    const notifyWoriking = function (flag) {
        setworkChecking(!flag);
    }

    useEffect(() => {
        setMembers(checkedMember.filter((member) => member.working == workFlag))
        setWorkFlag(!workFlag);
    }, [workChecking]);

    const modifyMember = {
        getMemberRow: function (row) {
            setSelectMember({
                ...row,
                url: ''
            });
            setAddMember(false);
        },
        addMember: async function (member) {
            try {
                let formData = new FormData();
                formData.append('profile', profile);
                for (let item in member) {
                    formData.append(item, member[item]);
                }

                const response = await fetch('/api/member', {
                    method: 'post',
                    mode: 'same-origin',
                    headers: {
                        'Accept': 'application/json'
                    },
                    body: formData
                });

                if (!response.ok) {
                    throw new Error(`${response.status} ${response.statusText}`);
                }
                const json = await response.json();

                if (json.result !== 'success') {
                    throw new Error(`${json.result} ${json.message}`);
                }

                setMembers(members.concat({ ...member, ...json.data[0] }));
            } catch (err) {
                console.error(err);
            }
        },
        search: async function () {
            let url = '';
            if (division === 'all' && keyword === '') {
                url = `/api/member/${division}`;
            } else {
                url = `/api/member/${division}/${keyword}`;
            }

            try {
                const response = await fetch(url, {
                    method: 'get',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: null
                })

                if (!response.ok) {
                    throw new Error(`${response.status} ${response.statusText}`);
                }
                const json = await response.json();

                if (json.result !== 'success') {
                    throw new Error(`${json.result} ${json.message}`);
                }

                setMembers(json.data);
                setCheckedMembers(json.data);
            } catch (err) {
                console.error(err);
            }
        },
        updateMember: async function (member) {
            try {
                let formData = new FormData();
                for (let item in member) {
                    formData.append(item, member[item]);
                }
                const response = await fetch('/api/member/' + member.no, {
                    method: 'post',
                    mode: 'same-origin',
                    headers: {
                        'Accept': 'application/json'
                    },
                    body: formData
                })

                if (!response.ok) {
                    throw new Error(`${response.status} ${response.statusText}`);
                }

                const json = await response.json();
                if (json.result !== 'success') {
                    throw new Error(`${json.result} ${json.message}`);
                }

                setMembers(
                    members.map(item => item.no === member.no ? ({ ...item, ...member }) : item)
                );
                setSelectMember(member);

            } catch (err) {
                console.error(err);
            }
        },
    };

    return (
        <SiteLayout>
            <GridContainer>
                <GridItem xs={12} sm={12} md={6}>
                    <Card>
                        <CardHeader title="사용자 조회" />
                        <div style={{ display: "flex", paddingLeft: 15, paddingRight: 15 }}>
                            <MemberListSelect
                                notifyDivision={notifyDivision} />
                            <SearchBox
                                notifyKeyword={notifyKeyword}
                                keyword={keyword} />
                            <IconButton aria-label="delete" onClick={modifyMember.search}>
                                <SearchIcon />
                            </IconButton>
                            <Button style={{ backgroundColor: blue[500], color: 'white' }} onClick={() => setAddMember(true)}>
                                등록
                            </Button>
                        </div>
                        <CardContent>
                            <MemberList
                                members={members}
                                modifyMember={modifyMember}
                                notifyWoriking={notifyWoriking}
                            />
                        </CardContent>
                    </Card>
                </GridItem>

                <GridItem xs={12} sm={12} md={6}>
                    <Card>
                        {addMember ?
                            <CardHeader title='사용자 등록' />
                            : <CardHeader title='사용자 정보' />
                        }
                        <CardContent>
                            {addMember ? <MemberAdd modifyMember={modifyMember} /> : <MemberInfo modifyMember={modifyMember}
                                member={selectMember == null ? '' : selectMember} />}
                        </CardContent>
                    </Card>
                </GridItem>
            </GridContainer>
        </SiteLayout>
    );
}