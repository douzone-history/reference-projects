import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import React, { useEffect, useState } from 'react';
import MedicineInfo from '../../components/Admin/Medicine/MedicineInfo';
import MedicineList from '../../components/Admin/Medicine/MedicineList';
import MedicineSelect from '../../components/Admin/Medicine/MedicineSelect';
import GridContainer from '../../components/common/GridContainer';
import GridItem from '../../components/common/GridItem';
import SearchBox from '../../components/common/SearchBox';
import SiteLayout from '../../components/common/SiteLayout';

export default function Medicine() {
    const [medicines, setMedicines] = useState([]);
    const [selectMedicine, setSelectMedicine] = useState([]);
    const [division, setDivision] = useState('all');
    const [keyword, setKeyword] = useState('');

    useEffect(async () => {
        try {
            const response = await fetch('/api/medicine', {
                method: 'get',
                headers: { 'Content-Type': 'application/json' }
            });

            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }

            const json = await response.json();
            if (json.result !== 'success') {
                throw new Error(`${json.result} ${json.message}`);
            }
            setMedicines(json.data);
            setSelectMedicine(json.data[0]);
        } catch (err) {
            console.error(err);
        }
    }, []);

    const getMedicineRow = (row) => {
        setSelectMedicine(row);
    }

    const notifyDivision = function (division) {
        setDivision(division);
    }

    const notifyKeyword = function (keyword) {
        setKeyword(keyword);
    }

    return (
        <SiteLayout>
            <GridContainer>
                <GridItem xs={12} sm={12} md={6}>
                    <Card>
                        <CardHeader title="의약품 조회" />
                        <div style={{ display: "flex", paddingLeft: 15, paddingRight: 15 }}>
                            <MedicineSelect notifyDivision={notifyDivision} />
                            <SearchBox
                                notifyKeyword={notifyKeyword}
                                keyword={keyword} />
                        </div>
                        <CardContent>
                            <MedicineList
                                medicines={medicines}
                                getMedicineRow={getMedicineRow}
                                division={division}
                                keyword={keyword}
                            />
                        </CardContent>
                    </Card>
                </GridItem>

                <GridItem xs={12} sm={12} md={6}>
                    <Card>
                        <CardHeader title="의약품 정보" />
                        <CardContent>
                            <MedicineInfo
                                medicine={selectMedicine == null ? '' : selectMedicine} />
                        </CardContent>
                    </Card>
                </GridItem>

            </GridContainer>
        </SiteLayout>
    );
}