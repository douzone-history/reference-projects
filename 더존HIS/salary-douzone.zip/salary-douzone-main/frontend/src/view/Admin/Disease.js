import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import React, { useEffect, useState } from 'react';
import DiseaseInfo from '../../components/Admin/Disease/DiseaseInfo';
import DiseaseList from '../../components/Admin/Disease/DiseaseList';
import DiseaseSelect from '../../components/Admin/Disease/DiseaseSelect';
import GridContainer from '../../components/common/GridContainer';
import GridItem from '../../components/common/GridItem';
import SearchBox from '../../components/common/SearchBox';
import SiteLayout from '../../components/common/SiteLayout';

export default function Disease() {
  const [diseases, setDiseases] = useState([]);
  const [selectDisease, setSelectDisease] = useState([]);
  const [division, setDivision] = useState('all');
  const [keyword, setKeyword] = useState('');

  useEffect(async () => {
    try {
      const response = await fetch('/api/disease', {
        method: 'get',
        headers: { 'Content-Type': 'application/json' }
      });

      if (!response.ok) {
        throw new Error(`${response.status} ${response.statusText}`);
      }

      const json = await response.json();
      if (json.result !== 'success') {
        throw new Error(`${json.result} ${json.message}`);
      }

      setDiseases(json.data);
      setSelectDisease(json.data[0]);
    } catch (err) {
      console.error(err);
    }
  }, []);

  const getDiseaseRow = (sickCd, sickNm) => {
    setSelectDisease({ sickCd, sickNm });
  }

  const notifyDivision = function (division) {
    setDivision(division);
  }

  const notifyKeyword = function (keyword) {
    setKeyword(keyword);
  }

  return (
    <SiteLayout>
      <GridContainer>
        <GridItem xs={12} sm={12} md={6}>
          <Card>
            <CardHeader title="질병코드 조회" />
            <div style={{ display: "flex", paddingLeft: 15, paddingRight: 15, width: '100%' }}>
              <DiseaseSelect notifyDivision={notifyDivision} />
              <SearchBox
                notifyKeyword={notifyKeyword}
                keyword={keyword} />
            </div>
            <CardContent>
              <DiseaseList
                diseases={diseases}
                getDiseaseRow={getDiseaseRow}
                division={division}
                keyword={keyword}
              />
            </CardContent>
          </Card>
        </GridItem>

        <GridItem xs={12} sm={12} md={6}>
          <Card>
            <CardHeader title="질병코드 정보" />
            <CardContent>
              <DiseaseInfo
                disease={selectDisease == null ? '' : selectDisease} />
            </CardContent>
          </Card>
        </GridItem>
      </GridContainer>
    </SiteLayout>
  );
}