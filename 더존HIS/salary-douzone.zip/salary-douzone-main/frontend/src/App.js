import React from 'react';
import { BrowserRouter, Switch } from 'react-router-dom';
import AuthRoute from './components/common/AuthRoute';
import Disease from './view/Admin/Disease';
import Medicine from './view/Admin/Medicine';
import Member from './view/Admin/Member';
import Login from './view/SignIn/Login';
import Doctor from './view/User/Doctor';
import Nurse from './view/User/Nurse';

export default function App() {
    return (
        <BrowserRouter>
            <Switch>
                <AuthRoute component={Login} path="/" exact />
                <AuthRoute component={Member} path="/admin" role={'admin'} exact />
                <AuthRoute component={Member} path="/admin/member" role={'admin'} exact />
                <AuthRoute component={Medicine} path="/admin/medicine" role={'admin'} exact />
                <AuthRoute component={Disease} path="/admin/disease" role={'admin'} exact />
                <AuthRoute component={Nurse} path="/nurse" role={'nurse'} exact />
                <AuthRoute component={Doctor} path="/doctor" role={'doctor'} exact />
            </Switch>
        </BrowserRouter>
    );
}
