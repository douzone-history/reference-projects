package com.douzone.ucare.vo;

public class ReservationVo {
	private Long revNo;
	private String revDate;
	private String revTime;
	private Long insNo;
	private String insDt;
	private Long uptNo;
	private String updDt;
	private Long patientNo;
	private String name;
	private String telNo;
	private String ssn;
	private String insurance;
	
	public Long getRevNo() {
		return revNo;
	}
	public void setRevNo(Long revNo) {
		this.revNo = revNo;
	}
	public String getRevDate() {
		return revDate;
	}
	public void setRevDate(String revDate) {
		this.revDate = revDate;
	}
	public String getRevTime() {
		return revTime;
	}
	public void setRevTime(String revTime) {
		this.revTime = revTime;
	}
	public Long getInsNo() {
		return insNo;
	}
	public void setInsNo(Long insNo) {
		this.insNo = insNo;
	}
	public String getInsDt() {
		return insDt;
	}
	public void setInsDt(String insDt) {
		this.insDt = insDt;
	}
	public Long getUptNo() {
		return uptNo;
	}
	public void setUptNo(Long uptNo) {
		this.uptNo = uptNo;
	}
	public String getUpdDt() {
		return updDt;
	}
	public void setUpdDt(String updDt) {
		this.updDt = updDt;
	}
	public Long getPatientNo() {
		return patientNo;
	}
	public void setPatientNo(Long patientNo) {
		this.patientNo = patientNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTelNo() {
		return telNo;
	}
	public void setTelNo(String telNo) {
		this.telNo = telNo;
	}
	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	public String getInsurance() {
		return insurance;
	}
	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}
		
}
