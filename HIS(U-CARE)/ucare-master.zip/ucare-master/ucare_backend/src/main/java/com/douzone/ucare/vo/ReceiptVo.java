package com.douzone.ucare.vo;

public class ReceiptVo {
	private Long receiptNo;
	private String receiptDt;
	private String receiptTime;
	private String accept;
	private int bp;
	private int bs;
	private String remark;
	private String insDt;
	private String uptNo;
	private String uptDt;
	private Long patientNo;
	private String userId;
	private String name;
	private Long no;
	private String state;
	private String diagnosisTime;
	private String cureYN;
	private String overlap;

	public Long getNo() {
		return no;
	}
	public void setNo(Long no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getReceiptNo() {
		return receiptNo;
	}
	public void setReceiptNo(Long receiptNo) {
		this.receiptNo = receiptNo;
	}
	public String getReceiptDt() {
		return receiptDt;
	}
	public void setReceiptDt(String receiptDt) {
		this.receiptDt = receiptDt;
	}
	public String getReceiptTime() {
		return receiptTime;
	}
	public void setReceiptTime(String receiptTime) {
		this.receiptTime = receiptTime;
	}
	public String getAccept() {
		return accept;
	}
	public void setAccept(String accept) {
		this.accept = accept;
	}
	public int getBp() {
		return bp;
	}
	public void setBp(int bp) {
		this.bp = bp;
	}
	public int getBs() {
		return bs;
	}
	public void setBs(int bs) {
		this.bs = bs;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getInsDt() {
		return insDt;
	}
	public void setInsDt(String insDt) {
		this.insDt = insDt;
	}
	public String getUptNo() {
		return uptNo;
	}
	public void setUptNo(String uptNo) {
		this.uptNo = uptNo;
	}
	public String getUptDt() {
		return uptDt;
	}
	public void setUptDt(String uptDt) {
		this.uptDt = uptDt;
	}
	public Long getPatientNo() {
		return patientNo;
	}
	public void setPatientNo(Long patientNo) {
		this.patientNo = patientNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDiagnosisTime() {
		return diagnosisTime;
	}
	public void setDiagnosisTime(String diagnosisTime) {
		this.diagnosisTime = diagnosisTime;
	}
	public String getCureYN() {
		return cureYN;
	}
	public void setCureYN(String cureYN) {
		this.cureYN = cureYN;
	}
	public String getOverlap() {
		return overlap;
	}
	public void setOverlap(String overlap) {
		this.overlap = overlap;
	}
	
	@Override
	public String toString() {
		return "ReceiptVo [receiptNo=" + receiptNo + ", receiptDt=" + receiptDt + ", receiptTime=" + receiptTime
				+ ", accept=" + accept + ", bp=" + bp + ", bs=" + bs + ", remark=" + remark + ", insDt=" + insDt
				+ ", uptNo=" + uptNo + ", uptDt=" + uptDt + ", patientNo=" + patientNo + ", userId=" + userId
				+ ", name=" + name + ", no=" + no + ", state=" + state + ", diagnosisTime=" + diagnosisTime
				+ ", cureYN=" + cureYN + ", overlap=" + overlap + "]";
	}

}
