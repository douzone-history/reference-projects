import { VIEW_STATE } from './types';

export const viewManage = () => {
    return {
        type: VIEW_STATE
    }
}