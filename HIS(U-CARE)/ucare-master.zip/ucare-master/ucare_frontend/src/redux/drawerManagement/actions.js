import { ChangeState } from './types';

export const drawerManage = () => {
    return {
        type: ChangeState
    }
}