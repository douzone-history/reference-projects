## git commit 규칙
 - 작업하기 전에 항상 최신 src pull 한 후 작업 시작

## commit message
 - 작업일자 수정내역 알아보기 쉽게 기록

## sql 작성 규칙
 - 테이블명, 컬럼명 소문자로 작성
 - &#42; 사용 금지
 - 들여쓰기 사용
 - outer join 가급적 지양
