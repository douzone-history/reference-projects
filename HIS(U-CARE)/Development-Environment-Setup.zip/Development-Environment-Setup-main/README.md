# Development-Environment-Setup

## PostgreSQL 설치 가이드
- https://dog-developers.tistory.com/122?category=896103 <- 해당 링크 따라 설치
- Port: Default(5432)
- DB GUI Tool: DBeaver 사용 추천
